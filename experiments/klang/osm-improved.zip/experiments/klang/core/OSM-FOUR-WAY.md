# Four-way oscillator performance comparison

17 September 2026. A fresh common benchmark compares:

1. **Original Klang:** the unchanged, faulty `include/klang.h`.
2. **V2 C++:** the unmodified oscillator routines from Fabian Giesen's C++ port
   of Tammo Hinrichs's V2. The original x87 assembler is not timed here.
3. **Fixed positive-only:** the retained V2-informed Klang fix, before signed
   frequency support, reconstructed with its original verified header hash.
4. **Reflection:** the current separate reflection prototype, with the revised
   unsigned setter, no `width`/`step`, restored comparison syntax and double scale.

This measures complete oscillator workloads, including applicable setters,
buffer clearing/output accumulation and the checksum loop. It does not isolate
the setter's instruction latency. Default experimental and production headers
remain unchanged.

## Method and limitations

- Intel i7-10700, Windows x64, one voice at 48 kHz, C++17.
- MSVC 19.51.36257 and Clang 22.1.3. Release `/O2 /fp:precise /MD`; Debug
  `/Od /fp:precise /MDd`. These are standalone builds, not full UE builds.
- Five two-million-sample passes per case. Median of three Release repetitions
  or two Debug repetitions. Executable order reverses between repetitions;
  compilation finishes before timing and configurations run sequentially.
- All four versions use the same benchmark source and buffers. Construction,
  allocation, device interaction and file I/O are outside the timed region.
- Fixed frequency is 440 Hz. Changing frequency uses a precomputed positive
  `440 + 200*sin(i*0.03)` sequence. The common comparison does not ask the
  unsigned implementations to process negative frequencies.
- V2 exposes block render functions and computes coefficients once per call.
  A fixed 64-sample call therefore amortises that work. Per-sample parameter
  changes require one-sample calls in this adapter. Both call sizes are shown.
- V2 receives a small cached Hz-to-counter adapter; the full synthesizer's
  note/pitch mapping, envelopes and voice management are excluded. The render
  routines, gain of 1 and non-ring output path are preserved unchanged.
- Saw duty is 0, triangle/square 50%, and pulse 25%. The old Klang Pulse's
  default parameter of 0.5 maps to 25% through its faulty half-scale conversion;
  the corrected versions explicitly select 0.25. No broken DSP code is repaired
  in the original comparison.
- Timing does not establish correctness. V2 has the previously documented
  low-frequency/phase-resolution limits; original Klang retains its bugs.
  Only reflection has the tested signed-frequency contract among these four.

The buffer clear/sum work and extra render-call structure differ from the
earlier scalar-only benchmark. Compare numbers within this report. Inlining,
loop structure and code layout can change the relative costs: these results
do not supersede earlier measurements as universal oscillator timings.

## Results

All times are **elapsed ns/sample; lower is faster**. `Fixed/64` uses native
64-sample render calls. `Fixed/1` renders one sample at a time without calling
the setter. `Same/1` repeats the unchanged setter each sample; `Vary/1` changes
positive frequency each sample. The tables below are generated from the retained
results, including every repetition and min/max in the JSON archive.

### MSVC Release

| Version | Waveform | Fixed/64 | Fixed/1 | Same/1 | Vary/1 |
| --- | --- | ---: | ---: | ---: | ---: |
| Original Klang | saw | 4.384 | 5.360 | 5.746 | 10.691 |
| Original Klang | triangle | 4.307 | 4.911 | 5.812 | 10.530 |
| Original Klang | square | 3.996 | 4.790 | 5.760 | 9.274 |
| Original Klang | pulse25 | 4.613 | 4.529 | 5.490 | 9.205 |
| V2 C++ | saw | 3.202 | 7.727 | 8.519 | 8.865 |
| V2 C++ | triangle | 3.474 | 7.833 | 8.175 | 9.175 |
| V2 C++ | square | 3.082 | 6.465 | 6.658 | 8.490 |
| V2 C++ | pulse25 | 2.938 | 7.366 | 7.677 | 7.692 |
| Fixed positive-only | saw | 4.113 | 4.475 | 5.494 | 9.897 |
| Fixed positive-only | triangle | 4.185 | 4.507 | 5.528 | 9.292 |
| Fixed positive-only | square | 3.748 | 4.764 | 5.822 | 8.662 |
| Fixed positive-only | pulse25 | 3.932 | 4.185 | 5.802 | 8.574 |
| Reflection | saw | 4.210 | 4.820 | 5.440 | 10.111 |
| Reflection | triangle | 4.339 | 4.664 | 5.384 | 10.589 |
| Reflection | square | 3.744 | 4.445 | 5.824 | 9.408 |
| Reflection | pulse25 | 3.768 | 4.832 | 6.063 | 9.363 |

### Clang Release

| Version | Waveform | Fixed/64 | Fixed/1 | Same/1 | Vary/1 |
| --- | --- | ---: | ---: | ---: | ---: |
| Original Klang | saw | 3.311 | 3.318 | 3.452 | 8.614 |
| Original Klang | triangle | 3.326 | 3.405 | 3.607 | 9.133 |
| Original Klang | square | 3.038 | 3.144 | 3.449 | 8.431 |
| Original Klang | pulse25 | 3.033 | 3.148 | 3.631 | 7.866 |
| V2 C++ | saw | 1.175 | 2.240 | 2.457 | 3.118 |
| V2 C++ | triangle | 2.691 | 3.543 | 3.767 | 4.834 |
| V2 C++ | square | 2.426 | 3.159 | 3.380 | 4.717 |
| V2 C++ | pulse25 | 2.502 | 3.193 | 3.410 | 4.464 |
| Fixed positive-only | saw | 1.905 | 2.059 | 2.628 | 4.475 |
| Fixed positive-only | triangle | 2.640 | 3.040 | 3.503 | 6.209 |
| Fixed positive-only | square | 2.299 | 2.393 | 3.139 | 5.771 |
| Fixed positive-only | pulse25 | 2.110 | 2.438 | 3.070 | 5.404 |
| Reflection | saw | 2.766 | 3.344 | 3.547 | 8.213 |
| Reflection | triangle | 2.876 | 3.099 | 3.611 | 8.373 |
| Reflection | square | 2.202 | 2.588 | 3.169 | 6.739 |
| Reflection | pulse25 | 2.207 | 2.439 | 3.009 | 6.541 |

### MSVC Debug

| Version | Waveform | Fixed/64 | Fixed/1 | Same/1 | Vary/1 |
| --- | --- | ---: | ---: | ---: | ---: |
| Original Klang | saw | 21.452 | 25.852 | 35.236 | 56.052 |
| Original Klang | triangle | 21.407 | 27.463 | 36.368 | 55.504 |
| Original Klang | square | 19.263 | 21.590 | 32.465 | 53.981 |
| Original Klang | pulse25 | 20.633 | 20.198 | 32.444 | 55.059 |
| V2 C++ | saw | 14.032 | 30.503 | 27.698 | 34.066 |
| V2 C++ | triangle | 15.054 | 30.123 | 28.430 | 34.313 |
| V2 C++ | square | 14.045 | 29.908 | 31.290 | 31.888 |
| V2 C++ | pulse25 | 15.081 | 27.092 | 30.333 | 33.857 |
| Fixed positive-only | saw | 16.230 | 19.059 | 26.035 | 56.401 |
| Fixed positive-only | triangle | 16.984 | 19.494 | 27.814 | 52.362 |
| Fixed positive-only | square | 16.659 | 18.344 | 25.624 | 50.590 |
| Fixed positive-only | pulse25 | 17.001 | 17.698 | 26.812 | 50.694 |
| Reflection | saw | 15.399 | 17.891 | 26.535 | 54.732 |
| Reflection | triangle | 15.081 | 17.733 | 26.996 | 56.656 |
| Reflection | square | 15.177 | 17.148 | 24.089 | 55.439 |
| Reflection | pulse25 | 15.271 | 17.471 | 26.077 | 53.519 |

### Clang Debug

| Version | Waveform | Fixed/64 | Fixed/1 | Same/1 | Vary/1 |
| --- | --- | ---: | ---: | ---: | ---: |
| Original Klang | saw | 23.448 | 26.402 | 37.223 | 62.983 |
| Original Klang | triangle | 21.886 | 27.901 | 37.867 | 59.869 |
| Original Klang | square | 18.092 | 23.949 | 36.467 | 59.707 |
| Original Klang | pulse25 | 19.082 | 22.689 | 35.131 | 62.123 |
| V2 C++ | saw | 13.642 | 33.595 | 34.806 | 34.005 |
| V2 C++ | triangle | 14.290 | 31.097 | 33.293 | 36.198 |
| V2 C++ | square | 14.680 | 31.373 | 33.036 | 38.933 |
| V2 C++ | pulse25 | 13.619 | 29.211 | 30.601 | 37.317 |
| Fixed positive-only | saw | 13.671 | 17.345 | 30.808 | 49.956 |
| Fixed positive-only | triangle | 14.355 | 18.178 | 29.033 | 53.958 |
| Fixed positive-only | square | 14.385 | 19.287 | 28.502 | 50.820 |
| Fixed positive-only | pulse25 | 14.467 | 19.206 | 28.486 | 47.993 |
| Reflection | saw | 12.750 | 18.043 | 28.551 | 50.779 |
| Reflection | triangle | 13.900 | 18.281 | 27.993 | 51.499 |
| Reflection | square | 13.523 | 20.143 | 25.611 | 52.219 |
| Reflection | pulse25 | 14.307 | 18.004 | 27.161 | 48.382 |


## Interpretation

The reflection version has not established universal preservation of
positive-only performance. In this workload MSVC Release is relatively close;
Clang's saw and triangle show appreciable overhead, especially with changing
frequency. Other waveforms differ. These results strengthen the case for
reviewing caller/inlining behaviour before promoting reflection.

V2's native block routine is an effective baseline. Its one-sample calls expose
repeated coefficient preparation, particularly in MSVC and Debug. Caching and
calling conventions matter alongside the state-machine equations.

Instance memory is not a complete synthesizer comparison. The extracted V2
state plus its Hz adapter is 24 bytes; the Klang objects include their normal
base-class state. The measured instances are 104 bytes for original Klang,
136 for the positive-only fix, and 144 for reflection. All share the same
256-byte scratch audio buffer in the harness.

## Evidence and reproduction

[osm-four-way-results.json](osm-four-way-results.json) retains the four
compiler/build runs, source/header hashes, compiler commands, execution order,
all measurements and finite output checksums. Source provenance and V2's known
limitations are in [V2-SOURCE-REVIEW.md](V2-SOURCE-REVIEW.md).

From an x64 VS developer prompt, run sequentially:

```text
python tests/klang/compare_osm_versions.py --output build/osm-four-way/msvc
python tests/klang/compare_osm_versions.py --compiler clang-cl.exe --output build/osm-four-way/clang
python tests/klang/compare_osm_versions.py --debug --repeats 2 --output build/osm-four-way/debug-msvc
python tests/klang/compare_osm_versions.py --debug --repeats 2 --compiler clang-cl.exe --output build/osm-four-way/debug-clang
```

The runner requires the existing pinned local `build/farbrausch-v2/synth_core.cpp`
and verifies its SHA-256 before extracting unchanged routines. Generated headers,
executables, CSVs and logs remain under `build/`.
