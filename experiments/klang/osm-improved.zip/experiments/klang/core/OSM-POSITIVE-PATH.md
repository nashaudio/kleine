# OSM positive-path and Debug performance review

16 September 2026. Experimental core only; production and UE headers are unchanged.

Follow-up: [storage, transition encoding, case order and dispatch](OSM-LAYOUT.md)
tests Chris's specific suggestions independently, including deriving `step` at
boundaries and selecting forward/signed routines with the existing function pointer.

## Outcome

Negative frequency can use separate boundary formulas while sharing the cheap
ordinary-sample calculations. This improves the previous signed implementation,
particularly in Debug and in Clang's concrete-type Release tests. **It has not
eliminated the Release cost compared with the positive-only implementation.**
Some MSVC and virtual-call workloads regress against the previous signed version.
This remains a prototype with a performance trade-off, not an accepted CPU fix.
The earlier approximately 6% figure was one comparison, not a universal overhead.

Chris's Debug requirement is now recorded in `AGENTS.md`. Debug throughput is a
separate measured requirement; passing correctness tests with optimisations off
does not establish that a design is inexpensive in that mode.

## Explicit implementation changes

- The OSM handles signed increments directly. Its two previously unused
  transition codes describe backwards crossings of the peak and cycle boundary.
- Ordinary rising/falling samples keep the same cached linear formulas. Pulse
  plateaus remain constant `+1` and `-1`. Additional backwards formulas run only
  at the relevant boundary; there is no per-sample phase mirroring or pulse
  polarity multiplication.
- `set()` caches direction, interval magnitude, inverse interval and waveform
  coefficients. Repeated unchanged frequency requests do not reconfigure them.
- The counter advances with native unsigned arithmetic; internal comparisons
  read the stored float values directly. These remove wrapper calls in Debug
  without depending on compiler inlining. Public Klang argument types and
  calling syntax are unchanged.
- The concrete waveform classes call their waveform routine directly. The
  generic `Osm` still supports its existing waveform member-function pointer.

There is still one shared direction comparison/XOR when classifying a sample's
transition. The expanded switch and signed setup also affect generated code.
Consequently, separate exceptional formulas do **not** imply zero positive-path
overhead. The object is 152 bytes, versus 144 for the prior signed wrapper and
136 for the positive-only candidate. No allocation was added.

The previous signed wrapper, cached-polarity setup, a no-inline boundary helper,
separate forward/backward sample routines and a cached direction-mask variant
were explored. Moving code out of line did not reliably recover positive-only
Release speed: register spills and lost specialisation offset the smaller
sample routine. The current direct state machine avoids that wrapper and has
the strongest concrete-type Clang results of these signed trials; MSVC's
regressions remain explicit below.

## CPU measurements

Intel Core i7-10700, Windows x64, MSVC 19.51.36257 and clang-cl 22.1.3, C++17,
`/fp:precise`. Release uses `/O2 /MD /DNDEBUG`; Debug uses `/Od /MDd /D_DEBUG`.
These are standalone builds, not a claim to reproduce every UE/VS Debug option
such as runtime checks. One voice, 48 kHz, five passes of two million samples,
repeated three times; report median of the three pass medians.
Construction, devices, allocation and file I/O are outside the timed loop.

Percentages below are changes in time per sample: **negative means faster**.
Ranges span Saw, Triangle, Square and Pulse. Timings include the same checksum
and loop overhead for every header. Concrete and opaque virtual-call workloads
are separate builds. The identical runtime mode selector is now used for all
headers so the benchmark does not give one header different compile-time loop
specialisation opportunities.

### Debug: concrete types

| Positive workload | Current MSVC, ns/sample | Versus positive-only | Current Clang, ns/sample | Versus positive-only |
| --- | ---: | ---: | ---: | ---: |
| Set frequency once | 9.77–10.37 | -4% to -2% | 10.42–10.71 | -7% to -3% |
| Unchanged setter/sample | 13.53–14.61 | -25% to -16% | 15.43–18.97 | -23% to -8% |
| Changing frequency/sample | 34.38–36.53 | -11% to -8% | 35.80–36.59 | -8% to -4% |

Against the prior signed implementation, changing-frequency Debug cost improves
by 16–22% on MSVC and 15–19% on Clang. Against production, all measured positive
Debug workloads improve by 21–52%. This is a scalar oscillator result, not a
whole-model or editor frame-time guarantee.

### Release: concrete types

| Positive workload | MSVC versus positive-only | MSVC versus prior signed | Clang versus positive-only | Clang versus prior signed |
| --- | ---: | ---: | ---: | ---: |
| Set frequency once | +5% to +12% | 0% to +16% | +7% to +41% | -48% to -1% |
| Unchanged setter/sample | +12% to +20% | +15% to +20% | -10% to +25% | -38% to -1% |
| Changing frequency/sample | +2% to +24% | -1% to +18% | +7% to +25% | -34% to -16% |

For scale, the fixed positive saw costs **1.21 ns/sample on Clang**, versus
2.31 for the prior signed wrapper and 1.13 for the positive-only candidate.
On MSVC it costs **3.78 ns/sample**, versus 3.26 and 3.48 respectively.
It would be misleading to present only the Clang improvement.

### Release: opaque virtual calls

| Positive workload | MSVC versus positive-only | MSVC versus prior signed | Clang versus positive-only | Clang versus prior signed |
| --- | ---: | ---: | ---: | ---: |
| Set frequency once | +7% to +13% | +4% to +18% | +29% to +42% | +5% to +32% |
| Unchanged setter/sample | -4% to +16% | -13% to +4% | +2% to +33% | -11% to +8% |
| Changing frequency/sample | +13% to +18% | -10% to +12% | +17% to +28% | -3% to +3% |

Fixed negative frequency costs 3.33–3.77 ns/sample on MSVC and 1.36–2.46 on
Clang in the concrete Release workload. Changing negative frequency costs
8.65–9.05 and 4.89–7.03 respectively. Both directions are supported in the
default candidate; the general double integrator is not called as a fallback.

The remaining Release penalty needs further work before calling positive
performance preserved. Scalar timings at these scales are sensitive to code
layout, compiler decisions and system noise. All individual runs are retained;
this review does not choose a compiler-specific implementation from one result.

## Correctness and scope

The current candidate passes **18,432 fixtures / 12,616,512 checks** on each of
MSVC and Clang, Release and Debug. These cover both signs at 44.1/48/96 kHz,
FM/PWM through zero, setters through base references, phase, reset, rate changes,
zero and sub-counter-tick frequencies. Maximum error against the independent
counter-quantised interval reference is `3.02e-7`, with no overshoot or nonfinite
output in the supported domain. Ordinary audio error against the unquantised
duty request remains `1.12e-6`.

The separate general-reference suite passes 3,840 fixtures on both compilers.
The `abs(Hz) >= fs` and extreme LF/tiny-duty limitations remain open; see
[OSM-STATUS.md](OSM-STATUS.md). Extant-model review and promotion are pending.

## Reproduce and evidence

From an x64 VS developer prompt, run these sequentially:

```text
python tests/klang/check_osm.py --output build/osm-positive-check
python tests/klang/check_osm.py --debug --output build/osm-positive-check-debug
python tests/klang/benchmark_osm.py --retained --repeats 3 --output build/osm-positive-release
python tests/klang/benchmark_osm.py --retained --debug --repeats 3 --output build/osm-positive-debug
python tests/klang/benchmark_osm.py --retained --opaque --repeats 3 --output build/osm-positive-virtual
```

Add `--compiler clang-cl.exe` and use different output directories for Clang.
`--retained` reconstructs the two earlier comparison headers from
[retained source regions](osm-comparison-sources.json), checking their complete
hashes before compiling. It fails explicitly if later non-OSM core changes make
those exact headers unreconstructable.

[Retained results](osm-positive-path-results.json) contain commands, compiler
versions, source hashes, correctness output and every benchmark repetition.
Their labels `previous` and `integrated` mean the positive-only candidate and
prior signed wrapper respectively; `baseline` means production, which has known
oscillator defects. The reconstruction smoke test also passes with identical
historical header hashes. Earlier reports describe their earlier candidates.
