# SynTHX: production, V2 and reflection Saw profiles

17 September 2026. Intel Core i7-10700, Windows x64.

**Reflection is fastest in the actual SynTHX workload on both compilers, in
Release and Debug.** With held and automated controls it reduces whole-synth
render time by 14-26% relative to the production Saw and 26-45% relative to the
V2 adapter. No production header, model source or existing candidate was changed.

Follow-up: [the two separate exceptional-case fixes](OSM-SYNTHX-EXTENSIONS.md)
were subsequently measured against a fresh reflection baseline in the same model.
Neither shows a marked SynTHX slowdown, despite the earlier modulation
microbenchmark regressions.

## Implementations and comparison scope

All variants use one shared experimental core for signal-flow operators,
envelopes, controls, buffers, note dispatch, mixing and saturation. This also
provides the restored arithmetic needed by SynTHX: the production header alone
lacks the scalar-output overload its partials use. **Production in this report
means the unchanged production Saw implementation**, not the entire unmodified
production header.

A generated copy of [SynTHX.k](../../../examples/SynTHX.k) changes exactly one
declaration: `Saw osc;` becomes `BenchSaw osc;`. Everything else is preserved,
including note initialisation, random stereo assignment, envelope lookups,
per-buffer configuration and the final stereo `tanh` stage.

| Variant | Implementation |
| --- | --- |
| Production | The complete `Fast` namespace extracted unchanged from `include/klang.h` into an isolated namespace, selecting its original `Saw`. Its oscillator faults remain present. |
| V2 | The previously pinned, unchanged Farbrausch C++ `renderTriSaw` routine, with a small `Oscillator` adapter for Hz, reset and one-sample output. This does not run the original x87 assembly or the full V2 synth. |
| Reflection | Recommended `force-inline` candidate: reflection, narrow integer distances, protected phase setup and explicit inlining. Neither exceptional-case extension nor the typed-adapter experiment is included. |

Reflection/common header SHA-256:
`9a8a99d97c82e79ccaa7683f268c7abb613ec7293f9025d6ee2a2a30111dc5c7`.
Ordinary Klang operators and public virtual interfaces are used; no `final`
classes or qualified calls bypass the model's dispatch.

### Why V2 loses its earlier advantage

SynTHX evaluates each Saw through `osc >> out` within the partial's per-sample
loop. The V2 adapter therefore calls `renderTriSaw(..., 1)`. The unchanged routine
computes integration coefficients and initial transition state once per render
call: here, once per sample. Reflection caches coefficients when frequency
changes. Earlier fixed-block V2 tests amortised setup across 64 samples and could
expose a vectorisable oscillator loop.

This measures V2 adapted to the existing model's processing pattern. It does
not negate the native block renderer's earlier results. Exploiting that renderer
would need a different integration and a separately labelled model benchmark;
no such rewrite is hidden here.

## Workload and method

- 48 kHz stereo, 64-frame host buffers, one MIDI note at pitch 26 and velocity 1.
- Eleven chord tones, four harmonics, two Saws per harmonic below 440 Hz and
  three above: **96 active Saws per frame**.
- Each note slot contains 132 Saw instances. The source allocates 32 note slots,
  so 4,224 Saw objects exist, with one note active. Inactive instances are not
  counted as rendered voices. All 132 partials of the active note retain the
  model's per-buffer configuration calls.
- Held case: source defaults, pitch control .6, detune .5, minor selected,
  attack .5 seconds. Sweep: pitch 0 to 1 and detune 1 to .5, updated once per
  host buffer from a precomputed sequence.
- Seed 12345; recreate the synth for each pass; warm for 187 buffers (about
  .249 seconds), then time two seconds of audio.
- Three passes per execution, three executions per variant/configuration.
  Report the median of the three pass-medians. Rotate variant order, finish
  compiling before timing, and run configurations sequentially.
- Timed: full note processing, sweep control updates, clearing buffers, mixing,
  ADSR, stereo saturation and an output checksum. Excluded: allocation,
  construction, note-on, warm-up, audio devices, file I/O and validation statistics.
- These are **elapsed offline render milliseconds per audio second**, not an
  operating-system process CPU counter. Divide by ten for equivalent utilisation
  of one core at real time. Processing uses one thread.

| Build | Flags |
| --- | --- |
| MSVC 19.51.36257 Release | `/std:c++17 /O2 /fp:fast /MT /DNDEBUG` |
| Clang 22.1.3 Release | `/std:c++17 /O2 /fp:fast /MT /DNDEBUG` |
| MSVC 19.51.36257 Debug | `/std:c++17 /Od /fp:fast /MTd /D_DEBUG` |
| Clang 22.1.3 Debug | `/std:c++17 /Od /fp:fast /MTd /D_DEBUG` |

Both use `/EHsc`; no AVX-specific target, LTO, PGO or extra optimisation switches.
`CL` and `_CL_` are unset. This is installed stock Clang, not Klang Studio's
modified LLVM. The candidate's precise phase-setup region remains intact.
Debug includes the unoptimised model/operator path, retaining the candidate's
existing inlining annotations.

## Held controls

Milliseconds per audio second; lower is better. Savings are reductions in
elapsed render time, not increases in throughput.

| Build | Production Saw | V2 adapter | Reflection | Saving vs production | Saving vs V2 |
| --- | ---: | ---: | ---: | ---: | ---: |
| MSVC Release | 42.16 | 54.80 | **34.30** | 18.7% | 37.4% |
| Clang Release | 42.32 | 55.08 | **31.18** | 26.3% | 43.4% |
| MSVC Debug | 213.81 | 257.22 | **181.87** | 14.9% | 29.3% |
| Clang Debug | 257.74 | 303.99 | **215.78** | 16.3% | 29.0% |

## Moving pitch and detune

| Build | Production Saw | V2 adapter | Reflection | Saving vs production | Saving vs V2 |
| --- | ---: | ---: | ---: | ---: | ---: |
| MSVC Release | 44.68 | 52.95 | **35.77** | 19.9% | 32.4% |
| Clang Release | 43.12 | 58.19 | **32.29** | 25.1% | 44.5% |
| MSVC Debug | 211.48 | 250.45 | **182.70** | 13.6% | 27.1% |
| Clang Debug | 254.40 | 291.92 | **215.77** | 15.2% | 26.1% |

These are whole-synth costs, not a single-Saw cost divided out from the model.
Small held/sweep differences and occasional inversions include run variation
and changed frequency/branch patterns. Every pass median is retained; reflection
wins consistently across both workloads and all four configurations.

## Memory and output checks

| Variant | `sizeof(Saw)` | `sizeof(SynTHX::MyNote)` |
| --- | ---: | ---: |
| Production | 104 bytes | 43,904 bytes |
| V2 adapter | 64 bytes | 38,624 bytes |
| Reflection | 144 bytes | 49,184 bytes |

The table gives Release object sizes. Debug note slots are respectively 46,024,
40,744 and 51,304 bytes; Saw sizes are unchanged.
These exclude envelope/control heap storage, allocator costs, code and total
process memory. Reflection adds 5,280 bytes per note slot relative to production,
or 168,960 bytes across the preallocated 32-slot pool.

All twelve variant/build combinations rendered finite, non-silent output in both
scenarios. The host found exactly one active note and 96 active Saws. Checksums
were identical across timing repetitions for each variant/configuration.
Independent raw-float checks confirmed 192,000 finite output samples per retained
held stereo render. No normalisation, phase alignment or gain fitting was used.

| Build | V2 vs reflection residual peak | Residual RMS |
| --- | ---: | ---: |
| MSVC Release | 7.81268e-5 | 1.46343e-6 |
| Clang Release | 9.98527e-5 | 2.05304e-6 |
| MSVC Debug | 7.80821e-5 | 1.45635e-6 |
| Clang Debug | 7.81268e-5 | 1.46341e-6 |

Production audio differs, as expected from its unrepaired oscillator. These are
model-level sanity checks, not replacements for the waveform/lifecycle suite
or listening acceptance for all existing models.

## Reproduce

Run sequentially in an x64 Visual Studio developer prompt:

```text
python tests/klang/profile_synthx.py --output build/osm-synthx/msvc-release
python tests/klang/profile_synthx.py --compiler clang-cl.exe --output build/osm-synthx/clang-release
python tests/klang/profile_synthx.py --debug --output build/osm-synthx/msvc-debug
python tests/klang/profile_synthx.py --compiler clang-cl.exe --debug --output build/osm-synthx/clang-debug
```

[Runner](../../../tests/klang/profile_synthx.py),
[harness](../../../tests/klang/synthx-profile.cpp),
[retained evidence](osm-synthx-results.json). Commands, compiler identities,
source hashes, all timing repetitions, validation output and residuals are
recorded. Generated model copies, headers, executables, source/assembly listings
and held audio remain under `build/osm-synthx/`.
