# General OSM repair (retained reference)

16 September 2026. This records the earlier general repair and its measurements.
The experimental core now uses the [V2-informed signed repair](OSM-STATUS.md).
The general oscillator is preserved separately in [osm-reference.h](osm-reference.h).
Production `include/klang.h`, the supplied UE header and models are unchanged.

**CPU follow-up:** the [Farbrausch source review](V2-SOURCE-REVIEW.md) traces the
main faults to Klang's port and demonstrates a much smaller float correction.
The general repair below remains a correctness reference; its measured CPU
increase is not accepted as necessary for production. The fast implementation
and separate signed-frequency experiment now have their own documented checks
and CPU results; the full-domain checks below still apply to the reference.

## Changes

- Correct the shared 32-bit phase scale, wrapping negative/full-turn phases and
  avoiding invalid float-to-unsigned conversions. Bit conversions use `memcpy`.
- Give Triangle, Square and Pulse a genuine 50% default duty. Preserve Saw's
  exact zero-width rising edge instead of widening it according to frequency.
- Read phase before advancing it, once per sample. Replace fragile transition
  equations with the same piecewise waveform's interval mean: midpoint values
  on uninterrupted linear segments, trapezoids across slope changes, and pulse
  high/low coverage at edges. Duty has one boundary for both slopes and states.
- Handle duty 0/1, zero and negative frequency, and wrapping/full-cycle intervals
  without dividing by zero, clipping a broken result, or looping over cycles.
- Initialise default oscillators, publish the requested frequency, refresh the
  increment when the sample rate changes on the next setter call, and implement
  absolute/relative phase and reset in the OSM wrapper.
- Repair the shared fast Sine's default-frequency initialisation: previously,
  setting its initial 1000 Hz could leave its increment at zero and output silent.

The public waveform classes and model calling syntax remain unchanged. These
are corrections to audio behaviour, so existing samples can change.

## Timing and numeric contract

`set(hz)` changes frequency without resetting phase; `set(hz, radians)` sets
absolute phase and clears the relative offset. The three-argument form adds
duty; `setDuty(duty)` changes width without resetting phase. Relative phase is
in cycles, following Klang's existing relative setter convention.

An OSM output is the mean over the interval ending at the current phase, using
the current frequency and duty, then phase advances. This retains the intended
old averaging convention, including its half-sample integration delay. For
negative Hz the integration direction reverses. FM/PWM changes apply on the
next call; no interpolation of the control values over that interval is implied.
Zero Hz (or a step smaller than one counter tick) holds the point value.
`reset()` zeros the running phase and preserves OSM duty and relative offset;
the existing Sine reset convention clears both phase and offset.

The counter remains 32-bit, with a maximum step quantisation error below
`fs / 2^32` Hz. Setters and transition arithmetic use double intermediates to
avoid low-frequency cancellation; outputs remain float. Duty is clamped to
[0,1]. Nonfinite frequency behaves as a stopped oscillator; nonfinite phase
maps to zero and nonfinite duty to 0.5. Hosts must still set `fs` before
construction and call a frequency setter after changing it.

This is **sample averaging, not an ideal band-limit**. High harmonics can still
alias; the repair does not promise a new anti-aliasing algorithm. The inaccurate
band-limited labels on these four OSM wrappers have been corrected.

## Verification

[osm-contracts.cpp](../../../tests/klang/osm-contracts.cpp) uses independent
periodic antiderivatives, rather than repeating the implementation's segment
calculation. MSVC 19.51.36257 and Clang 22.1.3, C++17, Release and Debug each pass:

- 3,840 waveform fixtures and 2,183,474 checks, at 44.1/48 kHz.
- Frequency from 0.01 Hz through Nyquist and above the sample rate, both
  directions, duty endpoints/narrow pulses, absolute and relative phase.
- Default construction, reset, unchanged frequency after rate changes,
  audio-rate FM/PWM through zero, invalid-input containment and Sine checks.
- Maximum interval-mean error **3.04e-8**, with no nonfinite or out-of-range
  waveform samples in the tested cases.

At 440 Hz / 48 kHz:

| Waveform | Repaired min/max | Mean | RMS |
| --- | ---: | ---: | ---: |
| Saw | -0.99082 / 0.98951 | ~0 | 0.57210 |
| Triangle | -0.99076 / 0.99076 | ~0 | 0.57725 |
| Square / Pulse, default duty | -1 / 1 | ~0 | 0.99392 |

All 80 unchanged source files retain the prior candidate's outcomes: 72/80
compile on MSVC and 70/80 on Clang, with no new failures. Existing arithmetic,
routing and table-initialisation blockers remain separate work. The language
suite passes its 227 candidate runtime checks and literal fixtures on both
compilers. Kleine builds/links on MSVC and `--help` succeeds.

Successful sound fixtures remain finite and repeatable. The strict old/new
sample-identity gate reports Harrier differences: residual RMS approximately
7.36e-6 at 44.1 kHz and 1.21e-5 at 48 kHz. Restoring **only the old Increment**
in a diagnostic header restores exact production Harrier samples at both rates,
isolating the change to increment quantisation in its additive Sines. The gate
was not weakened or falsely reported green. Bicycle and Train use affected
oscillators and change more substantially; these are listening follow-ups.
PD comparison oscillators remain independent of OSM.

## Processing cost

Intel Core i7-10700, Windows x64, `/O2 /fp:precise`, one voice at 48 kHz; five
passes of two million samples per waveform, median times. Timing excludes
construction, allocation, audio devices and file I/O. Ranges below span the
four waveform classes; full per-waveform min/median/max values are retained.

| Workload | MSVC old -> repaired, ns/sample | Clang old -> repaired, ns/sample |
| --- | ---: | ---: |
| Configure once | 2.64-2.96 -> 3.12-3.80 | 2.09-2.42 -> 2.92-8.68 |
| Same frequency setter each sample | 2.60-2.98 -> 4.88-5.35 | 2.31-2.61 -> 3.57-4.26 |
| Vary frequency each sample | 7.66-10.39 -> 10.55-12.02 | 7.19-8.50 -> 8.23-9.78 |

Oscillator size is 128 rather than 104 bytes on these builds. No new heap
allocation is introduced. The reciprocal width is cached; uninterrupted
segments use the midpoint fast path. The repair costs more than the faulty
implementation, especially Clang's configure-once Saw/Triangle case; further
performance work should use this evidence without weakening correctness.
These scalar microbenchmarks do not establish SIMD, many-voice, or UE host cost.

## Reproduce

From an x64 VS developer command prompt:

```text
python tests/klang/check_osm.py
python tests/klang/check_osm.py --debug --output build/osm-fix/contracts-debug-msvc
python tests/klang/check_oscillators.py
python tests/klang/benchmark_osm.py
python experiments/klang/core/check_compatibility.py --output build/osm-fix/final-compatibility-msvc
python tests/klang/check.py --output build/osm-fix/final-language-msvc
python tests/klang/check_sounds.py --output build/osm-fix/final-sounds-msvc
```

Use `--compiler clang-cl.exe` and distinct output directories for Clang; run
benchmarks without other compiler/render jobs. The last command intentionally
retains its strict sample-identity failure for the explained Harrier change.
[osm-fix-results.json](osm-fix-results.json) preserves final hashes, commands,
outcomes, measurements and model residuals. Generated files stay in
`build/osm-fix/`. Promotion to production/UE remains a review step.
