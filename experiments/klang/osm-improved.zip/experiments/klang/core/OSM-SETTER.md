# Reflection setter: magnitude, caching and precision

17 September 2026. The changes are in [osm-reflected.inc](osm-reflected.inc),
the separate reflection prototype. The default experimental `klang.h` still
uses the direct bidirectional OSM; production and UE headers are unchanged.

The subsequent [four-way benchmark](OSM-FOUR-WAY.md) compares this revised
prototype with original Klang, upstream V2 C++ and the positive-only fix using
one common buffered workload.

## Changes retained

- Remove `width`; use `f` for the positive interval width throughout reflection.
- Restore `frequency != hz` and normal parameter comparisons, including the
  wrapper's frequency check in generated reflection headers.
- Calculate a 32-bit unsigned tick magnitude directly; remove the signed
  `long long` tick intermediate and its absolute-value calculation.
- Calculate `negative` once. A negative request that truncates to zero ticks
  uses the zero-frequency point convention, as before.
- Remove the cached `step` member. Reflection always stores the positive
  magnitude in `increment.amount`'s bits, so boundary calculations can read
  those bits directly. This is simpler than removing `step` from the direct
  bidirectional implementation, where the stored increment can be negative.
- Retain double `stepScale`, pending a reason to trade precision for speed.

The main changed section is:

```cpp
const float magnitude = std::fabs(hz.value);
const unsigned int ticks = magnitude < sampleRate
    ? static_cast<unsigned int>(magnitude * stepScale) : 0;
const bool negative = hz < 0 && ticks != 0;
if (reverse != negative) {
    reverse = negative;
    offset.position = static_cast<unsigned int>(breakpoint) - offset.position;
    if (waveform == &OSM::saw) {
        amplitude = -amplitude;
        rising = -rising;
        falling = -falling;
    }
}
std::memcpy(&increment.amount, &ticks, sizeof(ticks));
f = float(ticks) * tickScale;
inverseStep = f > 0 ? 1.f / f : 0;
coefficients();
```

The scalar access in `fabs(hz.value)` obtains the float magnitude explicitly;
ordinary parameter comparisons use Klang syntax again. The existing cached
rate/frequency guard remains around this code. `memcpy` preserves all 32 bits
when placing the unsigned magnitude in the existing signed `Increment` field.

## What the compiler actually does

The signed `long long` represented nearly +/-2^32 without losing the unsigned
counter's range. A separate sign does remove the need for that C++ type here.
It does not remove the float-to-integer conversion itself.

Both measured x64 Release compilers still use `cvttsd2si` with a 64-bit register
for the unsigned conversion, followed by a low-32-bit store. Their generated
unsigned-to-float conversion also uses a 64-bit integer register. Merely
spelling the source type `unsigned int` does not force 32-bit instructions.
The new setter does remove the old signed-integer negation/selection work.

The original reflection setter already evaluates the common `float(step)`
conversion once in the inspected Release code and stores it twice for `f` and
`width`. Removing `width` removes redundant storage and explicit Debug work;
it does not eliminate a second Release conversion that was already shared.

The local sign makes reuse explicit. The prior MSVC code already extracts the
sign once, but accesses the stored direction again for magnitude selection.
The cached-sign alternative simplifies that flow; a large universal gain is
not implied. Restored comparison syntax has identical inspected MSVC Release
setter instructions to the no-width version, while Debug can expose conversion
helper calls.

The tick conversion is scalar. Clang packs some slope/bias calculations using
float `mulps` in both the original and revised setters; changing the tick
intermediate does not halve those float lanes. This is not a general SIMD
benchmark across independent voices. There is no evidence here for a blanket
factor-of-two penalty from the 64-bit intermediate.

Removing `width` alone leaves x64 OSM at 112 bytes because of alignment.
Removing `step` too reduces OSM to 104 bytes and `Fast::Saw` from 152 to 144.
The 64-bit duty breakpoint remains: it represents the exact endpoint 2^32.

## Does `stepScale` have to be double?

The retained **positive-only fix already used double**. The older production
OSM had no `stepScale` member and delegated to float-based `Increment`.
These are different baselines.

Float is a viable precision trade-off, not an inherently broken oscillator.
The diagnostic changes the scale and product to float, with a clamp before
integer conversion because a rounded product must not overflow uint32.
It fails the existing `1e-5` residual checks: 43,844 failures, largest difference
`0.00025583169`, RMS difference about `1.76e-6` across the tested samples.
Those checks require the existing counter quantisation and aligned phase;
they are not listening thresholds.

The maximum short-test residual is about -72 dB relative to full scale. It is
**not** a noise floor or a bound on residuals after long phase drift. The
altered scale/product changes the integer increment slightly; that tuning
difference accumulates with time. Examples relative to the double setter:

| Rate | Requested Hz | Tick difference | Frequency difference | Relative phase after one minute |
| ---: | ---: | ---: | ---: | ---: |
| 44,100 | 440 | -1 | -0.00001027 Hz | -0.222 degrees |
| 48,000 | 440 | -1 | -0.00001118 Hz | -0.241 degrees |
| 48,000 | 1,000 | +3 | +0.00003353 Hz | +0.724 degrees |
| 48,000 | 20,000 | -42 | -0.00046939 Hz | -10.139 degrees |
| 96,000 | 440 | 0 | 0 | 0 |

At 440 Hz/48 kHz the difference is about 0.000044 cents. My assessment is that
this tuning change is negligible for the requested perceptual accuracy target.
Phase-sensitive combinations and long reference comparisons can expose it;
no listening test is claimed. A changed quantisation contract should be stated
explicitly rather than calling those strict residual failures audible defects.

The float alternative has not established a consistent throughput improvement
over the simpler double-scale setter, so retaining double currently preserves
precision without giving up a demonstrated performance gain. Float remains a
reproducible alternative if another target benefits.

## Validation and timing

The quality matrix now includes the closest float frequency below the sample
rate, in both directions, in addition to the previous zero/sub-tick, phase,
reset, rate-change and through-zero FM/PWM checks. The new matrix has 19,584
fixtures and 13,431,840 checks per run.

All six double-scale alternatives pass this matrix on MSVC 19.51.36257 and
Clang 22.1.3 in Release and Debug. The selected no-step version retains the
reflection maximum interval residual of `2.82e-7`. The float diagnostic has
the stated strict residual failures on all four builds.

Representative saw timings, ns/sample, original reflection -> revised setter:

| Build | Fixed positive | Varying positive | Alternating sign every sample |
| --- | ---: | ---: | ---: |
| MSVC Release | 3.716 -> 3.718 | 8.443 -> 8.231 | 10.691 -> 9.136 |
| Clang Release | 1.175 -> 1.135 | 5.735 -> 4.830 | 6.472 -> 5.659 |
| MSVC Debug | 10.277 -> 15.951 | 42.803 -> 55.647 | 44.649 -> 55.898 |
| Clang Debug | 10.398 -> 10.765 | 38.142 -> 41.733 | 37.282 -> 42.141 |

Debug timing, especially MSVC, has substantial run-to-run/system noise; the
archive retains every minimum/median/maximum and repetition. Do not infer that
removing a member itself caused the entire MSVC fixed-frequency difference.
Release gains are also workload-dependent; this is not a universal speedup.

There is a concrete Debug cost from the restored syntax: the MSVC no-width
setter calls only `memcpy` and `coefficients`, while the syntax-only setter
adds four `signal::operator float&` calls. The unsigned/no-step setter has
three such calls plus `fabs`; its wrapper also uses the restored comparison.
These helper calls disappear in Release. Keeping the requested syntax accepts
that current Debug implementation cost; the prototype has not been promoted
as a completed performance fix. A later review of the core conversions can
address their Debug cost without spelling `.value` throughout user code.

Measurements are one voice at 48 kHz on an Intel i7-10700, five passes of two
million samples per case, repeated twice. Release uses `/O2 /fp:precise /MD`,
Debug `/Od /fp:precise /MDd`, with compilers/builds run sequentially. They are
standalone configurations, not the full UE build. No allocations or file I/O
occur in the timed sample loop.

The comparison runner generates seven cumulative alternatives: original,
no width, restored syntax, cached sign, unsigned magnitude, no step, and the
float-scale diagnostic. Source transformations are retained in
[osm_setter_variants.py](../../../tests/klang/osm_setter_variants.py), using the
archived first reflection source rather than the changing prototype as baseline.

New timing modes exercise through-zero frequency changes and a deliberate
+440/-440 alternation every sample. All headers receive identical benchmark
source. The extra modes change compiled loop code, so compare these runs with
each other, not numerically against the earlier reflection report.

Full measurements and final verification are recorded in
[osm-setter-results.json](osm-setter-results.json).

From an x64 VS developer prompt, run compiler/build combinations sequentially:

```text
python tests/klang/probe_osm_layout.py --quality --signed --crossing --only-comparisons --repeats 2 --variants setter-original setter-no-width setter-syntax setter-cached-sign setter-unsigned setter-no-step setter-float-scale --output build/osm-setter/msvc
```

Add `--debug` or `--compiler clang-cl.exe` and a distinct output directory.
The float diagnostic is expected to fail the strict residual gate; its results
are retained as a precision experiment, not counted as a passing exact port.
