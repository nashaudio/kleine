# OSM storage, transition codes and dispatch

16 September 2026. Follow-up to [OSM-POSITIVE-PATH.md](OSM-POSITIVE-PATH.md).
Each alternative is generated separately by
[probe_osm_layout.py](../../../tests/klang/probe_osm_layout.py).
**No runtime change from these trials has been promoted to the experimental
core.** Its transition encoding now has explanatory comments. Production and
UE headers are unchanged.

The subsequent [phase-reflection prototype](OSM-REFLECTION.md) tests completely
specialised forward/backwards routines and a waveform identity that uses the
forward state machine for both signs. It is more promising than pointer
selection for concrete calls, and remains separate for review.

## Are transition codes 1 and 6 appropriate?

Yes: they follow the original V2 C++ encoding, `wrap:old_up:new_up`.
Here, “up” means **phase is below the breakpoint**, regardless of the direction
of travel. It does not necessarily mean the output is increasing over time.

| Code | Bits | Start region | End region | Wrap | Meaning |
| ---: | --- | --- | --- | --- | --- |
| 0 | `000` | Down | Down | No | Within falling section |
| 1 | `001` | Down | Up | No | Cross peak backwards |
| 2 | `010` | Up | Down | No | Cross peak forwards |
| 3 | `011` | Up | Up | No | Within rising section |
| 4 | `100` | Down | Down | Yes | Cross both boundaries |
| 5 | `101` | Down | Up | Yes | Cross zero forwards |
| 6 | `110` | Up | Down | Yes | Cross zero backwards |
| 7 | `111` | Up | Up | Yes | Cross both boundaries |

For a midpoint breakpoint, moving from phase `0.625` to `0.375` produces `001`;
moving backwards from `0.125` through zero to `0.875` produces `110`.
V2's forward-only algorithm calls those combinations invalid because they
cannot occur during forward travel. Adding backwards travel makes them valid;
none of the original codes is renumbered.

The wrap calculation must also change. If `M = 2^32` and the backwards step has
magnitude `d`, its stored increment bits are `M-d`. A backwards interval wraps
when its ending phase is at least `M-d`. Thus the current implementation uses:

```cpp
wrapped = (end < unsigned_increment_bits) != reverse;
```

This preserves the meaning of bit 2 for both overflow and underflow. Adding the
two case labels without changing the forward-only wrap test would be wrong.

The stored `state` has two history bits; the returned transition code has three.
`sync()` recomputes the starting region when configuration changes, so “start”
refers to the averaging interval being evaluated. A packed direction flag must
survive the history update and be translated into the wrap bit on return. It
cannot simply be ORed into the original expression, whose `& 3` removes it.
The `folded-state` prototype implements that translation and passes the signed
quality suite. This argument concerns intervals shorter than one cycle;
multi-cycle FM remains OSM-01.

## Does numerical case order help?

The isolated `numerical-order` variant orders both switches `0,1,2,3,4,5,6,7`.
It passes the signed quality suite with both compilers in Release and Debug.
There is **no consistent measured speed benefit**. Both Release compilers use
indexed dispatch for these dense codes; textual order does not impose a linear
sequence of eight comparisons. It can still change the placement of case bodies.

Representative fixed positive saw costs:

| Build | Existing order | Numerical order |
| --- | ---: | ---: |
| MSVC Release | 3.78 ns/sample | 3.78 ns/sample |
| Clang Release | 1.21 ns/sample | 1.21 ns/sample |
| MSVC Debug | 10.59 ns/sample | 10.20 ns/sample |
| Clang Debug | 10.70 ns/sample | 10.51 ns/sample |

Other Debug cases move in both directions. Numerical order is reasonable for
reading the bit-pattern table, but is not established as an optimisation.

## 64-bit arithmetic and narrowing

The signed step before wrapping spans nearly `-2^32` to `+2^32`. A signed
32-bit integer cannot represent that domain, so the present setup uses
`long long`. The final phase representation needs only its low 32 bits.
In the inspected MSVC Release code, conversion from double uses `cvttsd2si`
into a 64-bit register; storing the low 32 bits performs the narrowing. There
is no separate expensive “64-bit to 32-bit conversion” instruction.

The `unsigned-setup` variant computes an unsigned magnitude first and derives
the wrapping bits separately. It passes the accuracy suite, but does not give
a consistent throughput improvement. Changing arithmetic in `set()` cannot
directly explain a loop that sets frequency only once outside the timed region.

There is another 64-bit issue in the sample loop: the breakpoint can equal
`2^32` for duty 1, and expressions such as `2^32-end` use wider integers. MSVC
emits general unsigned-64-to-float conversion handling for some of these bounded
distances. The `bounded-distances` variant expresses valid smaller/signed ranges
explicitly and removes that handling. It passes the quality tests but has not
produced a consistent measured speed gain. Fewer instructions alone are not a
guarantee of lower elapsed time.

## Why the longer phase addition? Why retain `carry`?

`offset += increment` calls `Phase::operator+=`, whose body is the same unsigned
addition used directly in `tick()`. The longer spelling was introduced to avoid
that extra helper call in an unoptimised build. The isolated Debug runs show
roughly 0.7–1 ns/sample extra in the fixed-saw case with the operator. Other
workloads are noisier; there is no established Release advantage to the longer
spelling. The operator remains valid and is preferable syntax when this small
Debug cost is acceptable.

Inlining the `carry` expression produces **identical inspected Release
instruction text** for the saw routine on both MSVC and Clang. It is a local
temporary, not part of the object. Debug timings move slightly in both directions.
Its presence does not explain the sizeable Release differences.

## Object size, packing and registers

Measured x64 sizes; “reorder” uses ordinary member alignment, not packed or
potentially unaligned storage:

| Variant | `sizeof(OSM)` | `sizeof(Fast::Saw)` |
| --- | ---: | ---: |
| Current | 112 | 152 |
| Byte-sized State alone | 104 | 144 |
| Reordered members alone | 104 | 144 |
| Byte-sized State plus reordering | 96 | 136 |
| Direction folded into state | 104 | 144 |
| Folded direction plus reordering | 96 | 136 |
| Local `stepScale` | 96 | 136 |
| Float `stepScale` | 104 | 144 |
| Remove cached `f` and `width` | 104 | 144 |
| Derive `step` at boundaries | 104 | 144 |

Packing does reduce memory use, but it does **not** consistently improve CPU
cost. For example, the packed-byte variant's fixed Clang pulse was slower in
the repeated concrete-type trial. Folding direction into the state improved
MSVC's fixed saw from about 3.76 to 3.30 ns/sample, while slowing Clang's saw
from about 1.20 to 2.69. It is a useful prototype, not a universal win.

Register pressure depends on values simultaneously needed by the generated
code, rather than the total bytes in the C++ object. Cold configuration fields
need not occupy registers while samples are processed. A byte-sized value may
still occupy a full register and require extension/masking instructions.
Conversely, the separate direction load does participate in the ordinary
sample calculation and can change register allocation. Its mere existence
does not establish one fixed percentage overhead.

## Which values need to persist? Does `stepScale` need double?

- Phase, phase offset, breakpoint and history are persistent oscillator state.
- Cached frequency/rate avoid repeated setup; `stepScale = 2^32 / sampleRate`
  avoids a double division whenever frequency changes.
- The duty reciprocals and linear slopes/biases make ordinary samples cheap.
  Moving them into sample-local calculations would give up that explicit saving.
- `f` and `width` can be derived when needed. The `fewer-caches` variant removes
  them and passes, but does not show a consistent CPU benefit.
- A local `stepScale` also passes and saves space, but recomputes the division
  during FM. Its changing-frequency Debug cases are slower, as expected.

Float `stepScale` is technically possible if a different frequency-quantisation
contract is accepted. It does not retain the current full-counter accuracy.
The tested float-product version fails 43,816 checks, with maximum sample error
about `0.000256`; using a double product with the float coefficient still fails
the existing accuracy target. These are measured differences, not a claim of
audibility. There is no demonstrated CPU gain sufficient to justify adopting
that precision change. The earlier positive-only candidate also caches a double
scale, so this is not a new cost unique to signed support.

## Is `step` merely an unnecessary precast?

It is the **magnitude**, while `increment.amount` stores wrapping bits. For a
negative 100-tick increment, casting the stored amount to unsigned gives
`2^32-100`, not `100`. Also, a positive frequency above half the sample rate can
have its high bit set: `abs(increment.amount)` is not a valid general substitute.

The two tested alternatives remove the member and compute the magnitude only
inside boundary cases. The second exploits the transition code itself:

- Cases 2/5 imply forward travel: use the unsigned increment bits.
- Cases 1/6 imply backwards travel: subtract those bits from unsigned zero.
- Cases 4/7 can occur in either direction, so use the cached direction.

Both pass all 18,432 fixtures on both compilers, Release and Debug, and reduce
OSM by 8 bytes after alignment. Neither gives a consistent speed improvement.
For example, the fixed Clang saw stays at about 1.20–1.21 ns/sample and the MSVC
saw at about 3.74–3.77. Debug results are also mixed. Most 440 Hz samples use
ordinary branches that never load `step`; removing it cannot save a load on
those samples. Boundary density at other frequencies can change the trade-off.

## Selecting forward/signed processing with a function pointer

The `pointer-split` prototype does exactly this: construction selects the
forward routine; `set()` changes the existing waveform pointer when the
quantised direction changes. The forward routine has no runtime reverse test.
Negative frequencies select the complete signed routine. No new public type or
second per-sample function pointer is required. Both signs, resets, phase
changes and FM/PWM through zero pass the quality suite.

However, the concrete waveform classes must now call through that pointer;
their current direct calls otherwise permit inlining. Results depend on the
calling context. Representative fixed positive saw results:

| Context | Current | Pointer selection |
| --- | ---: | ---: |
| MSVC Release, concrete | 3.76 | 3.78 |
| Clang Release, concrete | 1.20 | 2.52 |
| MSVC Release, virtual caller | 4.45 | 3.76 |
| Clang Release, virtual caller | 4.18 | 3.35 |
| MSVC Debug, concrete | 10.21 | 12.34 |
| Clang Debug, concrete | 11.20 | 13.76 |

Values are ns/sample. The virtual-call improvement makes this a worthwhile
retained option. It is not a default zero-overhead solution: concrete Clang and
Debug regress, and changing-frequency virtual workloads can also get slower.
A direct branch between specialised routines is retained as `branch-split` for
comparison; its results also depend on compiler and workload.

## Evidence and reproduction

[osm-layout-results.json](osm-layout-results.json) retains 16 runs, including
initial screens, repeated comparisons, quality results, sizes, commands, hashes,
and instruction excerpts. Release follow-ups use three repetitions of five
two-million-sample passes; Debug uses two repetitions. Initial screens use one.
The benchmark is one voice at 48 kHz, fixed 440 Hz or varying positive frequency
around 440 Hz. Quality checks cover both signs and 44.1/48/96 kHz. Compile options
are the same standalone `/O2` and `/Od` settings documented in the earlier review.

These short timings have visible system/code-layout noise. Small percentages,
or isolated outliers, are not sufficient grounds for promotion. The assembly,
accuracy results and direction of repeated changes are considered together.
Runtime code remains unchanged; only the enum explanation was added afterwards.
The exact tested core is retained as `bidirectional-base` in
[osm-comparison-sources.json](osm-comparison-sources.json).

From an x64 VS developer prompt, run compiler/build combinations sequentially:

```text
python tests/klang/probe_osm_layout.py --quality --repeats 3 --variants control numerical-order derived-step pointer-split --output build/osm-probes/release
python tests/klang/probe_osm_layout.py --debug --quality --repeats 2 --variants control numerical-order derived-step pointer-split --output build/osm-probes/debug
```

Add `--compiler clang-cl.exe` and distinct output directories for Clang.
For the exact pre-comment base, reconstruct retained headers with
`benchmark_osm.py --retained` and pass its `headers/bidirectional-base/klang.h`
to this runner's `--header` option. Alternate headers, logs, assembly and
executables remain under `build/`; useful variant-generation source is retained.
