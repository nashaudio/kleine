# OSM status: integrated behaviour and outstanding work

## Working production: 17 September 2026

`include/klang.h` now contains the **combined reflection OSM**. This is the
working production version requested by Chris; the old header is retained in
`baselines/production-2026-09-17/klang.h`. The external UE and Studio source
trees have not been changed. See [promotion evidence](OSM-PROMOTION.md).

| Item | Working production status |
| --- | --- |
| Signed frequency / FM through zero | Implemented through phase reflection. |
| OSM-01: multi-cycle frequency | Implemented; full-cycle mean plus partial-cycle integration. |
| OSM-02: fractional/tiny duty | Implemented, including combined multi-cycle cases. |
| General double integrator | Test reference only; absent from the production sample path. |
| Public oscillator syntax and overrides | Preserved; no public `final`. |
| OSM-03: model impact | Compile/render comparison complete; Chris accepts all six exported Flanger/Expression/FM2 pairs as NIPD. Numerical differences in these fixtures need no further investigation; existing compilation gaps remain separate. |
| OSM-04: performance | SynTHX remains strong; isolated audio-rate modulation has material costs, up to 2.32x the reflection baseline in the measured Release cases. Optimisation remains useful. |

Correctness passes 23,093,220 checks per build on MSVC and Studio Clang 14.0.6,
Release and Debug. Phase still uses a quantised 32-bit increment. These are
sample-averaged oscillators, not an ideal band-limiting algorithm. Promoting
the tested correction does not claim every old model will sound unchanged.

The default `experiments/klang/core/klang.h` is an older direct bidirectional
candidate, **not** this replacement. The historical notes below refer to that
earlier candidate and successive experiments; their pending/open statements
do not describe the current production status.

## Historical investigation, before promotion

16 September 2026, following Chris's clarification that robust negative
frequency is required for FM. **All changes here are still experimental.**
Production `include/klang.h` and the external UE/game header are unchanged.

17 September: [compiler/code-generation review](OSM-CODEGEN.md) now distinguishes
MSVC dispatch, Clang vectorisation and precision-sensitive phase setup. Performance
defaults are `/fp:fast /MT` (Debug `/MTd`), as requested for Klang Studio. The new
reflection candidates remain separate; mixed MSVC/Debug timings prevent a blanket
performance recommendation.

The [typed OSM investigation](OSM-TYPED.md) preserves public subclassing and
overrides, and retains the concrete oscillator type through configuration.
It fixes one inline-routing ambiguity in the prototype, but measured frontend
performance remains mixed. No public class or method has been made `final`.

The subsequent [multi-cycle extension](OSM-EXTENSIONS.md) passes the expanded
correctness suite but slows ordinary fixed-frequency MSVC Release processing
by 11-16%. Chris's performance gate stopped the work there: the extension is
retained separately, unpromoted, and fractional-duty work was not started.

Chris subsequently requested [fractional-duty support alone](OSM-FRACTIONAL-DUTY.md).
It passes continuous-duty accuracy checks, including sub-counter-tick duties,
on MSVC/Clang Release/Debug. Ordinary pulse PWM is 32-35% slower on MSVC and
42-44% slower on Clang Release, so that candidate also remains separate and
unpromoted. It contains no multi-cycle code.

The [SynTHX whole-synth profile](OSM-SYNTHX.md) compares the production Saw,
unchanged V2 C++ kernel through a Klang adapter, and recommended reflection
candidate in the same 96-active-Saw model. Reflection is fastest in MSVC/Clang
Release/Debug, with held and moving controls: 14-26% less render time than the
production Saw. This supports that candidate for this actual model; it does
not remove the exceptional-case limitations or promote a core header.

The subsequent [separate-fix SynTHX test](OSM-SYNTHX-EXTENSIONS.md) finds no marked
whole-model slowdown from either existing fix on MSVC/Clang, Release/Debug.
This supports their cost in that per-buffer-control workload; audio-rate FM/PWM
regressions remain a separate constraint. No combined version was tested.

The [native Studio Clang 14.0.6 SynTHX run](OSM-SYNTHX-CLANG14.md) repeats all five
variants through `klang.dll`, Release and Debug. Reflection takes about 26% less
render time than production in Release and 15% less in Debug. Both fixes stay
close in this workload. The DLL uses Windows GNU/libc++ and its bundled runtime,
so comparison with the earlier clang-cl results changes more than LLVM version.

Chris then requested [both fixes together](OSM-COMBINED.md). The combined
reflection candidate passes 23.1 million correctness checks per build on MSVC
and Studio Clang 14.0.6, Release/Debug, including interactions between tiny duty
and multi-cycle signed frequencies. Fresh SynTHX profiles show no marked cost:
MSVC Release improves 6–9%, while the largest slower median is Clang Release
moving controls at +3.2%, within overlapping execution ranges. This is now an
implemented and tested combined candidate; production and the default
experimental header remain unchanged. Audio-rate modulation cost and broader
model impact remain separate follow-ups.

## What is active?

| Item | Current status | In the game? |
| --- | --- | --- |
| V2 float state machine | In the experimental replacement `klang.h`. | No. |
| Negative frequency / FM through zero | Now integrated into the ordinary experimental `Fast::Saw`, `Triangle`, `Square` and `Pulse`; no extra include or opt-in type is required. | No; awaiting core promotion and model review. |
| General double integrator | Available in `osm-reference.h` as an explicitly selected reference implementation. It is not included or called by the default oscillators and there is no automatic fallback. | No. |
| Multi-cycle frequency and tiny-duty rounding | Both fixes are implemented together in `osm-combined.inc`, passing the expanded correctness suite and SynTHX performance check. Per-sample modulation cost remains to be reviewed for the combined version. | No; the combined candidate is experimental. |

The previous report called signed support an experiment because it was genuinely
separate at that point. Chris's requirement now makes it part of the default
candidate. `osm-signed.h` is retained only as the historical integration
prototype/comparator; users of the experimental core do not need it.

```cpp
klang::optimised::Pulse pulse;
pulse.set(-440, 0, 0.25f); // Signed Hz, absolute phase in radians, high duty.
```

## Frequency scope: do not conflate these cases

The integrated oscillators support `abs(Hz) < fs`, where `fs` is the sample rate,
including negative Hz, stopping, restarting, and FM through zero. At 48 kHz,
that means frequencies strictly between -48,000 and +48,000 Hz. This is a
numerical domain, not a claim that above-Nyquist signals are free of aliases.

At or above one cycle per sample (`abs(Hz) >= fs`), the default currently holds
phase and outputs the point value. That prevents invalid arithmetic but is
**not correct rendering of that FM request**. Such wide FM can reach this case,
so it remains an open correctness/design item before claiming unrestricted FM.
Nonfinite frequency is also contained by holding phase.

The general reference handles signed and multi-cycle intervals. It is on the
substitute bench, in Chris's terminology: executable and tested, but it does
not enter the normal processing path. We have not accepted its CPU cost as an
automatic default solution.

## Outstanding work

- **OSM-01: multi-cycle frequency handling — open.** Evaluate a bounded fast
  treatment or a selected fallback for `abs(Hz) >= fs`, with FM across that
  boundary. Keep setup/dispatch costs visible. The current hold behaviour is
  provisional containment, not a permanent API decision.
- **OSM-02: low-frequency/tiny-duty resolution — open, planned repair
  investigation.** The 32-bit duty breakpoint rounds away a fractional counter
  tick. Retain that fraction in configuration and investigate applying it only
  to boundary calculations, so the common sample path stays inexpensive.
  The [first isolated implementation](OSM-FRACTIONAL-DUTY.md) passes the
  continuous-duty reference but regresses ordinary FM/PWM performance.
  A low-overhead integration remains unresolved; the tested repair is retained.
  No decision has been made to waive the issue on perceptual grounds.
- **OSM-03: extant-code impact — pending.** Review existing examples, sounds,
  and Farnell models against the candidate, including their FM ranges, before
  production/UE promotion. Previous unsigned/general comparisons are historical
  evidence, not a pass for this version.
- **OSM-04: positive-frequency Release cost — open before promotion.** The
  direct bidirectional state machine improves Debug and Clang concrete-type
  throughput over the prior signed wrapper, but some MSVC and virtual-call
  Release cases regress. It has not preserved positive-only performance.
  Measure both Debug and Release; see [current CPU evidence](OSM-POSITIVE-PATH.md).

OSM-02 is not the original transition-spike bug returning. The recorded extreme
case is a 0.001 Hz pulse with duty `1e-6` at 96 kHz: roughly one 1 ms pulse every
1,000 seconds. A sub-counter-tick shift of about 0.23 microseconds produces a
0.04397 sample-value difference at an edge, with no overshoot. This describes
the reproduced limit; it does not establish perceptual acceptability.

## Integration and verification

The default classes now use a direct bidirectional float state machine. Two
formerly unused transition codes describe backwards crossings; ordinary samples
retain the cached forward-path formulas. Direction and coefficients are cached
in `set()`. There is no phase/duty-mirroring wrapper or per-sample pulse inversion.
All classes share the same duty setter, including calls through `Osm&`; it no
longer needs an override. Public calling syntax is unchanged.

The default quality suite now covers both signs, FM/PWM through zero, relative
and absolute phase, reset, rate changes, virtual setter dispatch, positive and
negative zero, and steps either side of one counter tick. At 44.1/48/96 kHz:

- MSVC 19.51.36257 and Clang 22.1.3, Release and Debug: **18,432 fixtures and
  12,616,512 checks pass per run**.
- Maximum interval error against the counter-quantised waveform: `3.02e-7`.
  Ordinary audio comparison against the unquantised requested duty: `1.12e-6`.
- No nonfinite samples or overshoot in the supported-domain checks.
- The separate general-reference suite still passes 3,840 fixtures on both
  compilers; it is not substituted into the default suite.

## Current CPU review

The [four-way comparison](OSM-FOUR-WAY.md) measures original Klang, upstream V2
C++, the positive-only fix and current reflection in one buffered workload.
It records all four waveforms in MSVC/Clang Release and Debug. Reflection is
close to positive-only in several MSVC cases but has material Clang Release
overhead in others; calling context remains part of OSM-04.

The [reflection setter follow-up](OSM-SETTER.md) simplifies that separate
prototype, including unsigned magnitude conversion and removal of redundant
state. Its precision discussion distinguishes strict comparison failures from
likely perceptual significance. The default header remains unchanged.

The latest [phase-reflection prototype](OSM-REFLECTION.md) removes direction
selection from sample processing while supporting both signs. It passes the
full quality suite on both compilers in Release and Debug and improves fixed
Release throughput, with mixed changing-frequency results. It remains a
separate candidate in `osm-reflected.inc`; the default described above is
unchanged. OSM-04 remains open.

The [storage/dispatch follow-up](OSM-LAYOUT.md) records isolated tests of member
packing, direction encoding, step/scale caching, case order and function-pointer
selection. Several save space or help particular workloads; none is promoted as
a universal CPU improvement. The current enum now explains its bit encoding.

The [positive-frequency and Debug review](OSM-POSITIVE-PATH.md) supersedes the
previous signed-wrapper timings. The current candidate explicitly removes
unnecessary wrapper calls and caches configuration for Debug as well as Release.
On both compilers its measured positive Debug workloads are faster than the
positive-only and prior signed implementations.

Release is mixed: Clang concrete-type processing improves substantially over
the signed wrapper, but some MSVC and opaque virtual-call cases get slower.
Against the positive-only candidate, fixed positive Release processing remains
5–12% slower on MSVC and 7–41% slower on Clang. There is no blanket 6% or
zero-overhead claim. OSM-04 remains open before promotion.

The full review gives timings, compiler options, all comparison baselines and
reproduction commands. [Current evidence](osm-positive-path-results.json)
retains six benchmark configurations and six correctness runs, with source
hashes and all repetitions. [Earlier signed results](osm-signed-results.json)
describe the superseded wrapper. The general reference remains separate.
