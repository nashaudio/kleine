# V2-informed fast oscillators

**Historical positive-only stage:** negative-frequency support has since been
integrated into the default experimental oscillators. See [current status,
remaining fixes and updated CPU results](OSM-STATUS.md). The domain table and
measurements below describe the preceding positive-only candidate.

16 September 2026. Implemented in the experimental [klang.h](klang.h).
Production `include/klang.h`, the UE header, PD primitives and models are
unchanged. Review of the impact on existing examples/sounds is deliberately
the next stage; earlier model-comparison results describe the earlier header.

## Accuracy goal

Chris's "pretty good" means perceptually useful, high-quality DSP with excellent
performance, not mathematically exact waveforms. Keep the efficient minimax Sine
and V2's useful sample averaging. Fix large spikes, wrong duty/phase, unstable
transitions and lifecycle mistakes; do not replace those algorithms merely
because their approximation or alias rejection is imperfect.

The new check allows absolute numerical error up to `1e-5` of full scale against
the intended box-averaged waveform. This is an engineering guard against defects,
not a universal audibility threshold or an ideal-band-limiting requirement.
The measured errors are substantially smaller. Listening remains the measure
of whether the retained waveform character is desirable.

## Implementation

The [V2 source audit](V2-SOURCE-REVIEW.md) identified port defects rather than
a need to replace the underlying oscillator state machine. The core now uses
its six transition cases and **float arithmetic throughout sample processing**:

- Read phase before advancing it. Use the corrected full-cycle phase scale,
  half-duty defaults and one consistent breakpoint for shape and transitions.
- Cache slopes and biases, so a sample wholly within a segment needs one
  conversion, multiplication and addition after selecting its state.
- Express corner integrals in a factored form that avoids subtracting almost
  equal large terms. Convert short distances from integer counter space, instead
  of throwing away nine bits before computing them. This repairs the low-Hz
  and narrow-duty cases without a general double integrator in the sample loop.
- Represent the duty endpoint 1 explicitly. Zero Hz holds the waveform's point
  value; duty 0/1 is supported without division by zero or output clipping.
- Keep relative phase in the effective counter when it changes, avoiding a
  second phase addition per sample. Reset, absolute phase and sample-rate refresh
  on the next setter call retain their tested contracts.
- Cache the rate-to-counter scale for frequency updates. It uses double only
  during configuration; changed Hz needs multiplication, not another division
  by sample rate. Counter quantisation is about `fs / 2^32` Hz. Multiplication
  by the cached scale can differ from direct division by one counter tick.
- Give the known Saw/Triangle/Square/Pulse classes direct waveform calls, so the
  compiler need not recover the target from a stored member-function pointer.
  Generic `Osm` retains its existing waveform constructor and dispatch.

No allocation is added. Oscillator size is 136 bytes on these x64 builds, versus
104 in production and 128 in the general repair. The Sine polynomial, its sample
loop and the shared `Increment` implementation are unchanged **in this step**.
The preceding shared phase/startup repairs remain in the experimental header.

## Supported domain and separate experiments

| Implementation | Frequency domain | Purpose |
| --- | --- | --- |
| Experimental core `Fast::Saw/Triangle/Square/Pulse` | `0 <= Hz < fs` | Fast common implementation, including stopped/LFO operation and duty endpoints. |
| [osm-signed.h](osm-signed.h), `Fast::signed_frequency::*` | `abs(Hz) < fs` | Opt-in signed-frequency prototype, including FM through zero. |
| [osm-reference.h](osm-reference.h), `Fast::reference::*` | Signed Hz, including one or more cycles per sample | Preserved general integrator; broader correctness reference and exceptional-case implementation. |

Neither extra header is included by `klang.h`. Negative or at/above-rate Hz in
the fast core currently holds phase and outputs the point value; it is explicit
provisional containment, **not** correct rendering of those requests. The public
frequency still reports the requested value. Nonfinite Hz likewise holds phase.
The signed prototype holds at/above-rate requests. Do not interpret a containment
test as validating those frequencies. Frequencies above Nyquist but below `fs`
are numerically supported; that does not make their aliases inaudible.

The signed prototype mirrors phase and duty when direction changes. A mirrored
triangle retains its value; a mirrored pulse also inverts polarity. Counter-space
complements preserve very narrow duty intervals. This handles negative frequency
without duplicating sample state or adding the general integrator, but its
configuration and pulse-sign costs remain separate from the common core.

```cpp
#include "osm-signed.h" // experiment only; klang.h alone does not opt in
klang::Generators::Fast::signed_frequency::Pulse pulse;
pulse.set(-440, 0, 0.25f); // Hz, radians, high-duty fraction
```

The preserved general reference still passes the original strict contracts,
including multi-cycle intervals. We have not added automatic fallback or its
dispatch cost to the fast core. The signed prototype is a promising integration
candidate; multi-cycle behaviour can remain a separate choice for now.

## Verification

MSVC 19.51.36257 and Clang 22.1.3, C++17, Release `/O2 /fp:precise` and Debug
`/Od /MDd /D_DEBUG`: all twelve profile/compiler/build combinations pass.

| Profile | Fixtures per run | Checks per run | Worst absolute interval error |
| --- | ---: | ---: | ---: |
| Fast | 9,216 | 6,567,924 | 2.82e-7 |
| Signed prototype | 18,432 | 12,583,488 | 3.02e-7 |
| General reference | 3,840 | 2,183,474 | 3.04e-8 |

The fast and signed runs cover 44.1/48/96 kHz, zero and 0.001 Hz through just
below one cycle/sample, tiny duty widths and exact endpoints, phase at corners,
default construction, frequency changes, reset, relative/absolute phase, rate
changes, FM/PWM, and containment of unsupported input. The signed run adds both
directions, through-zero FM and negative-phase lifecycle checks. No nonfinite
samples or overshoot in the supported-domain fixtures; measured peak is 1.
Fast RMS numerical error is `4.18e-8` of full scale.

Those fast/signed errors compare against the waveform with its **32-bit
breakpoint**, matching the counter-based contract. A separate check against the
unquantised requested duty, for audio frequencies from 20 Hz and ordinary duty
widths 0.001-0.999 (plus exact endpoints), finds worst error `1.12e-6` and also
passes the `1e-5` limit. We do not equate counter accuracy with infinite control
resolution.

An extreme case remains: a 0.001 Hz pulse with duty `1e-6` at 96 kHz has a
`0.04397` sample-value difference at a transition relative to the unquantised
request. One cycle lasts about 1,000 seconds and the high pulse about 1 ms;
rounding its breakpoint by less than one counter tick can shift the edge by
about 0.23 microseconds. This is a control-resolution limit, not an overshoot or
unstable integrator, and is recorded rather than declared inaudible. At zero Hz,
a point exactly at a rounded discontinuity also follows that rounded breakpoint.
The general reference keeps continuous double duty; a separate fractional
breakpoint correction is another possible future fix if this use case matters.

Expected values use independent periodic antiderivatives in
[oscillator-reference.h](../../../tests/klang/oscillator-reference.h). The existing
strict `2e-6` general test is retained; it was not silently loosened to describe
the positive-frequency core as a full-domain replacement. It also exposes the
tiny-duty rounding differences above. The reference profile
also retains the shared Sine/phase checks. This is algorithm verification,
not a fresh pass for all extant models or a subjective listening result.

## CPU results

Intel Core i7-10700, Windows x64, one voice at 48 kHz. Each entry uses three
executions, each taking the median of five two-million-sample passes. The reported
result is the median of those three medians. All runs and min/max values are
retained in [osm-fast-results.json](osm-fast-results.json). Construction, allocation,
audio devices and file I/O are outside the measured interval; a checksum prevents
unused-output elimination. These are scalar elapsed-time microbenchmarks.

Percentage change from the **production Klang baseline**, ranges across four
waveforms; negative means faster:

| Workload | MSVC, concrete type | Clang, concrete type | MSVC, virtual call | Clang, virtual call |
| --- | ---: | ---: | ---: | ---: |
| Configure once | -8% to 0% | -52% to -23% | 0% to +3% | -30% to -8% |
| Repeat unchanged Hz setter/sample | +2% to +7% | -29% to -2% | -7% to +7% | -31% to -6% |
| Change Hz each sample | -17% to -10% | -53% to -34% | -14% to -6% | -26% to -8% |

For the ordinary inline setter workload, MSVC costs 2.71-3.16 ns/sample and
Clang 1.78-2.53 ns/sample. Fixed-frequency concrete-type costs are 3.06-3.31 ns
on MSVC and 1.13-1.87 ns on Clang. The general repair's corresponding fixed
cost is 3.53-4.23 ns and 2.91-8.68 ns respectively in this same harness.

Opaque virtual calls are compiled as a separate workload through a non-inlined
`Oscillator&` loop, avoiding concrete-type specialisation. Their results confirm
that improvements are not limited to one fully inlined loop, while showing the
remaining small MSVC regressions. Compiler inlining, code layout and scheduling
noise materially affect these tiny timings: these are not universal speedups,
a SIMD/voice-scaling result, a V2 assembly comparison or a UE host benchmark.

The separate signed prototype's negative fixed-frequency cost is 3.06-3.22 ns
on MSVC and 1.92-2.35 ns on Clang. Changing negative Hz costs 8.45-9.01 ns and
7.35-7.94 ns respectively. Full numbers, including positive-domain overhead,
are retained rather than assuming signed support is free.

## Reproduce and next review

From an x64 VS developer command prompt:

```text
python tests/klang/check_osm.py --output build/osm-v2/fast-msvc
python tests/klang/check_osm.py --profile signed --output build/osm-v2/signed-msvc
python tests/klang/check_osm.py --profile reference --output build/osm-v2/reference-msvc
python tests/klang/benchmark_osm.py --experiments --repeats 3 --output build/osm-v2/final-benchmark-msvc
python tests/klang/benchmark_osm.py --opaque --repeats 3 --output build/osm-v2/opaque-msvc
```

Add `--debug` to correctness runs, or `--compiler clang-cl.exe` with separate
outputs for Clang. Run benchmarks sequentially without competing jobs.
`--profile strict` applies the old full-domain expectations directly to the
fast core and reports the unsupported negative/multi-cycle frequencies and
tiny-duty rounding differences; it remains available as an integration diagnostic.

Next: review affected extant models and their controls, listening and timing
before deciding whether signed support belongs in the default core. The
production and UE headers have not been promoted or edited.
