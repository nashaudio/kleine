# OSM compiler settings and generated-code review

17 September 2026. Intel i7-10700, Windows x64; MSVC 19.51.36257 and clang-cl
22.1.3. These are the installed compilers, not Klang Studio's modified LLVM.

**The large gap has identifiable code-generation causes.** MSVC retains virtual
sample calls in this harness. Clang removes them and additionally vectorises the
V2 fixed saw. Reflection's constructor visibility and integer conversions prevent
it receiving the same treatment by default. Neither `/MT` nor `/fp:fast` alone
removes the gap.

The default experimental `klang.h` still contains the direct bidirectional OSM.
This investigation uses the separate `osm-reflected.inc` prototype. Production,
default experimental and UE headers remain unchanged. New candidates are generated
by [osm_codegen_variants.py](../../../tests/klang/osm_codegen_variants.py).

## Settings actually used

Earlier comparisons used `/O2 /fp:precise /MD`; Debug used `/Od /fp:precise /MDd`.
Following Chris's instructions, performance defaults now use:

| Configuration | Flags |
| --- | --- |
| Release | `/std:c++17 /O2 /fp:fast /MT /DNDEBUG` |
| Debug | `/std:c++17 /Od /fp:fast /MTd /D_DEBUG` |

Both also use `/EHsc`; neither enables `/arch:AVX2`, whole-program optimisation,
profile-guided optimisation or link-time code generation. `CL` and `_CL_` were
unset. Correctness reference builds retain `/fp:precise`; `check_osm.py --fast`
tests the candidate under fast math while keeping oracle arithmetic precise.

The local `clang-cl -###` output shows that **`/O2` maps to LLVM `-O3`**,
with loop and SLP vectorisation enabled, generic x86-64 targeting and
`-ffp-contract=on` under `/fp:precise`. MSVC's `/O2` includes `/Ob2`; MSVC has no
corresponding `/O3` level. An explicit `/Ob3` trial did not remove its virtual
sample calls or produce a consistent improvement. Different compiler pipelines
remain important even when their command-line flags have matching names.

References: [MSVC optimisation settings](https://learn.microsoft.com/en-us/cpp/build/reference/o1-o2-minimize-size-maximize-speed?view=msvc-170),
[floating-point settings](https://learn.microsoft.com/en-us/cpp/build/reference/fp-specify-floating-point-behavior?view=msvc-170),
[Clang driver options](https://clang.llvm.org/docs/UsersManual.html).

### Actual local UE 5.8.1 settings

The generated `Klang.Shared.rsp` files in `F:/Future/Future.58/Plugins/Klang/Intermediate/Build/Win64/x64`
show the following, rather than merely assuming Unreal defaults:

| Target | Runtime | Optimisation | Floating point |
| --- | --- | --- | --- |
| UnrealGame Development / Shipping | `/MD` | `/Ox /Ot /Ob2` | `/fp:fast` |
| UnrealEditor Development | `/MD` | `/Ox /Ot /Ob2` | `/fp:precise` |
| UnrealGame DebugGame | `/MD` | `/Od` | `/fp:fast` |
| UnrealEditor DebugGame | `/MD` | `/Od` | `/fp:precise` |

Their per-source response files select C++20. UnrealBuildTool's local
`VCToolChain.cs` selects static CRT only when `bUseStaticCRT` is enabled. Its
Clang path selects precise semantics and explicitly disables contraction; the
MSVC game/editor distinction above therefore must not be generalised to Clang UE
builds. Epic documents release CRT as the default even in debug builds in its
[target reference](https://dev.epicgames.com/documentation/unreal-engine/unreal-engine-build-tool-target-reference).
This repository's standalone Debug benchmark remains `/MTd`, not an imitation
of UE's DebugGame runtime.

## What the assembly shows

### MSVC: dispatch survives in the sample loop

For the concretely owned Klang saw, MSVC still emits the equivalent of:

```asm
mov  rax, [osc]             ; vtable
lea  rcx, [osc]
call qword ptr [rax+24]     ; process()
```

There is a second virtual call for frequency updates. See
`build/osm-codegen/candidate-msvc/reflection/benchmark.asm`, the `bench<Wave<Saw>>`
function (sample call at line 16064 in this retained listing).

Clang inlines these calls in the corresponding benchmark. A harness-only
`osc.Osc::process()` / `osc.Osc::set(hz)` diagnostic reduces the MSVC precise
saw fixed-block cost from 4.173 to 3.442 ns/sample and varying-frequency cost
from 9.924 to 8.390. Clang changes little. This supports dispatch/inlining as
a cause; it is not a recommendation to rewrite models with qualified calls.

### Clang V2: specialised, vectorised fixed saw

The unchanged V2 C++ routines have a small, visible initialisation path. Clang
can establish zero saw breakpoint, remove unreachable transition cases and
generate four samples together using `psrld`, `por`, `pcmpgtd` and `mulps/addps`.
The loop is visible near line 632 of
`build/osm-codegen/vector-inline-clang/v2/benchmark.asm`.

Reflection's ordinary harness constructor remains out of line. Its breakpoint,
coefficients and transition history arrive as general state; the fixed saw
retains the scalar switch loop. This is not proof that every real Klang model
will receive the same treatment: caller visibility matters.

V2 also deliberately discards nine low counter bits in `utof23`. Its remaining
speed advantage is not a free replacement for the full-resolution conversion:
the existing V2 diagnostics include nonfinite extremely-low-frequency output.

### A genuine 64-bit conversion obstacle

Reflection's `end - breakpoint` promotes to unsigned 64-bit because the
breakpoint includes the exact 2^32 endpoint. Clang emits general unsigned-64
conversion branches, although the distance in the UpDown case is below 2^32.
Narrowing the breakpoint for that subtraction removes those branches.

The ordinary falling segment also used `float(4294967296ull - end)`. Once
construction is exposed and the loop vectorises, SSE2 still needs four scalar
64-bit conversions per group. The candidate uses:

```cpp
(float(0xffffffffu - end) + 1.f) * downSlope + downBias
```

This expresses the distance using unsigned-32 arithmetic and retains the full
turn at `end == 0`. It enables packed conversion in the vector loop. It is not
bit-identical at every rounding boundary; the waveform checks below assess the
numerical effect. The setter's double `stepScale` is retained.

## Measurements and scope

Same common harness as [the four-way comparison](OSM-FOUR-WAY.md): one voice,
48 kHz, five timed passes of two million samples, alternating executable order,
two or three repetitions. Numbers are median-of-pass-medians in ns/sample.
Buffer clearing, output accumulation and checksum are included; no device,
file I/O, allocation or construction is timed. Fast math also speeds up the
checksum, so the precise/fast difference is not solely oscillator arithmetic.

### Flags alone, reflection saw

| Compiler | Static CRT, precise: fixed / varying | Static CRT, fast: fixed / varying |
| --- | ---: | ---: |
| MSVC | 4.173 / 9.924 | 3.422 / 8.740 |
| Clang | 2.792 / 8.101 | 2.025 / 7.189 |

Fixed means 64-sample calls at 440 Hz; varying means a setter and one-sample
render every sample. `/MT` alone did not consistently improve the hot loop.

### Clang construction diagnostic, fast math

| Saw implementation | Fixed 64 | Varying Hz |
| --- | ---: | ---: |
| V2 | 0.448 | 2.337 |
| Reflection, force-inline harness construction | 1.325 | 4.382 |
| Narrow distances + precise phase setup, same construction hint | 0.683 | 4.677 |

These are the paired `vector-inline-clang` results. An earlier construction-only
run measured 1.082 ns/sample, illustrating variation between builds/runs. The
ordinary construction comparison was 2.163 -> 2.025 ns/sample fixed and
6.780 -> 6.984 varying. **Do not advertise 0.683 as the default model cost.**
Triangles and pulses do not share the saw's zero-breakpoint simplification.

With ordinary construction, MSVC measured 3.658 -> 3.830 fixed and
9.786 -> 10.336 varying for the same candidate: no performance win. Debug
was mixed as well: saw fixed MSVC 14.170 -> 14.055, Clang 12.633 -> 14.832;
varying MSVC 53.420 -> 51.165, Clang 50.366 -> 49.776. These changes do not
justify promoting the arithmetic candidate as a universal improvement.

The endpoint-derived transition variant removes stored-history dependence but
adds a comparison; it did not consistently improve either compiler and remains
a diagnostic. Object size stays 144 bytes for these native Klang waveforms;
there is no extra allocation.

## Fast-math correctness

Unprotected phase setup under Clang fast math produced the wrong wrapped phase
at an exact full rotation, exposed by zero-frequency/duty-endpoint fixtures.
The `phase-precise` candidate wraps only `Fast::Phase` in
`#pragma float_control(precise, on, push)` / `pop`; waveform arithmetic and the
frequency setter retain fast math.

The independent oracle and diagnostic arithmetic are precise. Exceptional test
inputs are now constructed from bits inside that precise scope: the standard
library NaN/infinity helpers had been included under fast math and initially
invalidated six test requests. That test defect is distinct from the reproduced
phase conversion defect.

The candidate passes **19,584 fixtures / 13,431,840 checks per build** on MSVC
and Clang in precise Release, fast Release, and fast Debug. This includes
negative frequency, FM/PWM through zero, reset, phase, sample-rate changes,
near-full-turn increments and the existing invalid-frequency containment checks.
Maximum counter-reference error: precise 2.79e-7; MSVC fast 6.12e-6; Clang fast
Release 3.76e-7. Existing extreme tiny-duty and multi-cycle limitations remain
as documented in [OSM-STATUS.md](OSM-STATUS.md).

## Explicit inlining and nonvirtual calls

Following Chris's question, `force-inline` adds compiler inlining hints to the
candidate's OSM and oscillator constructors, setters, helpers and sample methods.
It uses `__forceinline` on MSVC/clang-cl, with `always_inline` spelling for other
Clang/GCC targets. Only the Windows compilers were tested. No `final` restrictions
or model syntax changes are introduced. This is broader than a recommended final
set of annotations: it establishes whether explicit hints can help.

Paired Release results, fast math/static CRT, **ordinary unmodified harness
construction**, ns/sample:

| Compiler / wave | Reflection fixed / varying | Hinted candidate fixed / varying |
| --- | ---: | ---: |
| MSVC saw | 3.752 / 9.556 | 2.744 / 7.663 |
| MSVC triangle | 3.505 / 9.686 | 2.772 / 8.940 |
| MSVC square | 3.162 / 8.623 | 2.427 / 7.153 |
| MSVC pulse25 | 3.091 / 8.190 | 2.416 / 7.248 |
| Clang saw | 2.357 / 8.440 | 0.746 / 7.158 |
| Clang triangle | 2.222 / 7.977 | 2.740 / 7.526 |
| Clang square | 1.983 / 6.576 | 1.638 / 5.685 |
| Clang pulse25 | 1.657 / 5.939 | 2.047 / 6.219 |

The hints improve MSVC's four Release waveforms in this run. Its outer sample
loop **still makes a virtual call**; hints inline the work inside the called
method. Clang exposes construction and specialises/vectorises the fixed saw.
This brings the Clang gain into a library-only prototype, without requiring the
harness constructor hint. It also worsens the fixed triangle and pulse25 cases,
so selective annotations merit further work.

Debug remains mixed: saw MSVC fixed 16.161 -> 15.779, varying 52.158 -> 56.413;
Clang fixed 13.411 -> 14.139, varying 51.881 -> 43.833. All four hinted builds
pass the full 13,431,840-check fast-math suite. These figures retain the normal
`/Od` setting; no hidden `/Ob` option was added to Debug.

**OSM is already nonvirtual.** `process()` and `set()` inherit Klang's virtual
interface. Removing their `virtual`/`override` spelling does not change that.
An explicitly qualified call bypasses dispatch, as already tested by the
`OSM_QUALIFIED` harness. Marking a concrete override `final` lets the compiler
know its implementation but forbids user subclasses from overriding it.

The longer-term compatible route is a typed, nonvirtual processing path for
concrete objects, while retaining the virtual boundary for generic Output/Sound
references. Existing `Generator::operator()` returns `Output&`, and inherited
arithmetic/conversion operators call virtual `process()`, so preserving concrete
types through the EDSL is part of that design. Merely adding another helper
inside `process()` does not remove the outer virtual call. That core redesign
has not been applied here.

Follow-up: the [typed adapter experiment](OSM-TYPED.md) now tests this boundary
with ordinary Klang expressions and subclass overrides. Concrete return types
alone do not eliminate the remaining virtual calls; public `final` annotations
are excluded by the requirement to preserve overrides.

References: [MSVC inlining](https://learn.microsoft.com/en-us/cpp/cpp/inline-functions-cpp?view=msvc-170),
[virtual functions and qualified calls](https://learn.microsoft.com/en-us/cpp/cpp/virtual-functions?view=msvc-170).

## Reproduce

In an x64 VS developer prompt, run configurations sequentially:

```text
python tests/klang/osm_codegen_variants.py
python tests/klang/compare_osm_versions.py --assembly --versions v2 reflection --output build/osm-codegen/repeat
python tests/klang/check_osm.py --fast --header build/osm-codegen/candidates/phase-precise/klang.h --output build/osm-codegen/repeat-quality
```

Add `--compiler clang-cl.exe` or `--debug` and a distinct output path. Use
`--compare-header LABEL PATH --versions reflection LABEL` for a candidate.
`--flag=/DOSM_INLINE_CONSTRUCTION` and `--flag=/DOSM_QUALIFIED` select harness
diagnostics. `--flag=/fp:precise` restores precise performance comparisons.

[Retained results](osm-codegen-results.json) contain commands, source hashes,
all waveform timings, quality summaries, driver output and UE response-file
flags/hashes. Generated headers, executable files and full assembly remain in
`build/osm-codegen/`.
