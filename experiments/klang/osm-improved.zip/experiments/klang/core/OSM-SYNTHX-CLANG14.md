# SynTHX with Klang Studio's Clang 14.0.6 toolchain

Follow-up: [both fixes combined](OSM-COMBINED.md) have subsequently been tested
on MSVC and this Clang 14.0.6 toolchain, Release and Debug.

17 September 2026. All five existing Saw variants were profiled in Release and
Debug using the local **Klang compiler DLL**, through Studio's executable launcher.
The two exceptional-case fixes remain separate.

**Reflection reduces render time by about 26% in Release and 15% in Debug versus
production.** Both fixes remain close to reflection in this model. Moving-control
Release medians are 4–5% higher with the fixes, but the execution ranges overlap;
this is not evidence of a reliably measured 4–5% penalty. Debug differences are
small and favourable. The earlier audio-rate FM/PWM concerns remain separate.

## Results

Elapsed render **milliseconds per audio second**, lower is better. Divide by ten
for equivalent utilisation of one core at real time. These are wall-clock render
measurements, not process CPU counters. The test uses **96 active Saws**.

| Saw implementation | Release held | Release moving | Debug held | Debug moving |
| --- | ---: | ---: | ---: | ---: |
| Production, broken | 41.53 | 42.40 | 219.72 | 217.10 |
| Upstream V2 C++ adapter | 59.86 | 59.08 | 269.21 | 262.34 |
| Reflection | 30.92 | 31.52 | 185.69 | 184.20 |
| Reflection + multi-cycle only | 31.92 | 33.16 | 183.84 | 181.28 |
| Reflection + tiny-duty only | 30.32 | 32.80 | 183.38 | 180.64 |

Relative to reflection:

| Separate fix | Release held | Release moving | Debug held | Debug moving |
| --- | ---: | ---: | ---: | ---: |
| Multi-cycle | +3.2% | +5.2% | -1.0% | -1.6% |
| Tiny-duty | -1.9% | +4.1% | -1.2% | -1.9% |

For perspective, the five execution medians for Release moving controls span
30.54–33.12 ms/s for reflection, 31.85–33.47 for multi-cycle, and 32.15–34.23
for tiny-duty. Full repetitions and ranges are retained in the evidence JSON.

## Which compiler and libraries?

The supplied `F:/llvm/build/klang/klang.dll` location was absent. The DLL used is
`F:/klang/build/klang/klang.dll`, alongside Studio's include files. Its SHA-256 is
`3da378aaa124e24c63b05b8f5270858617148bc5331e8f077f6ed862f2f69c86`.
It reports **Clang 14.0.6**, target **`x86_64-unknown-windows-gnu`**, POSIX threads.

`F:/klang/studio/Source/Executable.cpp` was compiled unchanged into a workspace
`klang.exe`. It loads `klang.dll`, finds its exported `main`, and forwards the
arguments, as Studio does. `CodeToolchain.h` supplies GNU-style C++17 commands.
The DLL's embedded filesystem supplies **libc++ and MinGW headers/libraries**.
This is the native Studio compiler route, rather than forcing its CL driver.

| Build | Requested benchmark options |
| --- | --- |
| Release | `-std=c++17 -fexceptions -O2 -ffast-math -static -DNDEBUG` |
| Debug | `-std=c++17 -fexceptions -O0 -ffast-math -static -D_DEBUG` |

The effective `-cc1`/linker commands were captured and confirm optimisation,
fast-math and the Windows GNU target. No extra ISA, LTO or PGO flags were used.
The benchmark explicitly requests fast math in both configurations, following
Chris's preference; this is not a claim that every option is a Studio UI default.

**`-static` does not reproduce MSVC `/MT` or `/MTd` exactly.** The generated
executables statically link the C++ library but still import Windows UCRT API-set
DLLs. Debug uses the same bundled runtime, with unoptimised model code and
`_DEBUG`; it does not use MSVC's debug CRT. Executable import lists are retained.

The previous Clang 22 measurements used the MSVC ABI/STL/runtime. This changes
more than the compiler version: ABI, standard library, runtime and conditional
`_MSC_VER` code also differ. For example, the shared core's `_controlfp_s` call
in `buffer::rewind()` is conditional on `_MSC_VER`. Cross-toolchain timing or
audio differences cannot be attributed solely to LLVM 14 versus LLVM 22.

## Workload and validation

The [original SynTHX method](OSM-SYNTHX.md#workload-and-method) is retained:
Intel Core i7-10700, Windows x64, 48 kHz stereo, 64-frame buffers, one MIDI note
at pitch 26, seed 12345, two seconds per pass after warm-up. Held controls use
pitch .6/detune .5; moving controls sweep pitch 0→1 and detune 1→.5 per buffer.
Construction, note-on, allocation, warm-up, validation and file I/O are excluded
from timing. Full synth mixing, envelopes, saturation and checksums are included.

- Release: seven passes per execution, five executions per variant.
- Debug: three passes per execution, five executions per variant.
- Tables use the median of execution medians. Variant order rotates through
  all five positions; configurations and timed processes run sequentially.
- All ten variant/build combinations passed both held and moving validations:
  one active note, 96 active Saws, finite nonzero output. Repeated checksums are
  stable for every variant/build/workload.
- Both separate fixes produce **sample-identical held audio to reflection** in
  Release and Debug. V2/reflection residual RMS is approximately `2.05e-6` in
  Release and `1.46e-6` in Debug, consistent with the preceding comparisons.
- Source and selected-header hashes were checked before and after each run;
  production, candidate and model sources are unchanged. The C++ timing harness
  is unchanged. The Python runner adds GNU-driver and all-five selection options.

SynTHX uses a zero-breakpoint Saw and per-buffer frequency configuration. It does
not exercise multi-cycle frequency increments or tiny nonzero duty inputs.
These are full-model performance and output checks, not a rerun of the expanded
exceptional-case correctness suite. V2 retains its unchanged one-sample adapter;
these numbers do not measure its native block-processing throughput.

Saw sizes are 104/64/144/160/168 bytes for production/V2/reflection/multi-cycle/
tiny-duty. Corresponding note sizes are 46024/40744/51304/53416/54472 bytes in
both builds. Note layouts differ from MSVC Release because the ABI/library differ.

## Reproduction and evidence

Build the launcher in an x64 VS developer shell, then use PowerShell:

```powershell
New-Item -ItemType Directory -Force build/toolchains/klang14
cl /nologo /O2 /MT /EHsc F:\klang\studio\Source\Executable.cpp /Fobuild\toolchains\klang14\launcher.obj /Febuild\toolchains\klang14\klang.exe
$env:PATH = 'F:\klang\build\klang;' + $env:PATH
python tests/klang/profile_synthx.py --compiler build/toolchains/klang14/klang.exe --driver gnu --all-variants --passes 7 --repeats 5 --output build/osm-synthx-clang14/release
python tests/klang/profile_synthx.py --compiler build/toolchains/klang14/klang.exe --driver gnu --all-variants --debug --passes 3 --repeats 5 --output build/osm-synthx-clang14/debug
```

[Retained evidence](osm-synthx-clang14-results.json) includes both complete run
reports, commands, compiler and launcher hashes, effective options, binary imports,
source/header hashes, repetitions, validation output and held-audio residuals.
Generated executables, dependencies, assembly and raw audio remain under
`build/osm-synthx-clang14/`. No combined fix or production promotion was made.
