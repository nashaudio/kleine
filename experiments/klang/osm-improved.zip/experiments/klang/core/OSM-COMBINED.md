# Reflection OSM with both fixes

**Promoted on 17 September:** this combined header is now the working
[`include/klang.h`](../../../include/klang.h). See the
[promotion and model comparison](OSM-PROMOTION.md) for the subsequent FM/PWM
profile, previous-header archive and remaining issues. Results below describe
the earlier combined-candidate validation.

17 September 2026. Chris requested multi-cycle and fractional-duty support
together, followed by MSVC and Studio Clang 14.0.6 tests in Release and Debug.

**Both fixes are implemented together and pass correctness checks in all four
builds. There is no marked performance penalty in SynTHX.** MSVC Release is
6–9% faster than the fresh reflection baseline. Clang Release changes by -1.5%
with held controls and +3.2% with moving controls. Debug remains close or faster.
Small differences should be read alongside the retained execution ranges.

The implementation is [osm-combined.inc](osm-combined.inc). Generate its usable
`klang.h` with `osm_extension_variants.py --variant combined`. Existing baseline
and separate-fix fragments are retained for reproducible comparison. The default
experimental header remains a historical candidate; it is not the promoted version.

## Implementation

The combined version retains the reflection state machine and merges:

- Multi-cycle integration: complete periods contribute their waveform mean;
  the existing transition cases integrate the remaining partial period.
- Fractional duty: retain the sub-counter-tick breakpoint and reflected-phase
  corrections, including in transition distances and ordinary-sample biases.

The mean and partial-period gain are applied to the corrected coefficients.
Saw/triangle crossings use the gain-adjusted peak; pulse transitions use the
gain-adjusted high/low values. The precise, non-inlined wide-frequency helper
remains confined to exceptional frequency setup. There is no general integrator
in the sample path and no new allocation or public API change. Subclassing and
overrides are preserved.

The generator applies the same bounded integer conversions, precise phase setup
and explicit inlining as the tested reflection baseline. Generated headers are
verified identical outside OSM.

| Source | SHA-256 |
| --- | --- |
| Combined fragment | `02a6b7098fd2f508daa23abc7e7c5ef46f30da5aced39d2db027159ba0ccb110` |
| Combined generated header | `1506b513f8c52464ffb3168907d06890113dba597d61a10b16738000dbd8f959` |
| Reflection baseline header | `9a8a99d97c82e79ccaa7683f268c7abb613ec7293f9025d6ee2a2a30111dc5c7` |

## Correctness

Every build passes **42,048 fixtures, 23,093,220 checks and 9,007,680 evaluated
samples**, using fast-math candidate code and an independent precise integral
reference. Tolerance is `1e-5` of full scale.

| Build | Failures | Maximum error |
| --- | ---: | ---: |
| MSVC Release | 0 | 6.124e-6 |
| MSVC Debug | 0 | 6.124e-6 |
| Clang 14 Release | 0 | 8.345e-7 |
| Clang 14 Debug | 0 | 8.345e-7 |

The combined profile enables both existing contracts: multi-cycle frequencies
and the requested duty without counter-grid rounding. Added interaction cases
cross whole-cycle boundaries while using sub-tick duty, and switch repeatedly
between positive/negative/zero/sub-tick/multi-cycle frequencies with changing
duty. Wide negative-frequency reset and relative-phase cases also use tiny duty.

Coverage includes Saw, Triangle, Square and Pulse at 44.1/48/96 kHz; positive and
negative FM, PWM, endpoint duties, duty down to `1e-12`, zero-frequency point
values, absolute/relative phase, reset, sample-rate changes, virtual control
dispatch and invalid-frequency containment. The retained phase increment remains
quantised to a 32-bit counter; the fix does not change that contract.

## SynTHX performance

Same [96-active-Saw workload](OSM-SYNTHX.md#workload-and-method): one note at
MIDI 26, seed 12345, 48 kHz stereo, 64-frame buffers, two seconds per timed pass
after warm-up. Held controls are pitch .6/detune .5; moving controls sweep pitch
0→1 and detune 1→.5 per buffer. Full synthesis, saturation, buffer clearing and
checksum are timed; allocation, note-on, warm-up, validation and I/O are excluded.

Intel Core i7-10700, Windows x64. MSVC 19.51.36257 uses `/O2 /fp:fast /MT` in
Release and `/Od /fp:fast /MTd` in Debug. Studio's Clang 14.0.6 DLL uses its
native Windows GNU/libc++ toolchain: `-O2`/`-O0`, `-ffast-math`, `-static`.
Both use C++17 and the appropriate `NDEBUG`/`_DEBUG` definition. Clang's static
bundled libraries still import Windows UCRT APIs; they do not reproduce MSVC's
CRT configuration exactly. See [toolchain details](OSM-SYNTHX-CLANG14.md).

Each configuration uses six executions per variant, alternating which runs
first. Release uses seven passes per execution; Debug uses three. Tables show
the median of execution medians, in **elapsed render milliseconds per audio
second**. Lower is better; these are not process CPU counters. Configurations
and timed processes run sequentially.

| Build | Held: baseline → combined | Change | Moving: baseline → combined | Change |
| --- | ---: | ---: | ---: | ---: |
| MSVC Release | 34.38 → 32.30 | -6.0% | 37.06 → 33.77 | -8.9% |
| MSVC Debug | 181.04 → 181.55 | +0.3% | 181.99 → 182.74 | +0.4% |
| Clang 14 Release | 30.84 → 30.37 | -1.5% | 32.04 → 33.06 | +3.2% |
| Clang 14 Debug | 182.02 → 174.92 | -3.9% | 184.63 → 179.54 | -2.8% |

Clang Release moving-control execution medians span 30.44–35.29 ms/s for baseline
and 31.00–34.36 for combined. The +3.2% headline is within overlapping ranges,
not a reliably isolated regression. All execution/pass timings are retained.

All full-model validations passed and all repeated checksums were stable. Held
audio is sample-identical to baseline in both Clang builds and MSVC Debug.
MSVC Release residual peak is `1.192e-7`, RMS `3.096e-9`.

`sizeof(Saw)` rises from **144 to 184 bytes**. Each allocated SynTHX note contains
132 Saws, adding 5,280 bytes per note, or 165 KiB over the 32 allocated note slots.
No new per-sample direction branch or memory allocation was introduced.

**Scope:** SynTHX uses a zero-breakpoint Saw and configures frequency per buffer.
The accuracy suite exercises the exceptional cases, but these performance
measurements do not exercise tiny-duty PWM or multi-cycle audio-rate FM. Earlier
modulation-cost concerns remain relevant; combined modulation throughput and
broader existing-model impact have not been re-profiled here.

## Reproduce

From an x64 VS developer shell, generate the candidate and run MSVC tests:

```text
python tests/klang/osm_extension_variants.py --variant combined --output build/osm-combined/candidate
python tests/klang/check_osm.py --profile combined --fast --header build/osm-combined/candidate/headers/combined/klang.h --output build/osm-combined/quality-msvc-release
python tests/klang/check_osm.py --profile combined --fast --debug --header build/osm-combined/candidate/headers/combined/klang.h --output build/osm-combined/quality-msvc-debug
python tests/klang/profile_synthx.py --combined --passes 7 --repeats 6 --output build/osm-combined/synthx-msvc-release
python tests/klang/profile_synthx.py --combined --debug --passes 3 --repeats 6 --output build/osm-combined/synthx-msvc-debug
```

For Clang, use the [existing DLL launcher setup](OSM-SYNTHX-CLANG14.md#reproduction-and-evidence),
add `--compiler build/toolchains/klang14/klang.exe --driver gnu` to each test
command, and replace `msvc` with `clang14` in the output paths.

[Retained evidence](osm-combined-results.json) includes commands, compiler
versions, source/header hashes, all four correctness reports, all four SynTHX
reports, repetitions, output validations and held-audio residuals. Raw generated
headers, executables, assembly, dependency files and audio stay in
`build/osm-combined/`.
