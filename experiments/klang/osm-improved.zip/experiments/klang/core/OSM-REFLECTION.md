# OSM: using forward processing for negative frequency

17 September 2026. **A tested, separate prototype; not the default experimental
OSM and not in production.** The current experimental header still uses the
direct bidirectional state machine. The readable replacement is
[osm-reflected.inc](osm-reflected.inc); the layout runner inserts it into a
generated header for testing.

**Setter follow-up:** [OSM-SETTER.md](OSM-SETTER.md) records the current fragment's
32-bit magnitude, removed `width`/`step`, restored comparison syntax and precision
assessment. The timings and sizes below describe the initial reflection version;
its exact source remains retained in the evidence archive.

## Does making `reverse` const remove its cost?

The extra `!= reverse` is the direction-dependent operation in the current
`tick()`. It normally compiles to a Boolean operation rather than a conditional
branch. Outside `tick()`, backwards boundary cases and direction-dependent
two-boundary calculations also distinguish the signed implementation.

The compiler already sees that `tick()` does not change `reverse`. Copying it
to a local `const bool` does not make its value known at compile time: each
oscillator can have a different setting. An optimiser may retain the flag in a
register or move its load outside a loop when it can prove that no intervening
call changes it. That alone does not remove the direction-dependent operation.

The `pointer-directions` prototype specialises **both** directions, with
`tick<false>()` and `tick<true>()`, and selects their waveform function in
`set()`. Each routine has its own valid transitions and no runtime direction
comparison. It passes the quality suite, but the indirect call can prevent
inlining. For the concrete Clang saw, fixed positive processing goes from
1.204 to 2.434 ns/sample; Debug also regresses on both compilers. Separating the
state machines works, but selecting them is not free in this calling context.

## A waveform identity removes the need to select a sample routine

Let `p` be physical phase in cycles, and `d` the duty breakpoint. For negative
frequency store this reflected coordinate:

```text
q = (d - p) modulo 1
```

As physical phase travels backwards, `q` travels forwards. The waveform has
these symmetries:

```text
Pulse(d - p)    =  Pulse(p)
Triangle(d - p) = -Triangle(p)
```

The asymmetric triangle uses the same breakpoint `d`; saws are its endpoint
cases. The identities apply to the interval averages used by OSM. Isolated
values at discontinuities require care for zero-length intervals.

Consequently, the prototype uses the original **forward-only state machine
for both signs**:

- Keep duty unchanged and advance internal phase by the positive magnitude.
- Pulse/square need no amplitude inversion.
- For triangle/saw, fold the inversion into the cached slopes, biases and area
  coefficients. Ordinary samples need no additional polarity multiply.
- Reflect stored phase only when the quantised direction changes. Adjust it
  when duty, absolute/relative phase or reset changes, preserving physical phase.
- A zero or sub-tick step uses physical forward coordinates and the original
  point-value convention, including exactly on a discontinuity.

`tick()` neither reads `reverse` nor calls through a new function pointer.
There are no backwards boundary cases in the sample switches. `reverse` still
exists for configuration, and an added polarity coefficient fits in existing
padding: x64 OSM remains 112 bytes, `Fast::Saw` 152 bytes.

This differs from the earlier signed wrapper: that wrapper changed duty and
inverted pulse samples. This reflection leaves duty unchanged and incorporates
triangle/saw polarity into configuration.

## Verification

MSVC 19.51.36257 and Clang 22.1.3, each in Release and Debug:

- **18,432 fixtures, 12,616,512 checks, zero failures per run.**
- Both signs, FM/PWM through zero, stops/restarts, phase controls, reset, rate
  changes and virtual setter dispatch at 44.1/48/96 kHz are covered.
- Maximum interval error against the counter-quantised reference: `2.82e-7`.
  Peak magnitude is `1.00000011921`, a float-rounding excess within the test's
  existing bound, not a claim of exact mathematical boundedness.
- Ordinary audio error against continuous requested duty remains `1.12e-6`.
  The known extreme low-frequency/tiny-duty limitation remains `0.04396756`.

This does not solve OSM-01 (multi-cycle frequencies) or OSM-02 (extreme duty
resolution). No general-integrator fallback has been added.

## Performance

One voice, 48 kHz, Intel i7-10700, concrete oscillator calls. Release uses
`/O2 /fp:precise /MD`, Debug `/Od /fp:precise /MDd`; these are standalone builds,
not a claim about the full UE build configuration. Each measurement uses five
passes of two million samples; results are medians across three Release or
two Debug repetitions. Compiler/build trials ran sequentially.

Fixed saw, frequency configured once, ns/sample:

| Build | Current +440 | Reflected +440 | Current -440 | Reflected -440 |
| --- | ---: | ---: | ---: | ---: |
| MSVC Release | 3.736 | 3.277 | 3.756 | 3.271 |
| Clang Release | 1.204 | 1.131 | 1.362 | 1.197 |
| MSVC Debug | 10.199 | 10.089 | 10.205 | 10.025 |
| Clang Debug | 10.550 | 10.510 | 10.520 | 10.030 |

The reflected Clang positive saw matches the earlier positive-only result of
about 1.13 ns/sample. That historical baseline was measured separately. Other
fixed-frequency waveforms also improve in the latest Release comparison, but
this does **not** establish zero signed-support cost for every waveform.

Changing frequency every sample has mixed results. In Clang Release, varying
positive triangle costs 6.461 -> 6.914 ns/sample and pulse 5.193 -> 5.479;
varying negative triangle costs 6.649 -> 7.105, while negative pulse improves
6.179 -> 5.527. MSVC changing-frequency cases mostly improve, with exceptions.
Debug fixed-frequency costs are similar or better, while changing-frequency
MSVC costs increase in several cases. Direction changes require additional
setter work; the timing modes vary frequency within one sign, so they do not
measure that extra crossing cost. Through-zero behaviour is correctness-tested.

These short measurements contain visible noise and code-layout effects. The
useful conclusion is structural: reflection removes per-sample direction
selection and restores the fast saw path. It is the more promising next
candidate, but setter performance and other calling contexts still merit review
before replacing the default. No listening or extant-model acceptance is implied.

## Evidence and reproduction

[osm-reflection-results.json](osm-reflection-results.json) retains all six
prototype runs, including repeated measurements, compiler commands, hashes,
quality results and exact tested OSM source fragments. The readable fragment
was extracted with only comment/indentation changes, checked for identical
executable tokens, and revalidated in all four compiler/build combinations.

From an x64 VS developer prompt, run sequentially:

```text
python tests/klang/probe_osm_layout.py --quality --signed --repeats 3 --variants control pointer-directions reflected-phase --output build/osm-reflection/msvc
python tests/klang/probe_osm_layout.py --debug --quality --signed --repeats 2 --variants control pointer-directions reflected-phase --output build/osm-reflection/debug-msvc
```

Add `--compiler clang-cl.exe` with distinct output directories for Clang.
Generated headers, executables, logs and assembly stay under `build/`.
