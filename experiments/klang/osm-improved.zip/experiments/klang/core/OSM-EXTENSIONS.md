# OSM exceptional-case extensions: stopped after step 1

**Current status:** both fixes have subsequently been combined and
[promoted to the working header](OSM-PROMOTION.md). The stopped work described
below is the earlier, separate step-1 experiment.

**Later combined implementation:** [both fixes are now implemented together](OSM-COMBINED.md),
passing MSVC/Studio Clang 14.0.6 correctness checks and SynTHX profiling in
Release/Debug. This page records the original step-1 performance gate below.

17 September 2026. Chris requested multi-cycle support first, followed by a
performance gate; fractional-duty work was conditional on passing that gate.

**Multi-cycle support passes correctness checks, but this integration causes a
marked slowdown in ordinary MSVC Release workloads. Work stopped at that gate.
Fractional-duty support was not added.** Production, the default experimental
header and the previously recommended reflection candidate remain unchanged.

Subsequent request: step 2 was then tried **without step 1**. The separate
[fractional-duty report](OSM-FRACTIONAL-DUTY.md) records passing accuracy checks
but marked modulation costs on both MSVC and Clang. Neither extension is promoted.

A later [SynTHX profile of the fixes separately](OSM-SYNTHX-EXTENSIONS.md) finds
no marked overhead in that ordinary 96-Saw model on either compiler, Release or
Debug. SynTHX configures frequency once per buffer and does not exercise these
extreme inputs; the per-sample modulation costs below remain relevant.

The [Studio Clang 14.0.6 follow-up](OSM-SYNTHX-CLANG14.md) runs all five SynTHX
variants through the native compiler DLL in Release and Debug, retaining the
two fixes separately. It also records the GNU/libc++ runtime difference from
the earlier clang-cl tests.

## Implementation tested

[osm-multicycle.inc](osm-multicycle.inc) extends the reflection OSM. The
[generator](../../../tests/klang/osm_extension_variants.py) applies the same
bounded integer distances, precise phase conversion and inlining hints as the
recommended `force-inline` control. Generated headers are in
`build/osm-extensions/headers/{control,multicycle}/klang.h`.

For a sample spanning `n + r` cycles, the output is:

```text
(n * cycleMean + r * remainderAverage) / (n + r)
```

Saw/triangle have zero complete-cycle mean. Pulse has mean `2*duty - 1`.
The original state machine advances only the residual phase and integrates
the residual interval. Scaling is folded into cached slopes, biases, peak and
pulse high/low levels; the edge formulas use the reciprocal of the full width.
Exact whole-cycle intervals output the cycle mean, including nonzero pulse DC.
The signed reflection mechanism is retained.

`wideStep` does the extra floor/remainder work only for frequencies outside the
ordinary sub-cycle range. `fmod` retains fractional phase when complete-cycle
counts exceed double's exact-integer range. No cycle-count loop, general
sample integrator, per-sample direction dispatch or heap allocation is added.
Native oscillators grow from 144 to 160 bytes on these Windows x64 builds.

### Fast-math boundary

The first version passed MSVC but failed Clang's infinity containment checks.
Clang removed a bit-based nonfinite check on a floating argument, even after
the helper body received precise arithmetic. Its declaration was in fast-math
scope. The retained implementation uses an explicitly non-inlined precise
helper taking integer input bits, avoiding those floating-argument assumptions.
This helper is reached only by exceptional setup. NaN/infinity continue to hold
the physical phase and output the point value; finite multi-cycle inputs now
render correctly instead of using that containment path.

## Correctness

`check_osm.py --profile multicycle --fast` extends the existing independent
integral suite, without changing the historical fast profile's frequency
contract. It includes:

- Frequencies immediately below/above the sample rate, exact integer cycles,
  fractional multi-cycle intervals, large cycle counts and maximum finite float.
- Both directions; FM/PWM across zero and the old supported-frequency limit.
- Phase offsets, reset, sample-rate refresh, transitions back to ordinary Hz,
  exact duty endpoints, near-zero steps and invalid-input containment.
- The existing counter-quantised duty contract. Fractional duty is deliberately
  still an unresolved issue, not silently treated as repaired.

Each build passes **29,952 fixtures / 21,286,884 checks**:

| Build | Failures | Maximum interval error |
| --- | ---: | ---: |
| MSVC Release | 0 | 6.124e-6 |
| MSVC Debug | 0 | 6.124e-6 |
| Clang Release | 0 | 3.762e-7 |
| Clang Debug | 0 | 2.794e-7 |

The existing extreme tiny-duty discrepancy remains approximately 0.04396756.
The reference/measurement arithmetic is precise; candidate arithmetic uses
`/fp:fast` except the documented setup protection.

## Performance gate

The stated working threshold was a repeatable slowdown of roughly 10% or more
in ordinary workloads, with smaller changes assessed against run variation.

Intel Core i7-10700, Windows x64, MSVC 19.51.36257, C++17,
`/O2 /fp:fast /MT`. One oscillator at 48 kHz, 64-sample scratch buffers,
five passes of 2,000,000 samples per case; median of three executions, with
control/candidate order alternated. Compiler work finished before timing.
Construction and setup before the timer, file I/O and allocation are excluded.
Buffer clearing, output accumulation and checksum are included.

The new harness exercises both ordinary controls and the extension. It uses
ordinary public `set()`, `setDuty()` and `process()` calls. No qualified calls or
`final` declarations are added. The optional frontend mode is available for
later work but was not run after the stop condition.

**Ordinary fixed 440 Hz, ns/sample:**

| Wave | Control | Multi-cycle | Change |
| --- | ---: | ---: | ---: |
| Saw | 2.699 | 3.059 | +13.4% |
| Triangle | 2.682 | 3.115 | +16.2% |
| Square | 2.334 | 2.665 | +14.2% |
| Pulse, 25% duty | 2.346 | 2.607 | +11.1% |

This is repeatable: Saw's three medians are 2.709/2.699/2.697 ns for the control
and 3.055/3.076/3.059 ns for the extension. It is not an inference from a single
outlying pass.

Other ordinary workloads also worsen; ranges across the four waveforms:

| Workload | Change in median ns/sample |
| --- | ---: |
| Unchanged Hz setter every sample | +16% to +22% |
| Positive audio-rate FM, 240-640 Hz | +23% to +55% |
| Bipolar audio-rate FM, -200 to +200 Hz | +23% to +49% |
| Audio-rate duty changes, .1-.9, fixed 440 Hz | +14% to +89% |
| Positive FM plus duty changes | +19% to +79% |

Changing-control cases have more timing spread, but the stable fixed-frequency
and unchanged-setter results already exceed the stop threshold. The wide-input
cases are retained as additional diagnostics; their baseline renders the wrong
behaviour, so their cost ratios are **not** acceptance criteria.

### What this establishes

Keeping extra mathematics in configuration did **not** preserve throughput.
The integration adds cache updates, cached pulse levels and a larger setter;
it changes generated code and storage even in ordinary operation. The exact
cause of each regression has not been isolated. In particular, the fixed-tone
slowdown cannot be blamed on executing `fmod` every sample: that helper is not
called in the timed fixed-tone workload.

No optimisation sweep or step-2 implementation followed the failed gate.
Clang/Debug **correctness** was checked; their **performance** measurements were
not run after MSVC Release established the stop condition. No new model
compilation/listening acceptance is claimed for this rejected extension.

## Scope of the fringe cases

Frequencies at/above one full cycle per sample and the simultaneous extreme
low-frequency/tiny-duty case are unusual demands in conventional synthesis.
They should not impose these costs on every oscillator instance. That does not
make modulation itself fringe: PWM changes pulse width and is a standard use
of pulse oscillators. Moog's [waveform-modulation documentation](https://moogmusic-help.freshdesk.com/en/support/solutions/articles/69000840661-how-can-i-modulate-the-waveform-of-just-one-of-the-oscillators-on-the-moog-one-)
explicitly distinguishes pulse-width modulation from saw/triangle wave-angle
modulation. Sine oscillators have no ordinary pulse-width parameter.

## Reproduce

Run in an x64 Visual Studio developer prompt, sequentially:

```text
python tests/klang/osm_extension_variants.py
python tests/klang/check_osm.py --profile multicycle --fast --header build/osm-extensions/headers/multicycle/klang.h --output build/osm-extensions/repeat-quality
python tests/klang/compare_osm_versions.py --extensions --assembly --repeats 3 --versions control multicycle --compare-header control build/osm-extensions/headers/control/klang.h --compare-header multicycle build/osm-extensions/headers/multicycle/klang.h --output build/osm-extensions/repeat-profile
```

For correctness, add `--compiler clang-cl.exe` or `--debug` and a distinct output
path. [Retained results](osm-extension-results.json) include source/header hashes,
commands, four correctness runs and every timing repetition. Generated complete
headers, executables, logs and assembly remain under `build/osm-extensions/`.
