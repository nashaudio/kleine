# Typed OSM investigation

17 September 2026. Separate prototype; production `include/klang.h`, the main
experimental `klang.h`, and the reflection fragment remain unchanged.

**A typed adapter can preserve the ordinary oscillator syntax and subclass
overrides. It has not yet delivered a consistent performance improvement.**
The useful interface result is that configuration retains the oscillator type;
the unresolved performance issue is virtual dispatch through the surrounding
Klang expression operators.

## Prototype

[osm-typed.inc](osm-typed.inc) contains the readable adapter and four public
oscillator declarations. [The generator](../../../tests/klang/osm_typed_variants.py)
adds its corresponding OSM setter specialisations and constructs complete
test headers under `build/osm-typed/headers/`:

| Header | Purpose |
| --- | --- |
| `control` | Previous reflection candidate with inlining hints and precise phase conversion. |
| `typed` | Compile-time waveform choice in the setter and a concrete return type from `operator()`. |
| `typed-conversions` | Additional explicit inlining hints on the signal-conversion overrides. A diagnostic, not the recommended adapter. |

The control and candidates share waveform arithmetic, phase protection and
existing inlining annotations. This isolates the typed interface changes from
the earlier oscillator fixes.

Ordinary use stays the same:

```cpp
using namespace klang;
using namespace klang::optimised;

Saw saw;
saw(440) * 0.2f >> out;
```

The internal adapter is `TypedOsm<Derived, PulseWave>`. Its `operator()` calls
the usual virtual setter and returns `Derived&`, so `saw(440)` has type `Saw&`
instead of `Output&`. It configures the object without processing a sample.
Its setter calls `osm.setTyped<false>()` for saw/triangle or
`osm.setTyped<true>()` for square/pulse. The reflection setter's waveform test
then becomes an `if constexpr` choice.

The existing specialised oscillators already call `osm.saw()` or `osm.pulse()`
directly in `process()`. The adapter retains this; removing a per-sample
waveform-pointer call is **not** a new benefit of this experiment. The common
`Osm` base and its legacy dynamic waveform entry point remain available.

No storage is added: each tested public oscillator is still 144 bytes on these
Windows x64 builds. No allocation is added. Existing `set()` overloads, relative
phase, duty, reset and conversions to common base references remain available.

### Subclassing remains meaningful

```cpp
struct MySaw : klang::optimised::Saw {
    using Saw::set;
    void set(klang::param hz) override { /* custom configuration */ }
    void process() override { /* custom sample */ }
};

MySaw custom;
klang::optimised::Saw& reference = custom;
reference(440) * 0.2f >> out; // Still invokes MySaw's overrides.
```

A `Saw&` can refer to a subclass. Unconditionally replacing its virtual call
with `Saw::process()` would bypass that subclass. The typed adapter deliberately
keeps `this->set(...)` and the normal processing dispatch. Returning `Saw&`
makes more type information available to the compiler; it does not prove that
the dynamic object is exactly a `Saw`.

The return-type change is observable to `decltype`, template deduction and
overload resolution. This is a source-compatible candidate for the tested
models, not a promise that every possible C++ metaprogram or external ABI is
unchanged.

## Where would `final` go?

These are the two relevant forms, **neither used in this prototype**:

```cpp
struct Saw final : Osm { /* ... */ }; // Forbid any subclass of Saw.

struct Saw : Osm {
    void process() override final { /* ... */ } // Forbid overriding this method.
};
```

The method form still permits subclasses, but they cannot supply another
`process()`. A `set(...) override final` similarly seals that particular setter
overload. Both conflict with Chris's request to preserve those extension points.

The internal `OSM` kernel has no virtual functions, so `final` there would not
remove a virtual call. Its waveform member pointer is a separate mechanism;
`final` does not turn that pointer into a compile-time choice.

See Microsoft's [final syntax](https://learn.microsoft.com/en-us/cpp/cpp/final-specifier?view=msvc-170)
and [virtual calls and explicit qualification](https://learn.microsoft.com/en-us/cpp/cpp/virtual-functions?view=msvc-170).

## Actual Klang-expression performance

i7-10700, Windows x64, MSVC 19.51.36257 and clang-cl 22.1.3. C++17,
`/O2 /fp:fast /MT`; Debug uses `/Od /fp:fast /MTd`. No LTO or extra `/Ob`
setting. Runs are sequential, with three executions per binary, alternating
control/candidate order. Each execution takes the median of five passes over
2,000,000 samples at 48 kHz, with 64-sample scratch buffers. Timings include
output accumulation/checksums, but exclude startup, construction and file I/O.

These runs use `--frontend` in the four-way harness, which evaluates Klang
expressions instead of the earlier direct `process()` loop. **Do not compare
these numbers directly with the earlier 0.746 ns Clang raw-process result.**

Release saw timings, ns/sample; lower is better:

| Expression | MSVC control | MSVC typed | Clang control | Clang typed |
| --- | ---: | ---: | ---: | ---: |
| `saw >> out`, fixed frequency | 3.781 | 3.779 | 3.996 | 4.049 |
| `saw(440) * 1.f >> out` | 6.006 | 5.387 | 4.641 | 5.179 |
| `saw(positiveFM) * 1.f >> out` | 8.520 | 8.875 | 9.799 | 9.009 |
| `saw(bipolarFM) * .2f >> out` | 9.195 | 9.235 | 10.572 | 9.851 |

The positive FM table spans roughly 240–640 Hz; the bipolar case subtracts
440 Hz, crossing zero. The `* 1.f` allows exactly the same expression to compile
against the control, whose unscaled inline route has the ambiguity described
below.

There is no consistent gain across waveforms. For example, MSVC triangle's
bipolar case improves from 10.707 to 9.109 ns, while Clang square's unchanged
inline setter worsens from 4.276 to 5.195 ns. MSVC pulse25's positive-FM timing
also regresses in this run (8.645 to 12.277 ns). Debug is mixed: the saw inline
setter is 35.300 to 37.386 ns on MSVC, and 37.240 to 33.198 ns on Clang.

The conversion-hint diagnostic does not produce a consistent improvement
either. Its saw positive-FM timings are 8.507 to 8.469 ns on MSVC and 8.931 to
9.723 ns on Clang. Some runs show appreciable timing spread; these figures
are evidence against claiming a universal speedup, not a precise cost model
for every application. All waveforms, repetitions and configurations are
retained in [the results](osm-typed-results.json).

### What the assembly shows

Both compilers retain indirect setter and signal-conversion calls in the
Release frontend loop, including the conversion-hint diagnostic:

```asm
call qword ptr [rax + 152] ; virtual setter
call qword ptr [rax + 16]  ; virtual signal conversion
```

The conversion then enters normal processing dispatch. MSVC also retains the
out-of-line benchmark wrapper constructor; Clang exposes construction but
still retains the frontend virtual calls. `__forceinline` on the conversion
does not resolve an indirect call whose target the compiler has not established.

The typed setter removes its runtime waveform selection, but that does not
remove the surrounding dispatch cost. Retaining a concrete expression type is
a useful foundation, not sufficient evidence that this path is now nonvirtual.

## Validation and compatibility

- Both candidates pass 19,584 oscillator fixtures / 13,431,840 checks on each
  compiler in Release and Debug. The independent integral oracle remains
  precise while candidate DSP uses fast math.
- Frontend contracts check single evaluation, arithmetic operands, cached
  const reads, modifier input/processing hooks, setter overloads, destruction
  and subclass overrides through concrete oscillator, `Osm`, `Generator` and
  `Output` references.
- The typed return makes `saw(440) >> out` compile directly. The control exposes
  `Output&` here and encounters the pre-existing member/global `operator>>`
  ambiguity. Candidate tests verify that this newly working route also
  respects subclass overrides.
- Existing oscillator limitations remain: the tests do not establish
  multi-cycle FM support or solve extreme low-frequency/tiny-duty resolution.
  See [OSM status](OSM-STATUS.md).

The final frontend suite passes **2,132 checks per typed build** (2,120 shared
checks against the control), on MSVC and Clang in Release and Debug.

All 80 model files were compiled unchanged against both `control` and `typed`:

| Collection | MSVC control / typed | Clang control / typed |
| --- | ---: | ---: |
| Examples | 50/53 / 50/53 | 50/53 / 50/53 |
| Sounds | 2/7 / 2/7 | 2/7 / 2/7 |
| Farnell | 20/20 / 20/20 | 18/20 / 18/20 |
| Total | **72/80 / 72/80** | **70/80 / 70/80** |

**No new failing files.** Existing failures cover the DX7/FM examples, the
Subtractive Filter setter, missing/UE-specific support in several sounds, and
Clang's ambiguous `signal`/`float` conditional in Alarm Generator (also included
by Phone Effects). Source/header hashes were unchanged during each sweep.
These are compilation checks, not a new listening or runtime acceptance of
the models. Full model sweeps cover the primary `typed` adapter; the additional
conversion-hint diagnostic has frontend and oscillator checks only.

## Recommendation

Keep the typed adapter as a reviewable interface prototype. Its concrete return
type is useful for readability and the routing ambiguity. Do not promote it as
a performance fix: the measured gains are mixed, and the public virtual calls
remain. Keep subclassing and overrides intact; do not use `final` on the public
oscillators to obtain an otherwise incompatible benchmark win.

Further performance work should examine the generic expression/conversion
layer, with these override tests as constraints. A statically dispatched helper
can be an explicit internal entry point where the exact object is known; it
cannot silently replace all calls through potentially polymorphic references.

## Reproduce

In an x64 Visual Studio developer prompt, run configurations sequentially:

```text
python tests/klang/osm_typed_variants.py
python tests/klang/check_osm_typed.py --output build/osm-typed/repeat-msvc
python tests/klang/check_osm_typed.py --compiler clang-cl.exe --output build/osm-typed/repeat-clang
```

Add `--debug` and a distinct output path for Debug. Use
`--variant typed-conversions` for the conversion-hint diagnostic;
`--contracts-only` reruns frontend checks without DSP tests or benchmarks.

For unchanged models, repeat this for `control` and `typed`, on both compilers:

```text
python experiments/klang/core/check_compatibility.py --header reference --reference-header build/osm-typed/headers/typed/klang.h --fast --output build/osm-typed/repeat-models
```

Generated complete headers, compiler logs, executables and assembler listings
stay under `build/osm-typed/`. The retained JSON records header/source hashes,
compiler commands, quality results, timings and model compatibility evidence.
