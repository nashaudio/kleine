# OSM: Farbrausch source and CPU review

16 September 2026. The main reproduced Klang faults are **not present in the
corresponding V2 source paths**. The original float state machine can be retained
for ordinary positive audio frequencies. The broader [repair](OSM-FIX.md) remains
a tested reference, but its CPU increase is not a necessary cost of fixing those
faults. Neither core header was changed during this source review.

## Which original?

Tammo "kb" Hinrichs's original implementation is
[`v2/synth.asm`](https://github.com/farbrausch/fr_public/blob/8c8f82c2ae01133370e649bbc05916e7aceecadd/v2/synth.asm).
Its bytes at repository commit `8c8f82c2ae01133370e649bbc05916e7aceecadd` match
the archived `original` tag, commit `3e333cf720be7f3cdc311bbe98939a70e7d60edb`.
The assembly uses x87 arithmetic, so its intermediate precision is not identical
to modern SSE float C++.

[`v2/synth_core.cpp`](https://github.com/farbrausch/fr_public/blob/8c8f82c2ae01133370e649bbc05916e7aceecadd/v2/synth_core.cpp)
is Fabian "ryg" Giesen's later C++ port, begun on 30 June 2012 in commit
`4e058e9c2a9784d4bec6cb94963a5ea775fbd768`. We inspected both implementations
and **executed the C++ oscillator routines, not the original assembler**.
The directory's `LICENSE.txt` places its code in the public domain; source
identities, hashes and history are retained in [v2-source-review.json](v2-source-review.json).
Downloaded source and generated fixtures remain under `build/farbrausch-v2/`.

## Fault attribution

| Klang finding | V2 source | Conclusion |
| --- | --- | --- |
| Transition spikes from `saw(offset - col, tick())` / `pulse(offset, tick())` | C++ reads phase into `p` before `osm_tick`; assembly advances its counter after calculating output. | Introduced by combining the operations into arguments whose evaluation order C++ does not specify. |
| Old phase/duty mapping spans only half the counter | C++ `ftou32` multiplies by 2 after scaling by 2^31; assembly shifts the converted breakpoint left by 1. | Klang omitted the factor of 2. The supplied 0.7.9 fixes scaling, exposing its unchanged duty defaults. |
| Default Square becomes near-DC in 0.7.9 | V2's pulse takes a breakpoint; half a cycle is 50% duty. It has no Klang `Square` wrapper passing 1 as the default duty. | Wrapper/default mismatch in Klang, not a V2 pulse defect. Triangle likewise needs a half-cycle breakpoint. |
| 0.7.9 Saw uses one breakpoint for slopes and another for transitions | C++ derives `col` from the same `brpt` used by `osm_tick`, without the frequency-dependent width clamp. | The inconsistent clamp is specific to Klang's port. |
| Uninitialised/default frequency and stale published frequency | V2's host calls its parameter/pitch setup; C++ calculates helper coefficients before each render loop. | Klang wrapper/lifecycle issues; no equivalent same-value setter shortcut in these original routines. |

Relevant source: C++ [`ftou32`](https://github.com/farbrausch/fr_public/blob/8c8f82c2ae01133370e649bbc05916e7aceecadd/v2/synth_core.cpp#L224-L235),
[`osm_tick`](https://github.com/farbrausch/fr_public/blob/8c8f82c2ae01133370e649bbc05916e7aceecadd/v2/synth_core.cpp#L605-L623),
and [waveform loops](https://github.com/farbrausch/fr_public/blob/8c8f82c2ae01133370e649bbc05916e7aceecadd/v2/synth_core.cpp#L698-L809);
assembly breakpoint conversion at lines 526-533 and counter updates at
`.m0pl` / `.m1pl`, following their waveform calculations.

V2 already computes interval averages using a box filter. Replacing that with a
general double integrator is not required to fix ordering, scaling or duty. Its
source explicitly acknowledges residual aliasing: this is not ideal band-limiting.

## Executable checks and upstream limits

[check_v2_source.py](../../../tests/klang/check_v2_source.py) verifies the pinned
source hash and extracts the helper/state/triangle/pulse function bodies unchanged.
The harness supplies oscillator state directly, unity gain, no ring modulation,
and a quantised 32-bit frequency increment. It does not reproduce the whole
synthesizer's pitch mapping, envelopes or host scheduling.

MSVC 19.51.36257 and Clang 22.1.3, C++17 `/O2 /fp:precise`, each ran 112
two-second cases: 44.1/48 kHz, 0.001/0.01/1/100/440/1000/10000 Hz, breakpoints
0/0.25/0.5/127:128, and both waveform routines. Startup is included.

At 440 Hz / 48 kHz the original C++ routines give:

| Waveform | Min / max | Mean | RMS |
| --- | ---: | ---: | ---: |
| Saw, breakpoint 0 | -0.99083 / 0.99083 | 1.91e-8 | 0.57210 |
| Triangle, breakpoint 0.5 | -0.99077 / 0.99076 | 1.64e-8 | 0.57725 |
| Pulse, breakpoint 0.5 | -1 / 1 | 1.25e-8 | 0.99392 |

These do not exhibit Klang's approximately threefold spikes or unintended
default-square DC. However, upstream is not universally correct:

- The C++ conversion to phase fraction discards nine counter bits. At 0.001 Hz
  its converted increment is zero: all 16 cases produce one nonfinite startup
  sample. At 1 Hz the worst measured peak is 1.00263166, a small float
  cancellation/quantisation error. These measurements concern the C++ port;
  they have not been reproduced in the original x87 assembler.
- Exact breakpoint 1 is outside the original helper's stated domain. Negative
  frequency, zero frequency and arbitrary wide modulation are not established
  contracts of this positive pitch-driven path.
- The source explicitly preserves a separate negative-input Sine FM range
  reduction bug (`BUG_V2_FM_RANGE`). That is unrelated to the OSM faults above.

The runner records diagnostics; successful execution is not an assertion that
all oscillator contracts pass.

## Smaller repair and CPU measurements

A generated diagnostic header retains Klang's float OSM equations and original
increment conversion. It repairs phase scaling and sequencing, half-duty
defaults and initialisation, and guards coefficient divisions. At 100/440/1000 Hz
and 44.1/48 kHz its native Saw/Triangle/Square/Pulse checks are finite and bounded,
with no transition spikes. This is an isolation experiment, **not a complete
replacement**: public frequency caching, Sine startup, zero/negative-frequency
semantics, phase/reset lifecycle and the wider contract suite still need work.

Intel Core i7-10700, Windows x64, one oscillator, 48 kHz. Existing
[osm-benchmark.cpp](../../../tests/klang/osm-benchmark.cpp), five passes of two
million samples per case; elapsed time excludes construction, allocation,
devices and file I/O. Three additional runs alternate old/new executable order;
the table uses the median of their per-run medians. All initial and repeated
measurements are retained, including a noisy initial MSVC Saw setter result.

Fixed 440 Hz, configured once, ns/sample:

| Waveform | MSVC old | MSVC small repair | Clang old | Clang small repair |
| --- | ---: | ---: | ---: | ---: |
| Saw | 2.886 | 2.890 | 2.320 | 2.466 |
| Triangle | 2.947 | 2.972 | 2.418 | 2.524 |
| Square | 2.653 | 2.740 | 2.098 | 2.103 |
| Pulse | 2.663 | 2.771 | 2.114 | 2.105 |

The repeated fixed-frequency results are approximately unchanged to 6% slower,
rather than the larger increases in the general repair. Setter-every-sample
results are roughly -0.3% to +9%; varying-frequency results roughly -2% to +12%.
Small differences are within microbenchmark variability, not a claim of exact
cost equality. The diagnostic remains 104 bytes, matching the old oscillator;
the general repair is 128 bytes. Memory is not the concern here.

These are comparisons with the faulty Klang baseline, not a benchmark against
original V2 assembly, and not a many-voice/SIMD or UE host measurement. Both
correctness and compiler-dependent CPU cost remain promotion criteria.

## Recommended direction

1. Retain the V2 float state machine for ordinary positive audio frequencies;
   fix the port's ordering, scaling, consistent breakpoint and wrapper lifecycle.
2. Keep coefficient work in configuration, cached until the relevant values
   change. Avoid widening the common per-sample path merely to cover rare cases.
3. Use the tested general integrator as a correctness reference and investigate
   targeted higher precision or a separate path for low/zero/negative frequency
   and extreme modulation. Select the path when configuration changes where
   practical; measure the dispatch cost rather than assume it is free.
4. Re-run the full independent contracts and model comparisons on the resulting
   candidate before promotion. In particular, avoid coupling an OSM fix to a
   shared Sine increment change unless that change is independently justified.

The earlier implementation proved the broader contract but was too broad as a
first performance-conscious fix. This source review provides a smaller route;
it does not yet replace the experimental header or claim full contract coverage
for the minimal diagnostic.

## Reproduce

Download the pinned `v2/synth_core.cpp` to `build/farbrausch-v2/synth_core.cpp`,
using the URL and SHA-256 in the retained source manifest. From an x64 Visual
Studio developer command prompt:

```text
python tests/klang/check_v2_source.py
python tests/klang/check_v2_source.py --compiler clang-cl.exe --output build/farbrausch-v2/clang
```

Run sequentially without competing compile/render jobs. The generated headers,
executables, compiler logs and raw CSV files remain under `build/`; the JSON
alongside this report preserves the review evidence.
