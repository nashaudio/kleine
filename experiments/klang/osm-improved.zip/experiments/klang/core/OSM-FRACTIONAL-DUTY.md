# Fractional-duty OSM: step 2 alone

**Follow-up:** [the combined reflection candidate](OSM-COMBINED.md) now includes
both fixes and passes expanded correctness checks and SynTHX profiling on MSVC
and Studio Clang 14.0.6, Release/Debug. This page retains the independent trial.

17 September 2026. Requested independently after the multi-cycle trial failed
its performance gate. **This candidate contains no multi-cycle extension.**

**The repair passes accuracy tests but has marked CPU regressions on MSVC and
Clang. It remains a separate prototype; the recommended reflection candidate,
default experimental header and production header are unchanged.** No further
optimisation or integration followed this gate.

Later [SynTHX tests](OSM-SYNTHX-EXTENSIONS.md) show no marked cost for this same
candidate in normal stacked-Saw synthesis, with frequency updated per buffer.
That result is distinct from the audio-rate FM/PWM workloads below.

## Implementation

[osm-fractional-duty.inc](osm-fractional-duty.inc) starts from the reflection
OSM. The generator applies the recommended narrow integer conversions, precise
phase setup and force-inline annotations to both it and the control.

The exact requested duty breakpoint is `B = k + epsilon` in counter ticks.
Previously `epsilon` was discarded. This version keeps it while retaining
32-bit integer phase and frequency increments:

- Forward phase is integer; comparing it with `B` uses `ceil(B)`.
- For negative Hz, reflected phase is `q = B - physicalPhase`. Its stored integer
  part is `k - physicalPhase`, with implicit fractional part `epsilon`. Its
  comparison threshold is therefore `k`, not `ceil(B)`.
- Cached slopes/biases incorporate the fractional phase for ordinary samples.
  Peak and wrap crossings use cached fractional distance corrections.
- Duty changes, direction changes, absolute/relative phase, reset and sample-rate
  changes preserve the physical phase convention.

`tick()` retains the forward carry test. There is no general integrator,
per-sample direction dispatch, heap allocation or public syntax change. The
native oscillators increase from **144 to 168 bytes** on these Windows x64 builds.
There is additional configuration and boundary arithmetic; storing corrections
in advance does not make that work free during audio-rate FM/PWM.

## Correctness

Both compilers, Release and Debug, pass **24,960 fixtures / 14,206,368 checks**
per run, evaluating 5,653,056 samples. Candidate arithmetic uses `/fp:fast`;
the independent antiderivative reference and measurements use precise arithmetic.
The fractional-duty profile compares against the requested duty without rounding
it to the counter grid. Historical profiles retain their previous contract.

| Build | Failures | Maximum interval/point error |
| --- | ---: | ---: |
| MSVC Release | 0 | 6.124e-6 |
| MSVC Debug | 0 | 6.124e-6 |
| Clang Release | 0 | 4.768e-7 |
| Clang Debug | 0 | 4.768e-7 |

The former approximately **0.04396756** edge discrepancy is repaired. The expanded
moving extreme-duty cases now have a worst residual of **4.768e-7** on every build.
The retained MSVC maximum comes from the broader ordinary matrix, not the repaired
fractional-duty edge.

Tests cover 44.1/48/96 kHz, positive/negative/zero and sub-tick frequency, duty down
to `1e-12`, quarter/half/three-quarter-counter-tick duties, phases on both sides of
the peak/wrap, sign changes, changing duty, virtual control dispatch, reset,
relative phase, rate changes and existing invalid-frequency containment.

As a negative control, the unchanged reflection header fails 62,038 checks in
this new profile. Its maximum error is 2 at zero-frequency/sub-tick pulse cases:
a tiny nonzero high interval becomes zero width when the breakpoint is truncated.
This is an expected failure of the stronger continuous-duty contract, not a
regression caused by modifying the control. Its previous quantised-duty acceptance
remains a separate result.

## Release performance

Intel Core i7-10700, Windows x64, MSVC 19.51.36257 and stock clang-cl 22.1.3.
C++17, **`/O2 /fp:fast /MT`** on both. This is the installed Clang toolchain,
not Klang Studio's modified compiler. Debug correctness uses `/Od /fp:fast /MTd`.

One oscillator at 48 kHz; 64-sample scratch buffers; five passes of 2,000,000
samples per case. Figures below are the median of three executions, alternating
control/candidate order. Builds finish before timing, and benchmarks run
sequentially. Construction and initial setup, file I/O and allocation are outside
the timed region. Sample processing, changing controls where specified, buffer
clearing, accumulation and checksum are included.

These are public `set()`, `setDuty()` and `process()` calls. The optional Klang
expression mode was not run. Do not compare these absolute timings with earlier
harnesses as if they measured identical work.

**Fixed 440 Hz: ns/sample, control -> candidate (change):**

| Oscillator | MSVC | Clang |
| --- | ---: | ---: |
| saw | 2.717 -> 2.926 (+7.7%) | 2.448 -> 2.633 (+7.6%) |
| triangle | 2.688 -> 3.189 (+18.6%) | 2.603 -> 2.671 (+2.6%) |
| square | 2.312 -> 2.380 (+2.9%) | 1.903 -> 1.943 (+2.1%) |
| pulse25 | 2.439 -> 2.392 (-1.9%) | 1.965 -> 1.986 (+1.1%) |

**Selected changing-control and exceptional workloads:**

| Workload | MSVC | Clang |
| --- | ---: | ---: |
| Saw: positive FM | 6.160 -> 7.079 (+14.9%) | 6.509 -> 7.738 (+18.9%) |
| Triangle: positive FM | 6.402 -> 7.574 (+18.3%) | 6.809 -> 7.644 (+12.3%) |
| Square: PWM | 6.124 -> 8.266 (+35.0%) | 6.430 -> 9.284 (+44.4%) |
| Pulse: PWM | 6.400 -> 8.414 (+31.5%) | 6.589 -> 9.344 (+41.8%) |
| Pulse: FM + PWM | 8.773 -> 11.601 (+32.2%) | 9.842 -> 13.632 (+38.5%) |
| Pulse: fixed .001 Hz, duty 1e-6 | 2.231 -> 2.623 (+17.6%) | 2.191 -> 1.935 (-11.7%) |
| Pulse: tiny-duty bipolar FM + PWM | 8.909 -> 11.817 (+32.6%) | 9.643 -> 14.066 (+45.9%) |

Ordinary PWM varies duty from .1 to .9 at fixed 440 Hz. Positive FM varies from
240 to 640 Hz; combined FM/PWM changes both controls every sample. Extreme mode 7
uses bipolar .001 Hz modulation and duty 1e-7 to 9e-7. All four oscillator classes
and all eight modes are retained in the evidence file; this table is a selection.

The regressions exceed the earlier roughly 10% performance gate. They are not
just one outlying timing: MSVC fixed Triangle medians are 2.690/2.688/2.687 ns for
the control and 3.189/3.180/3.190 ns for the candidate. Clang Square PWM candidate
medians are 9.284/9.286/9.267 ns, versus control 6.430/6.406/9.090 ns. There is
run variation, but the candidate's modulation cost is consistently substantial.
Small fixed-tone improvements should not be treated as reliable wins.

Additional cached values, setter work and boundary operations alter the generated
code even for ordinary duty values with zero fractional remainder. This explains
why the feature cannot be described as free. A precise attribution of each
fixed-tone regression would require further assembly/layout experiments; no
claim is made that the larger object alone caused it.

Clang Release profiling was completed to cover the relevant Klang Studio
compiler family. **Debug performance was not run after the Release gate failed**;
Debug correctness was checked on both compilers. No model listening or broad
example-compilation acceptance is claimed for this isolated, rejected extension.

## Remaining limits

- Multi-cycle inputs (`abs(Hz) >= fs`) still take the control's containment path.
  Step 1 is deliberately absent.
- Frequency/physical phase remain on the 32-bit counter grid; fractional duty
  support does not make sub-tick frequencies advance.
- This validates duties down to `1e-12`, not every subnormal float. Extreme
  reciprocal overflow/underflow remains outside the tested range.
- The accuracy repair is available for further work, but this integration does
  not meet the low-overhead requirement. No automatic fallback is added.

## Reproduce

Run sequentially from an x64 Visual Studio developer prompt:

```text
python tests/klang/osm_extension_variants.py --variant fractional-duty --output build/osm-fractional-duty
python tests/klang/check_osm.py --profile fractional-duty --fast --header build/osm-fractional-duty/headers/fractional-duty/klang.h --output build/osm-fractional-duty/repeat-quality
python tests/klang/compare_osm_versions.py --fractional-duty --assembly --repeats 3 --versions control fractional-duty --compare-header control build/osm-fractional-duty/headers/control/klang.h --compare-header fractional-duty build/osm-fractional-duty/headers/fractional-duty/klang.h --output build/osm-fractional-duty/repeat-profile
```

Add `--compiler clang-cl.exe` for Clang; correctness additionally used `--debug`.
Use distinct output paths. [Retained evidence](osm-fractional-duty-results.json)
contains commands, hashes, every timing repetition and all four accuracy reports.
Generated complete headers, binaries, assembly and logs remain under
`build/osm-fractional-duty/`.
