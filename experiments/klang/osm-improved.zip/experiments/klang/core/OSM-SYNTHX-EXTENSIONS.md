# SynTHX: separate multi-cycle and fractional-duty fixes

17 September 2026. Follow-up to the [three-Saw comparison](OSM-SYNTHX.md).
Chris selected **separate fixes only**; no combined candidate was created.

The later [Studio Clang 14.0.6 test](OSM-SYNTHX-CLANG14.md) repeats both fixes
alongside production, V2 and reflection through Studio's native compiler DLL.

**Neither existing fix causes a marked slowdown in this SynTHX workload.**
MSVC Release improves by about 6-11%. Clang Release is close to baseline or
faster, with the largest measured slowdown only 0.4%. Debug changes are small
and favourable. Treat small percentages as variation, not guaranteed gains.

This does **not** overturn the earlier audio-rate FM/PWM regressions. SynTHX
updates frequency once per 64-frame buffer, uses the ordinary zero-breakpoint
Saw, and stays below the multi-cycle frequency boundary. These runs measure
the cost of including each fix in normal synthesis, not execution of the extreme
cases or changing duty every sample.

## Candidates and method

No oscillator source was changed. The runner's `--extensions` mode generates
the existing candidates and verifies that their headers are identical to the
baseline outside OSM. The SynTHX model copy changes only the Saw member type;
the C++ timing harness is unchanged from the preceding comparison.

| Variant | Header SHA-256 |
| --- | --- |
| Reflection | `9a8a99d97c82e79ccaa7683f268c7abb613ec7293f9025d6ee2a2a30111dc5c7` |
| Multi-cycle only | `ba2a429df40d0cfa060df930447fc1a17a1713ed1bf4cb4c7d77d83cbbe1deeb` |
| Fractional-duty only | `fce80d30afef78438b870a27a7752d77bddd54902f088fc348281381044dee0c` |

These hashes match the isolated accuracy-tested implementations documented in
[OSM-EXTENSIONS.md](OSM-EXTENSIONS.md) and
[OSM-FRACTIONAL-DUTY.md](OSM-FRACTIONAL-DUTY.md).

The [original workload/method](OSM-SYNTHX.md#workload-and-method) is retained:
i7-10700, Windows x64, MSVC 19.51.36257 and stock clang-cl 22.1.3; C++17,
`/fp:fast`, Release `/O2 /MT`, Debug `/Od /MTd`. No extra ISA, LTO or PGO flags;
`CL` and `_CL_` are unset. One MIDI note at pitch 26, seed 12345, 48 kHz stereo,
64-frame buffers, **96 active Saws**, two seconds per timed pass after warm-up.
Full mixing, ADSR, stereo saturation, buffer clearing and checksum are timed;
construction, note-on, allocation, warm-up, validation and file I/O are excluded.

- Held: default pitch control .6, detune .5.
- Sweep: pitch 0 to 1, detune 1 to .5, updated per buffer.
- Initial runs: three passes and three executions per variant/configuration.
- Release had enough spread to obscure small differences, so both Release
  configurations were repeated with **seven passes and five executions**.
- Tables use the Release confirmation runs and original Debug runs. All initial
  results are retained too. Values are medians of execution medians; variant
  order rotates. Compilation precedes timing; configurations run sequentially.

Units are elapsed render **milliseconds per audio second**, not process CPU
counters. Divide by ten for equivalent utilisation of one core at real time.
Compare against the fresh baseline in each row, not older absolute timings.

## Held controls

Lower is better. Parentheses show the change relative to reflection.

| Build | Reflection | Multi-cycle only | Tiny-duty only |
| --- | ---: | ---: | ---: |
| MSVC Release | 36.73 | 32.75 (-10.8%) | 33.12 (-9.8%) |
| Clang Release | 33.84 | 32.78 (-3.1%) | 33.90 (+0.2%) |
| MSVC Debug | 184.72 | 181.68 (-1.6%) | 179.33 (-2.9%) |
| Clang Debug | 221.60 | 216.09 (-2.5%) | 210.24 (-5.1%) |

## Moving pitch and detune

| Build | Reflection | Multi-cycle only | Tiny-duty only |
| --- | ---: | ---: | ---: |
| MSVC Release | 37.51 | 35.25 (-6.0%) | 33.92 (-9.6%) |
| Clang Release | 34.65 | 34.80 (+0.4%) | 32.47 (-6.3%) |
| MSVC Debug | 183.96 | 182.44 (-0.8%) | 179.58 (-2.4%) |
| Clang Debug | 217.15 | 210.90 (-2.9%) | 210.90 (-2.9%) |

MSVC Release's improvement survives the longer run. Other changes overlap
timing variation: Clang held baseline execution medians span 64.57-72.30 ms
per two-second pass; tiny-duty spans 64.91-73.06 ms. Its +0.2% is effectively tied.

Per-buffer configuration amortises extra setter work relative to audio-rate
modulation. Compiler visibility, generated code and object layout also differ
between a single-oscillator microbenchmark and this full model. No specific
instruction/layout cause for the speedups has been isolated. This supports
**no meaningful penalty here**, not universal performance gains from either fix.

## Output and memory

All variants passed finite, non-silent render checks in both workloads, with
one active note and 96 active Saws. Checksums repeat exactly between timing
executions. All measured inputs remained unchanged. Retained held renders each
contain 192,000 finite stereo float samples, without normalisation or alignment:

- Multi-cycle: sample-identical to reflection on both compilers/build types.
- Tiny-duty: sample-identical except MSVC Release, with maximum residual
  `1.19209e-7` and RMS `3.09595e-9`.

| Variant | Saw object | Note slot, Release | Note slot, Debug |
| --- | ---: | ---: | ---: |
| Reflection | 144 bytes | 49,184 bytes | 51,304 bytes |
| Multi-cycle only | 160 bytes | 51,296 bytes | 53,416 bytes |
| Tiny-duty only | 168 bytes | 52,352 bytes | 54,472 bytes |

Across all 4,224 allocated Saws, extra storage is 67,584 bytes for multi-cycle
or 101,376 bytes for tiny-duty. These exclude heap allocations, allocator
metadata, code and total process memory.

## Reproduce

Run sequentially in an x64 Visual Studio developer prompt:

```text
python tests/klang/profile_synthx.py --extensions --passes 7 --repeats 5 --output build/osm-synthx-extensions/msvc-release-confirmation
python tests/klang/profile_synthx.py --extensions --passes 7 --repeats 5 --compiler clang-cl.exe --output build/osm-synthx-extensions/clang-release-confirmation
python tests/klang/profile_synthx.py --extensions --debug --output build/osm-synthx-extensions/msvc-debug
python tests/klang/profile_synthx.py --extensions --debug --compiler clang-cl.exe --output build/osm-synthx-extensions/clang-debug
```

[Runner](../../../tests/klang/profile_synthx.py),
[retained evidence](osm-synthx-extension-results.json). Evidence includes initial
and confirmation measurements, every repetition, flags, hashes, selected-header
verification, validation and audio residuals. Generated headers, binaries,
assembly, logs and held renders remain under `build/osm-synthx-extensions/`.
No core header or model has been promoted.
