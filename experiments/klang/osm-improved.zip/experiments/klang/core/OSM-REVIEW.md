# OSM oscillator review

**Repair follow-up:** [OSM-FIX.md](OSM-FIX.md) records the implemented and tested
experimental repair. The findings below describe the original 0.7.8/0.7.9
headers and remain as historical evidence.

16 September 2026. Compared production 0.7.8 with Chris's supplied UE 0.7.9
header on MSVC 19.51.36257 and Clang 22.1.3, C++17, `/O2 /fp:precise`.
Neither header was changed. The new OSM contains useful corrections **and
remaining faults**; it is not ready for wholesale promotion.

## Why the PD matches remain valid

The Farnell models use `pd::osc` and `pd::phasor` in
[pd.h](../../../include/klang/pd.h). These implement PD's own table/phase
algorithms and do not call Klang's OSM. Pedestrians, Phone Tones, DTMF and Alarm
Generator therefore do not validate OSM through their PD comparisons.
The typed-literal sample-identity fixture also uses `pd::osc`.

## Confirmed phase correction

0.7.8 converts radians to a 32-bit phase using a scale of 2^31 per turn, while
its counter spans 2^32. 0.7.9 uses 2^32 and wraps negative/full-turn inputs.

| Requested turns | 0.7.8 reported cycles | 0.7.9 reported cycles |
| ---: | ---: | ---: |
| 0 | 0 | 0 |
| 0.25 | 0.125 | 0.25 |
| 0.5 | 0.25 | 0.5 |
| 0.75 | 0.375 | 0.75 |
| 1 | 0.5 | 0 |
| -0.25 | Invalid negative float-to-unsigned conversion; compiler-dependent | 0.75 |

This corrects phase offsets and duty widths. It does **not** establish that the
old frequency increment was halved. The measured Sine at 440 Hz/48 kHz is
439.999983 Hz with RMS 0.707105 in both headers. The old OSM wrapper's public
`frequency` field stays at 1000 after setting 440, although the internal
increment changes; 0.7.9 also repairs that stale field.

## Remaining faults

Values below are unnormalised, at 440 Hz and 48 kHz, after a one-second settle.
Both compilers give identical waveform metrics throughout the fixture.

| Oscillator | 0.7.8 min/max | 0.7.9 min/max | 0.7.9 mean | 0.7.9 RMS |
| --- | ---: | ---: | ---: | ---: |
| Sine | -1 / 1 | -1 / 1 | ~0 | 0.707105 |
| Saw | -0.9908 / 2.9688 | -0.9907 / 1.9962 | 0.018503 | 0.586956 |
| Triangle | -0.9816 / 3.0151 | -0.9816 / 3.0151 | 0.036667 | 0.637550 |
| Square, default duty | -2.9962 / 2.9963 | -1 / 1 | **0.981667** | 1 |
| Square, explicit duty 0.5 | -2.9962 / 2.9963 | -2.9962 / 2.9963 | ~0 | 1.033174 |
| Pulse, default duty | -2.9962 / 2.9963 | -2.9962 / 2.9963 | ~0 | 1.033174 |

1. **Square default duty was not updated with the phase correction.** Triangle
   changes from 1 to 0.5, preserving its intended half-cycle breakpoint, but
   Square still passes 1. In 0.7.9 that becomes nearly 100% duty rather than the
   old effective 50%. The result is nearly DC. Explicit duty 0.5 restores the
   intended shape, but retains the transition problem below. Pulse's default
   0.5 changes from an effective 25% to 50%; its old mean is approximately -0.5.

2. **Phase reads and advancement have unspecified argument evaluation order.**
   Both versions call `saw(offset - col, tick())` and `pulse(offset, tick())`.
   `tick()` advances `offset`, but returns the transition for the prior phase.
   The equations require the matching prior phase. The diagnostic snapshots it
   before calling `tick()`: Triangle becomes bounded by +/-0.991 with RMS
   0.577254 and fundamental amplitude 0.810457; half-duty Square/Pulse stay
   within +/-1 with RMS 0.993912. This isolates the transition fault without
   replacing the oscillator equations. It is a longstanding fault, not a new
   consequence of fixing the phase scale.

3. **0.7.9 Saw has inconsistent breakpoint and slope widths.** `init()` clamps
   `col` to at least `delta`, but `tick()` tests the unchanged `duty.position`.
   With explicit sequencing alone Saw still reaches -1.8257. Setting its duty
   to one sample's phase width makes both thresholds agree, giving
   -0.9907 / 0.9908 and mean ~0. This supports the diagnosis; the appropriate
   zero-width Saw limit and anti-aliasing contract still need review before
   selecting a production repair.

## Reproduce and scope

```text
python tests/klang/check_oscillators.py --game-header F:/Future/Future.58/Plugins/Klang/Source/Public/klang.h
python tests/klang/check_oscillators.py --game-header F:/Future/Future.58/Plugins/Klang/Source/Public/klang.h --compiler clang-cl.exe --output build/game-header/oscillators-clang
```

Run from an x64 VS developer prompt. [The probe](../../../tests/klang/oscillators.cpp)
measures 100/440/1000 Hz at 44.1/48 kHz: 66 cases per header, including explicit
diagnostic variants, plus six phase inputs. It records min/max, mean, RMS,
nonfinite counts and the first three harmonic amplitudes. All measured waveform
samples are finite. Rising zero-crossing counts are also retained, but transition
spikes can create extra crossings: they are not reliable pitch estimates for
the broken waveforms. Negative phase in the old header is a separate invalid
conversion probe, not a numerical reference.

This is diagnostic evidence, not a passing all-oscillator test gate. It does not
cover high-frequency aliasing, FM, live rate changes, every setter/lifecycle path,
negative frequency, or CPU cost. Acceptance should use intended waveform,
frequency, phase and level contracts, rather than requiring identity with faulty
0.7.8 output. Keep model listening comparisons when correcting existing sounds.

[Retained results and hashes](game-header-review.json) include the supplied
header identity and both compiler runs. Full logs/CSVs are under
`build/game-header/oscillators-{msvc,clang}/`. Fixes remain isolated in diagnostic
subclasses; production, candidate and supplied UE headers are unchanged.

Priority P1 before adopting OSM changes in the replacement core; allow 1-2 days
for focused repairs and boundary/FM tests, then assess affected game sounds.
