// General interval-mean oscillator retained as an experimental accuracy reference.
// Not included by the core; select explicitly when investigating exceptional cases.
#pragma once
#include <klang.h>

namespace klang::Generators::Fast::reference {
			/** Oscillator State Machine: average a piecewise waveform over one sample.
			 * Phase is the end of the integration interval, then advances once.
			 * Frequency is in Hz; absolute phase in radians; duty in [0,1].
			 * Zero Hz holds the point value. Negative Hz runs phase backwards.
			 * This is box averaging, not an ideal band-limit; harmonics can still alias.
			 */
			struct OSM {
				using Waveform = float(OSM::*)();
				const Waveform waveform;
				OSM(Waveform waveform) : waveform(waveform) {}

				Fast::Increment increment;
				Fast::Phase offset, phaseOffset;
				param frequency = 0;
				double sampleRate = 0, inverseWidth = 0, whole = 0, fraction = 0;
				double col = 0.5, rising = 2, falling = 2;
				bool backwards = false;

				void set(param hz) {
					if (frequency != hz || sampleRate != double(fs)) {
						frequency = hz;
						sampleRate = fs;
						increment.set(hz);
						backwards = hz < 0;
						const double cycles = fs > 0 && std::isfinite(hz.value) ? std::fabs(double(hz.value) / fs) : 0;
						whole = cycles >= 1 ? std::floor(cycles) : 0;
						const unsigned int ticks = backwards ? 0u - static_cast<unsigned int>(increment.amount)
							: static_cast<unsigned int>(increment.amount);
						fraction = double(ticks) / 4294967296.0;
						const double width = whole + fraction;
						inverseWidth = width > 0 ? 1 / width : 0;
					}
				}
				void set(param hz, param phase) {
					set(hz);
					offset = phase;
					phaseOffset = 0;
				}
				void set(param hz, param phase, param duty) {
					set(hz, phase);
					setDuty(duty);
				}
				void setDuty(param duty) {
					col = std::isfinite(duty.value) ? std::clamp(double(duty.value), 0.0, 1.0) : 0.5;
					rising = col > 0 ? 1 / col : 0;
					falling = col < 1 ? 1 / (1 - col) : 0;
				}

				// Segment states: entirely rising/high, entirely falling/low, or crossing duty.
				template<bool Pulse>
				double segment(double first, double last) const {
					if constexpr (Pulse) {
						return 2 * std::max(0.0, std::min(last, col) - first) - (last - first);
					} else {
						if (last <= col)
							return ((first + last) * rising - 1) * (last - first);
						if (first >= col)
							return (1 - (first + last - 2 * col) * falling) * (last - first);
						// Sum two trapezoids at the peak. No subtraction of near-equal integrals.
						return first * rising * (col - first) + (1 - last) * falling * (last - col);
					}
				}

				template<bool Pulse>
				float sample() {
					unsigned int end = offset.position + phaseOffset.position;
					if (backwards)
						end -= static_cast<unsigned int>(increment.amount);
					const double phase = double(end) / 4294967296.0;
					offset += increment;
					if (inverseWidth == 0) {
						if constexpr (Pulse) return phase < col ? 1.f : -1.f;
						else return float(phase < col ? 2 * phase * rising - 1 : 1 - 2 * (phase - col) * falling);
					}
					// Most samples stay on one segment: its midpoint is the exact mean.
					if (whole == 0 && fraction <= phase) {
						if (phase <= col) {
							if constexpr (Pulse) return 1.f;
							else return float((2 * phase - fraction) * rising - 1);
						}
						if (phase - fraction >= col) {
							if constexpr (Pulse) return -1.f;
							else return float(1 - (2 * phase - fraction - 2 * col) * falling);
						}
					}

					// Handle full turns and wrap explicitly; work stays bounded even above fs.
					double area = Pulse ? whole * (2 * col - 1) : 0;
					if (fraction <= phase)
						area += segment<Pulse>(phase - fraction, phase);
					else {
						area += segment<Pulse>(1 + phase - fraction, 1);
						area += segment<Pulse>(0, phase);
					}
					return float(area * inverseWidth);
				}
				float saw() { return sample<false>(); }
				float pulse() { return sample<true>(); }
				float output() { return (this->*waveform)(); }
			};

			/// @cond
			struct Osm : public Oscillator {
				const float _Duty;
				Osm(OSM::Waveform waveform, float duty = 0.f) : _Duty(duty), osm(waveform) {
					osm.setDuty(duty);
					osm.set(frequency);
				}
				using Oscillator::set;
				void set(param hz) override {
					Oscillator::frequency = hz;
					osm.set(hz);
				}
				void set(param hz, param phase) override {
					Oscillator::frequency = hz;
					Oscillator::position = phase;
					Oscillator::offset = 0;
					osm.set(hz, phase);
				}
				void set(param hz, param phase, param duty) override {
					set(hz, phase);
					setDuty(duty);
				}
				void set(param hz, relative phase) override {
					set(hz);
					set(phase);
				}
				void set(relative phase) override {
					Oscillator::offset = phase * twoPi;
					osm.phaseOffset = Oscillator::offset;
				}
				void setDuty(param duty) { osm.setDuty(duty); }
				void reset() override {
					Oscillator::position = 0;
					osm.offset = 0;
				}
				void process() override { out = osm.output(); }

			protected:
				OSM osm;
			};
			/// @endcond

			/// Descending saw, averaged over each sample interval.
			struct Saw : public Osm { Saw() : Osm(&OSM::saw, 0.f) {} };
			/// Triangle with equal rising and falling half-cycles, sample-averaged.
			struct Triangle : public Osm { Triangle() : Osm(&OSM::saw, 0.5f) {} };
			/// Square with 50% high duty, sample-averaged.
			struct Square : public Osm { Square() : Osm(&OSM::pulse, 0.5f) {} };
			/// Pulse with configurable high duty in [0,1], sample-averaged.
			struct Pulse : public Osm { Pulse() : Osm(&OSM::pulse, 0.5f) {} };

}
