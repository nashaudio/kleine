// Historical integration prototype, retained for comparison only.
// The default experimental core now includes signed-frequency oscillators.
#pragma once
#include <klang.h>

namespace klang::Generators::Fast::signed_frequency {
    // Mirroring triangle phase/duty preserves its value; pulse needs inversion.
    template<bool PulseWave>
    struct SignedOsm : Fast::Osm {
        SignedOsm(float duty) : Fast::Osm(PulseWave ? &OSM::pulse : &OSM::saw, duty), width(duty) {}
        using Fast::Osm::set;

        void set(param hz) override {
            if (frequency == hz && osm.sampleRate == fs.f) return;
            const bool backwards = hz < 0 && -double(hz.value) < fs.f && -double(hz.value) * OSM::turn >= fs.f;
            if (backwards != reverse) {
                osm.offset.position = 0u - osm.offset.position;
                osm.phaseOffset.position = 0u - osm.phaseOffset.position;
                reverse = backwards;
                setDuty(width);
            }
            frequency = hz;
            osm.set(hz < 0 ? -hz.value : hz.value);
        }
        void set(param hz, param radians) override {
            set(hz);
            Oscillator::position = radians;
            Oscillator::offset = 0;
            osm.offset = radians;
            if (reverse) osm.offset.position = 0u - osm.offset.position;
            osm.phaseOffset = 0;
            osm.sync();
        }
        void set(param hz, param radians, param duty) override {
            set(hz, radians);
            setDuty(duty);
        }
        void set(relative phase) override {
            Oscillator::offset = phase * twoPi;
            osm.offset.position -= osm.phaseOffset.position;
            osm.phaseOffset = Oscillator::offset;
            if (reverse) osm.phaseOffset.position = 0u - osm.phaseOffset.position;
            osm.offset.position += osm.phaseOffset.position;
            osm.sync();
        }
        void setDuty(param duty) {
            width = std::isfinite(duty.value) ? std::clamp(duty.value, 0.f, 1.f) : .5f;
            const auto ticks = static_cast<unsigned long long>(double(width.value) * OSM::turn);
            osm.setBreakpoint(reverse ? 4294967296ull - ticks : ticks);
        }
        void process() override {
            if constexpr (PulseWave) {
                out = osm.pulse();
                if (reverse) out = -out;
            } else out = osm.saw();
        }

    private:
        param width;
        bool reverse = false;
    };

    // Signed-frequency descending saw.
    struct Saw : SignedOsm<false> { Saw() : SignedOsm(0) {} };
    // Signed-frequency symmetric triangle.
    struct Triangle : SignedOsm<false> { Triangle() : SignedOsm(.5f) {} };
    // Signed-frequency 50% square.
    struct Square : SignedOsm<true> { Square() : SignedOsm(.5f) {} };
    // Signed-frequency variable-duty pulse.
    struct Pulse : SignedOsm<true> { Pulse() : SignedOsm(.5f) {} };
}
