// The runner supplies one Saw alias and a copy of SynTHX with only that type changed.
#include <klang.h>
#include "selected-saw.h"
#include "SynTHX.k"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <vector>

volatile double consumed = 0;
constexpr int rate = 48000, block = 64;

// An integer-only, precise check cannot be erased by fast-math assumptions.
#pragma float_control(precise, on, push)
__declspec(noinline) bool finiteBits(std::uint32_t bits) {
    return (bits & 0x7f800000u) != 0x7f800000u;
}
#pragma float_control(pop)
struct Metrics {
    double elapsed = 0, sum = 0, squares = 0, peak = 0;
    int nonfinite = 0, active = 0, saws = 0;
};

Metrics render(int mode, int frames, bool validate, const char* audioPath = nullptr) {
    std::srand(12345);
    auto synth = std::make_unique<SynTHX>();
    synth->noteOn(26, 1);
    auto& host = static_cast<klang::Stereo::Synth&>(*synth);
    std::array<float, block> left{}, right{};
    float* channels[] = {left.data(), right.data()};
    std::vector<std::array<float, 2>> automation(frames / block);
    for (int b = 0; b < int(automation.size()); ++b) {
        const float progress = float(b) / float(automation.size() - 1);
        automation[b] = mode ? std::array<float, 2>{progress, 1.f - .5f * progress}
                             : std::array<float, 2>{.6f, .5f};
    }
    Metrics result;
    for (unsigned int n = 0; n < synth->notes.count; ++n) {
        if (synth->notes[n]->finished()) continue;
        ++result.active;
        const auto* note = static_cast<const SynTHX::MyNote*>(synth->notes[n]);
        for (const auto& chord : note->notes)
            result.saws += float(chord.frequency) < 440 ? 8 : 12;
    }
    // Warm the real synth and caches; keep startup/allocation outside timing.
    for (int i = 0; i < rate / 4 / block; ++i) {
        left.fill(0); right.fill(0);
        host.process(channels, block);
    }
    FILE* audio = audioPath ? std::fopen(audioPath, "wb") : nullptr;
    if (audioPath && !audio) std::exit(3);
    const auto begin = std::chrono::steady_clock::now();
    for (int frame = 0; frame < frames; frame += block) {
        if (mode) {
            synth->controls[2].set(automation[frame / block][0]);
            synth->controls[1].set(automation[frame / block][1]);
        }
        left.fill(0); right.fill(0);
        host.process(channels, block);
        for (int i = 0; i < block; ++i) {
            result.sum += left[i] + double(right[i]);
            if (validate) {
                for (float value : {left[i], right[i]}) {
                    std::uint32_t bits;
                    std::memcpy(&bits, &value, sizeof(bits));
                    result.nonfinite += !finiteBits(bits);
                    result.squares += double(value) * value;
                    result.peak = std::max(result.peak, std::fabs(double(value)));
                }
            }
            if (audio) {
                const float pair[] = {left[i], right[i]};
                if (std::fwrite(pair, sizeof(float), 2, audio) != 2) std::exit(3);
            }
        }
    }
    result.elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - begin).count();
    if (audio) std::fclose(audio);
    consumed = result.sum;
    return result;
}

int main(int argc, char** argv) {
    klang::fs = rate;
    if (argc >= 2 && std::strcmp(argv[1], "validate") == 0) {
        for (int mode : {0, 1}) {
            const auto result = render(mode, rate * 2, true, argc > 2 && mode == 0 ? argv[2] : nullptr);
            std::printf("validation,%d,%d,%d,%d,%.12g,%.12g,%.12g\n", mode, result.active,
                result.saws, result.nonfinite, result.peak, std::sqrt(result.squares / (rate * 4)), result.sum);
            if (result.nonfinite || result.peak == 0 || result.active != 1 || result.saws != 96) return 1;
        }
        return 0;
    }
    const int passes = argc > 1 ? std::atoi(argv[1]) : 3;
    std::puts("mode,frames,active_notes,active_saws,saw_bytes,note_bytes,min_ms,median_ms,max_ms,checksum");
    for (int mode : {0, 1}) {
        std::vector<double> times;
        Metrics result;
        for (int pass = 0; pass < passes; ++pass) {
            result = render(mode, rate * 2, false);
            times.push_back(result.elapsed * 1000);
        }
        std::sort(times.begin(), times.end());
        std::printf("%d,%d,%d,%d,%zu,%zu,%.9g,%.9g,%.9g,%.12g\n", mode, rate * 2,
            result.active, result.saws, sizeof(BenchSaw), sizeof(SynTHX::MyNote),
            times.front(), times[times.size()/2], times.back(), result.sum);
    }
}
