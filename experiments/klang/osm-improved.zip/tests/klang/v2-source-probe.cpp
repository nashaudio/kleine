// Exercise the unmodified routines extracted from Farbrausch's C++ V2 port.
#include "v2-oscillator.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

int main() {
    std::puts("wave,rate,hz,duty,nonfinite,min,max,mean,rms");
    for (int rate : {44100, 48000}) {
        for (float hz : {.001f, .01f, 1.f, 100.f, 440.f, 1000.f, 10000.f}) {
            for (float duty : {0.f, .25f, .5f, 127.f / 128.f}) {
                for (bool pulse : {false, true}) {
                    V2OscProbe osc;
                    osc.cnt = 0;
                    osc.freq = int(double(hz) / rate * 4294967296.0);
                    osc.brpt = ftou32(duty);
                    osc.gain = 1;
                    osc.ring = false;
                    std::vector<float> audio(rate * 2, 0);
                    if (pulse) osc.renderPulse(audio.data(), int(audio.size()));
                    else osc.renderTriSaw(audio.data(), int(audio.size()));
                    double lo = 1e30, hi = -1e30, sum = 0, squares = 0;
                    int nonfinite = 0;
                    // Include startup to expose invalid low-frequency transitions.
                    for (float x : audio) {
                        if (!std::isfinite(x)) { ++nonfinite; continue; }
                        lo = std::min(lo, double(x)); hi = std::max(hi, double(x));
                        sum += x; squares += double(x) * x;
                    }
                    std::printf("%s,%d,%.9g,%.9g,%d,%.9g,%.9g,%.9g,%.9g\n",
                        pulse ? "pulse" : "tri-saw", rate, hz, duty, nonfinite,
                        lo, hi, sum / audio.size(), std::sqrt(squares / audio.size()));
                }
            }
        }
    }
}
