"""Compare scalar OSM throughput; run without competing compiler/render jobs."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import platform
import shutil
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default='cl.exe')
    parser.add_argument('--output', default='build/osm-fix/benchmark-msvc')
    parser.add_argument('--experiments', action='store_true', help='Also measure the opt-in signed and general-reference oscillators')
    parser.add_argument('--opaque', action='store_true', help='Use an opaque virtual Oscillator reference, preventing concrete-type inlining')
    parser.add_argument('--debug', action='store_true', help='Measure unoptimised /Od /MTd code, separately from Release')
    parser.add_argument('--crossing', action='store_true', help='Add through-zero and alternating-sign workloads to signed comparisons')
    parser.add_argument('--only-comparisons', action='store_true', help='Omit the automatic production/default benchmark entries')
    parser.add_argument('--retained', action='store_true', help='Reconstruct the retained positive-only and prior signed headers, verifying their hashes')
    parser.add_argument('--repeats', type=int, default=1, help='Repeat each five-pass measurement; retain every run and report median-of-medians')
    parser.add_argument('--previous-header', type=Path, help='Also compare a previous workspace header named klang.h')
    parser.add_argument('--compare-header', nargs=2, action='append', default=[], metavar=('LABEL', 'PATH'),
                        help='Add a named workspace header to the positive-frequency comparison')
    parser.add_argument('--signed-header', action='append', default=[], metavar='LABEL',
                        help='Also run negative-frequency workloads for this named comparison header')
    args = parser.parse_args()
    if args.repeats < 1:
        parser.error('--repeats must be positive')
    compiler = shutil.which(args.compiler)
    if not compiler:
        parser.error('Use an x64 VS developer environment')
    output = (ROOT / args.output).resolve()
    if not output.is_relative_to(ROOT / 'build'):
        parser.error('Output must be under build/')
    headers = {'baseline': ROOT / 'experiments/klang/core/baselines/production-2026-09-17/klang.h', 'candidate': ROOT / 'include/klang.h'}
    if args.retained:
        archive = json.loads((ROOT / 'experiments/klang/core/osm-comparison-sources.json').read_text(encoding='utf-8'))
        current = headers['candidate'].read_bytes().decode('utf-8')
        begin, end = current.index(archive['start']), current.index(archive['end'])
        for label, saved in archive['variants'].items():
            restored = (current[:begin] + saved['source'] + current[end:]).encode('utf-8')
            if hashlib.sha256(restored).hexdigest() != saved['sha256']:
                parser.error('Core outside the OSM has changed; cannot reconstruct the exact retained header ' + label)
            directory = output / 'headers' / label
            directory.mkdir(parents=True, exist_ok=True)
            header = directory / 'klang.h'
            header.write_bytes(restored)
            headers[label] = header
    if args.previous_header:
        previous = args.previous_header.resolve(strict=True)
        if previous.name != 'klang.h' or not previous.is_relative_to(ROOT):
            parser.error('--previous-header must name a workspace klang.h')
        headers['previous'] = previous
    if args.experiments:
        headers.update(signed=headers['candidate'], reference=headers['candidate'])
    for label, path in args.compare_header:
        comparison = Path(path).resolve(strict=True)
        if not label.replace('-', '').isalnum() or label in headers or comparison.name != 'klang.h' or not comparison.is_relative_to(ROOT):
            parser.error('--compare-header requires a unique alphanumeric label and workspace klang.h')
        headers[label] = comparison
    if not set(args.signed_header) <= set(headers):
        parser.error('--signed-header must name a selected header')
    if args.only_comparisons:
        headers.pop('baseline')
        headers.pop('candidate')
        if not headers:
            parser.error('--only-comparisons needs a comparison header')
    source = ROOT / 'tests/klang/osm-benchmark.cpp'
    results = []
    flags = ['/nologo', '/std:c++17', '/EHsc', '/Od' if args.debug else '/O2', '/fp:fast', '/MTd' if args.debug else '/MT',
             '/D_DEBUG' if args.debug else '/DNDEBUG',
             '/DNOMINMAX', '/D_CRT_SECURE_NO_WARNINGS', '/wd4244', '/wd4305', '/showIncludes']
    if args.opaque:
        flags.append('/DOSM_OPAQUE')
    for label, header in headers.items():
        directory = output / label
        directory.mkdir(parents=True, exist_ok=True)
        exe = directory / 'benchmark.exe'
        definitions = ['/DOSM_SIGNED'] if label == 'signed' else ['/DOSM_REFERENCE'] if label == 'reference' else []
        command = [compiler, *flags, *definitions, '/I' + str(header.parent), str(source),
                   '/Fo' + str(directory / 'benchmark.obj'), '/Fe' + str(exe)]
        compile = subprocess.run(command, text=True, capture_output=True, errors='replace', timeout=120)
        log = compile.stdout + compile.stderr
        (directory / 'compiler.log').write_text(log, encoding='utf-8')
        if compile.returncode or header.as_posix().lower() not in log.replace('\\', '/').lower():
            print(log[-4000:])
            return 1
        repeated = []
        for repeat in range(args.repeats):
            signed = label in ['candidate', 'signed', 'reference', *args.signed_header]
            run_command = [str(exe), *(['--crossing' if args.crossing else '--signed'] if signed else [])]
            run = subprocess.run(run_command, capture_output=True, text=True, timeout=60, check=True)
            (directory / f'metrics-{repeat}.csv').write_text(run.stdout)
            repeated.append([{k: v if k == 'wave' else float(v) for k, v in row.items()}
                             for row in csv.DictReader(io.StringIO(run.stdout))])
        rows = []
        for i, first in enumerate(repeated[0]):
            row = dict(first)
            row['median_ns'] = statistics.median(run[i]['median_ns'] for run in repeated)
            row['min_ns'] = min(run[i]['min_ns'] for run in repeated)
            row['max_ns'] = max(run[i]['max_ns'] for run in repeated)
            rows.append(row)
        inputs = [header, source]
        if label in ['signed', 'reference']:
            inputs.append(ROOT / 'experiments/klang/core' / ('osm-' + label + '.h'))
        results.append(dict(header=label, sha256=hashlib.sha256(header.read_bytes()).hexdigest(),
                            hashes={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},
                            command=command, run_command=run_command, repetitions=repeated, metrics=rows))
        print(label, f'{args.repeats} runs, {len(rows)} cases; medians retained', flush=True)
    version = subprocess.run([compiler, *(['--version'] if 'clang' in compiler.lower() else [])],
                             text=True, capture_output=True, errors='replace')
    (output / 'results.json').write_text(json.dumps(dict(
        date=datetime.now(timezone.utc).isoformat(), machine=platform.platform(), processor=platform.processor(),
        compiler_version=version.stdout + version.stderr, debug=args.debug, opaque=args.opaque, repeats=args.repeats, rate=48000, frames=2000000, passes=5,
        modes={'0': 'set once', '1': 'unchanged frequency setter per sample', '2': 'varying frequency per sample',
               '3': 'negative set once', '4': 'negative unchanged setter', '5': 'negative varying frequency',
               '6': 'through-zero varying frequency', '7': 'alternating +440/-440 every sample'},
        source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(), results=results), indent=2) + '\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
