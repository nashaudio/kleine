// Scalar oscillator CPU cost; no audio device, allocation or file I/O in the timed loop.
#include <klang.h>
#include <cstdio>
#include <array>
#include <chrono>
#ifdef OSM_SIGNED
#include "../../experiments/klang/core/osm-signed.h"
namespace target = klang::Generators::Fast::signed_frequency;
#elif defined(OSM_REFERENCE)
#include "../../experiments/klang/core/osm-reference.h"
namespace target = klang::Generators::Fast::reference;
#else
namespace target = klang::optimised;
#endif

volatile double consumed = 0;

#ifdef OSM_OPAQUE
// Keep runtime virtual dispatch opaque to the caller, as a separate workload.
#ifdef _MSC_VER
__declspec(noinline)
#else
__attribute__((noinline))
#endif
double renderOpaque(klang::Oscillator& osc, int mode, int frames, const std::array<float, 256>& frequencies) {
    double sum = 0;
    for (int i = 0; i < frames; ++i) {
        if (mode == 1) osc.set(440);
        if (mode == 2) osc.set(frequencies[i & 255]);
        if (mode == 4) osc.set(-440);
        if (mode == 5) osc.set(-frequencies[i & 255]);
        if (mode == 6) osc.set((frequencies[i & 255] - 440) * 4);
        if (mode == 7) osc.set(i & 1 ? -440 : 440);
        osc.process();
        sum += float(osc.out);
    }
    return sum;
}
#endif

template<class Osc>
void bench(const char* name, int mode) {
    std::array<float, 256> frequencies;
    for (int i = 0; i < 256; ++i) frequencies[i] = float(440 + 200 * std::sin(i * .03));
    double times[5];
    constexpr int frames = 2000000;
    for (int pass = 0; pass < 5; ++pass) {
        Osc osc;
        osc.set(mode >= 3 ? -440 : 440, 0);
        const auto start = std::chrono::steady_clock::now();
#ifdef OSM_OPAQUE
        const double sum = renderOpaque(osc, mode, frames, frequencies);
#else
        double sum = 0;
        for (int i = 0; i < frames; ++i) {
            if (mode == 1) osc.set(440);
            if (mode == 2) osc.set(frequencies[i & 255]);
            if (mode == 4) osc.set(-440);
            if (mode == 5) osc.set(-frequencies[i & 255]);
            if (mode == 6) osc.set((frequencies[i & 255] - 440) * 4);
            if (mode == 7) osc.set(i & 1 ? -440 : 440);
            osc.process();
            sum += float(osc.out);
        }
#endif
        const auto end = std::chrono::steady_clock::now();
        consumed = sum;
        times[pass] = std::chrono::duration<double, std::nano>(end - start).count() / frames;
    }
    std::sort(times, times + 5);
    std::printf("%s,%d,%zu,%.9g,%.9g,%.9g\n", name, mode, sizeof(Osc), times[0], times[2], times[4]);
}

int main(int argc, char** argv) {
    klang::fs = 48000;
    std::puts("wave,mode,bytes,min_ns,median_ns,max_ns");
    // Runtime selection gives every header the same loop/inlining opportunities.
    const int modes = argc == 2 && std::strcmp(argv[1], "--crossing") == 0 ? 8
                    : argc == 2 && std::strcmp(argv[1], "--signed") == 0 ? 6 : 3;
    for (int mode = 0; mode < modes; ++mode) {
        bench<target::Saw>("saw", mode);
        bench<target::Triangle>("triangle", mode);
        bench<target::Square>("square", mode);
        bench<target::Pulse>("pulse", mode);
    }
}
