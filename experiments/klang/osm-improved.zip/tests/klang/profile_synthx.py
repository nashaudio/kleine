"""Profile the actual SynTHX signal flow with production, V2 and reflection Saws.

Uses one shared core for non-oscillator code. Only the Saw member type in a
generated model copy changes; original model/core files are never edited.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import shutil
import statistics
import subprocess
import sys

from compare_osm_versions import ROOT, prepare, sha


def generate(output, extensions=False, all_variants=False, combined=False):
    subprocess.run([sys.executable, str(ROOT/'tests/klang/osm_codegen_variants.py'),
                    '--output', str(output/'base')], check=True, capture_output=True)
    common = output/'base/force-inline/klang.h'
    assert sha(common) == '9a8a99d97c82e79ccaa7683f268c7abb613ec7293f9025d6ee2a2a30111dc5c7'
    headers = prepare(output/'sources')
    original = headers['original'].read_text()
    a = original.index('\t\tnamespace Fast {')
    b = original.index('\t\t/// Wavetable-based oscillators', a)
    production = ('// Unchanged production Fast namespace, isolated for comparison.\n'
                  '// Klang Open License 1.0: licenses/Klang-Open-License-1.0.txt\n'
                  'namespace production { using namespace klang;\n' + original[a:b] + '\n}\n'
                  'using BenchSaw = production::Fast::Saw;\n')
    v2 = '''// Adapter for the unmodified Farbrausch V2 C++ render routine.
#include "v2-oscillator.h"
struct BenchSaw : klang::Oscillator {
    V2OscProbe osc{};
    klang::param cached = -1;
    const double scale = 4294967296.0 / double(klang::fs);
    BenchSaw() { osc.gain = 1; set(1000); }
    void set(klang::param hz) override {
        if (cached != hz) {
            cached = frequency = hz;
            osc.freq = int(double(float(hz)) * scale);
        }
    }
    void reset() override { osc.cnt = 0; }
    void process() override {
        float sample = 0;
        osc.renderTriSaw(&sample, 1);
        out = sample;
    }
};
'''
    model = (ROOT/'examples/SynTHX.k').read_text()
    assert model.count('Saw osc;') == 1
    model = model.replace('Saw osc;', 'BenchSaw osc;')
    variants = {}
    native = 'using BenchSaw = klang::optimised::Saw;\n'
    selections = [('production', production), ('v2', v2), ('reflection', native)]
    extension_headers = {}
    if extensions or all_variants or combined:
        if extensions:
            selections = [('reflection', native)]
        selections += [('multicycle', native), ('fractional-duty', native)]
        extension_names = ['multicycle', 'fractional-duty']
        if combined:
            selections = [('reflection', native), ('combined', native)]
            extension_names = ['combined']
        base = common.read_text()
        start = base.index('\t\t\tstruct OSM {')
        end = base.index('\t\t\t/// @cond\n\t\t\tstruct Osm', start)
        for name in extension_names:
            generated = output/'extensions'/name
            subprocess.run([sys.executable, str(ROOT/'tests/klang/osm_extension_variants.py'),
                            '--variant', name, '--output', str(generated)], check=True, capture_output=True)
            header = generated/'headers'/name/'klang.h'
            candidate = header.read_text()
            ca = candidate.index('\t\t\tstruct OSM {')
            cb = candidate.index('\t\t\t/// @cond\n\t\t\tstruct Osm', ca)
            assert candidate[:ca] == base[:start] and candidate[cb:] == base[end:]
            extension_headers[name] = header
    for name, source in selections:
        directory = output/'variants'/name
        directory.mkdir(parents=True, exist_ok=True)
        (directory/'selected-saw.h').write_text(source)
        (directory/'SynTHX.k').write_text(model)
        if name == 'v2':
            shutil.copyfile(headers['v2'], directory/'v2-oscillator.h')
        if name in extension_headers:
            shutil.copyfile(extension_headers[name], directory/'klang.h')
        variants[name] = directory
    return common, variants


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default='cl.exe')
    parser.add_argument('--driver', choices=['cl', 'gnu'], default='cl')
    parser.add_argument('--flag', action='append', default=[], help='Additional compiler option; use --flag=VALUE')
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--output', default='build/osm-synthx/msvc-release')
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--passes', type=int, default=3)
    parser.add_argument('--compile-only', action='store_true')
    parser.add_argument('--extensions', action='store_true', help='Compare reflection with the two existing, separate exceptional-case fixes')
    parser.add_argument('--all-variants', action='store_true', help='Compare all five Saws, keeping the two fixes separate')
    parser.add_argument('--combined', action='store_true', help='Compare reflection with both exceptional-case fixes combined')
    args = parser.parse_args()
    output = (ROOT/args.output).resolve()
    if sum([args.extensions, args.all_variants, args.combined]) > 1:
        parser.error('Choose one of --extensions, --all-variants or --combined')
    if not output.is_relative_to(ROOT/'build') or args.repeats < 1 or args.passes < 1:
        parser.error('Use a build/ output and positive counts')
    compiler = shutil.which(args.compiler)
    if not compiler:
        parser.error('Use an x64 Visual Studio developer prompt')
    common, variants = generate(output, args.extensions, args.all_variants, args.combined)
    source = ROOT/'tests/klang/synthx-profile.cpp'
    inputs = [ROOT/'examples/SynTHX.k', ROOT/'include/klang.h',
              ROOT/'experiments/klang/core/baselines/production-2026-09-17/klang.h',
              ROOT/'experiments/klang/core/klang.h', ROOT/'experiments/klang/core/osm-reflected.inc',
              ROOT/'build/farbrausch-v2/synth_core.cpp', common, source, Path(__file__)]
    inputs += [p for directory in variants.values() for p in directory.glob('*') if p.suffix in ['.h', '.k']]
    inputs += [ROOT/'tests/klang/osm_codegen_variants.py', ROOT/'tests/klang/compare_osm_versions.py',
               ROOT/'tests/klang/check_v2_source.py', ROOT/'experiments/klang/core/osm-comparison-sources.json']
    if args.extensions or args.all_variants:
        inputs += [ROOT/'tests/klang/osm_extension_variants.py',
                   ROOT/'experiments/klang/core/osm-multicycle.inc',
                   ROOT/'experiments/klang/core/osm-fractional-duty.inc']
    if args.combined:
        inputs += [ROOT/'tests/klang/osm_extension_variants.py',
                   ROOT/'experiments/klang/core/osm-combined.inc']
    hashes = {str(p.relative_to(ROOT)): sha(p) for p in inputs}
    flags = ['/nologo', '/std:c++17', '/EHsc', '/Od' if args.debug else '/O2', '/fp:fast',
             '/MTd' if args.debug else '/MT', '/D_DEBUG' if args.debug else '/DNDEBUG',
             '/DNOMINMAX', '/D_CRT_SECURE_NO_WARNINGS', '/wd4244', '/wd4305', '/showIncludes']
    if args.driver == 'gnu':
        flags = ['-std=c++17', '-fexceptions', '-O0' if args.debug else '-O2', '-ffast-math',
                 '-static', '-D_DEBUG' if args.debug else '-DNDEBUG',
                 '-DNOMINMAX', '-D_CRT_SECURE_NO_WARNINGS', '-H']
    flags += args.flag
    records = {}
    for name, directory in variants.items():
        exe = directory/'benchmark.exe'
        selected = directory/'klang.h' if (directory/'klang.h').exists() else common
        command = [compiler, *flags, '/I'+str(directory), '/I'+str(common.parent),
                   str(source), '/Fo'+str(directory/'benchmark.obj'), '/Fe'+str(exe),
                   '/FAs', '/Fa'+str(directory/'benchmark.asm')]
        if args.driver == 'gnu':
            command = [compiler, *flags, '-I'+str(directory), '-I'+str(common.parent),
                       '-MD', '-MF', str(directory/'benchmark.d'), str(source), '-o', str(exe)]
        build = subprocess.run(command, capture_output=True, text=True, errors='replace', timeout=120)
        log = build.stdout + build.stderr
        (directory/'compiler.log').write_text(log)
        includes = (directory/'benchmark.d').read_text() if args.driver == 'gnu' and (directory/'benchmark.d').exists() else log
        if build.returncode or selected.as_posix().lower() not in includes.replace('\\','/').lower():
            print('Compilation/header verification failed:', build.returncode, log[-7000:]); return 1
        if args.driver == 'gnu':
            assembly = [*command[:-2], '-S', '-o', str(directory/'benchmark.asm')]
            asm = subprocess.run(assembly, capture_output=True, text=True, errors='replace', timeout=120)
            (directory/'assembly.log').write_text(asm.stdout + asm.stderr)
            if asm.returncode:
                print(asm.stderr[-7000:]); return 1
        records[name] = dict(command=command, selected_header=str(selected.relative_to(ROOT)),
                             selected_header_sha256=sha(selected), repetitions=[])
        if args.driver == 'gnu':
            records[name]['assembly_command'] = assembly
        print(name, 'compiled', flush=True)
    if args.compile_only:
        return 0
    for name, directory in variants.items():
        command = [str(directory/'benchmark.exe'), 'validate', str(directory/'held.f32')]
        run = subprocess.run(command, capture_output=True, text=True, timeout=180)
        records[name]['validation'] = dict(command=command, returncode=run.returncode, output=run.stdout+run.stderr)
        print(name, run.stdout.strip(), flush=True)
        if run.returncode:
            return 1
    orders = []
    for repeat in range(args.repeats):
        names = list(variants)
        order = names[repeat % len(names):] + names[:repeat % len(names)]
        orders.append(order)
        for name in order:
            command = [str(variants[name]/'benchmark.exe'), str(args.passes)]
            run = subprocess.run(command, capture_output=True, text=True, check=True, timeout=240)
            (variants[name]/f'metrics-{repeat}.csv').write_text(run.stdout)
            rows = [{k: float(v) for k,v in row.items()} for row in csv.DictReader(io.StringIO(run.stdout))]
            assert len(rows) == 2
            records[name]['repetitions'].append(rows)
            print(name, repeat+1, [round(row['median_ms'], 2) for row in rows], flush=True)
    for record in records.values():
        record['metrics'] = []
        for i in range(2):
            row = dict(record['repetitions'][0][i])
            row['median_ms'] = statistics.median(rep[i]['median_ms'] for rep in record['repetitions'])
            row['ms_per_audio_second'] = row['median_ms']/2
            row['one_core_percent'] = row['ms_per_audio_second']/10
            row['ns_per_stereo_frame'] = row['median_ms']*1e6/row['frames']
            record['metrics'].append(row)
    version = subprocess.run([compiler, *(['--version'] if args.driver == 'gnu' or 'clang' in compiler.lower() else [])],
                             capture_output=True, text=True)
    unchanged = all(sha(ROOT/p)==h for p,h in hashes.items())
    report = dict(date=datetime.now(timezone.utc).isoformat(), machine=platform.platform(), processor=platform.processor(),
                  compiler_version=version.stdout+version.stderr, compiler_environment={v:os.environ.get(v) for v in ['CL','_CL_']},
                  debug=args.debug, rate=48000, block=64, frames=96000, seed=12345, midi_pitch=26,
                  passes=args.passes, repeats=args.repeats, execution_orders=orders, hashes=hashes, sources_unchanged=unchanged,
                  common_header=str(common.relative_to(ROOT)),
                  extensions=args.extensions, all_variants=args.all_variants, combined=args.combined, driver=args.driver,
                  modes={'0':'held defaults: pitch=.6 detune=.5', '1':'block controls: pitch 0 to 1, detune 1 to .5'},
                  results=records)
    (output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
    return 0 if unchanged else 1


if __name__ == '__main__':
    raise SystemExit(main())
