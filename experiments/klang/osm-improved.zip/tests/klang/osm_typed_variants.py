"""Build the typed OSM prototype from the retained inlining candidate."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from compare_osm_versions import ROOT


def method_end(source, start):
    index = source.index('{', start) + 1
    depth = 1
    while depth:
        depth += (source[index] == '{') - (source[index] == '}')
        index += 1
    return index


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='build/osm-typed/headers')
    args = parser.parse_args()
    output = (ROOT / args.output).resolve()
    if not output.is_relative_to(ROOT / 'build'):
        parser.error('Output must be under build/')
    subprocess.run([sys.executable, str(ROOT / 'tests/klang/osm_codegen_variants.py'),
                    '--output', str(output / 'codegen')], check=True, capture_output=True)
    base = (output / 'codegen/force-inline/klang.h').read_text(encoding='utf-8')
    typed = base
    a = typed.index('KLANG_OSM_INLINE void set(param hz)', typed.index('struct OSM {'))
    b = method_end(typed, a)
    setter = typed[a:b].replace('void set(param hz)', 'void setTyped(param hz)')
    setter = setter.replace('if (waveform == &OSM::saw)', 'if constexpr (!PulseWave)')
    typed = typed[:a] + ('template<bool PulseWave>\n' + setter + '\n'
        '\t\t\t\tKLANG_OSM_INLINE void set(param hz) {\n'
        '\t\t\t\t\tif (waveform == &OSM::saw) setTyped<false>(hz);\n'
        '\t\t\t\t\telse setTyped<true>(hz);\n'
        '\t\t\t\t}\n') + typed[b:]
    a = typed.index('KLANG_OSM_INLINE void set(param hz, param phase)', typed.index('struct OSM {'))
    b = method_end(typed, a)
    setter = typed[a:b].replace('void set(param hz, param phase)', 'void setTyped(param hz, param phase)')
    setter = setter.replace('set(hz);', 'setTyped<PulseWave>(hz);')
    typed = typed[:b] + '\n\t\t\t\ttemplate<bool PulseWave>\n' + setter + '\n' + typed[b:]
    a = typed.index('\t\t\t/// Descending saw, averaged over each sample interval.')
    b = typed.index('#undef KLANG_OSM_INLINE', a)
    fragment = (ROOT / 'experiments/klang/core/osm-typed.inc').read_text(encoding='utf-8')
    typed = typed[:a] + ''.join('\t\t\t' + x if x.strip() else x for x in fragment.splitlines(keepends=True)) + typed[b:]
    marker = 'using Osm::set;'
    converted = typed.replace(marker, '''// Expose the existing conversion bridge to the inliner. It remains virtual.
                KLANG_OSM_INLINE operator const signal& () override {
                    this->process();
                    return out;
                }
                KLANG_OSM_INLINE operator const signal& () const override { return out; }
                using Osm::set;''', 1)
    result = {}
    for name, source in [('control', base), ('typed', typed), ('typed-conversions', converted)]:
        path = output / name / 'klang.h'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(source, encoding='utf-8')
        result[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    (output / 'variants.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
