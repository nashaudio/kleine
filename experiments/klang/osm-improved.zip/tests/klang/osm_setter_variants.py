"""Reproducible setter alternatives, based on the retained first reflection trial."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new)


def variants():
    archive = json.loads((ROOT / 'experiments/klang/core/osm-reflection-results.json').read_text(encoding='utf-8'))
    old = archive['tested_osm_sources']['reflected-phase']['source']
    result = {'setter-original': old}
    compact = once(old, 'f = 0, width = 0, inverseStep = 0;', 'f = 0, inverseStep = 0;')
    compact = once(compact, '\t\t\t\t\t\twidth = float(step) * tickScale;\n', '')
    compact = compact.replace('inverseStep = width > 0 ? 1.f / width : 0;', 'inverseStep = f > 0 ? 1.f / f : 0;')
    compact = compact.replace('(1 - width)', '(1 - f)').replace(' - width ', ' - f ')
    result['setter-no-width'] = compact
    syntax = compact.replace('frequency.value != hz.value', 'frequency != hz')
    syntax = syntax.replace('hz.value > -sampleRate && hz.value < sampleRate', 'hz > -sampleRate && hz < sampleRate')
    result['setter-syntax'] = syntax
    cached = once(syntax, 'if (reverse != (ticks < 0)) {', 'const bool negative = ticks < 0;\n\t\t\t\t\t\tif (reverse != negative) {')
    cached = cached.replace('reverse = ticks < 0;', 'reverse = negative;')
    cached = cached.replace('reverse ? -ticks : ticks', 'negative ? -ticks : ticks')
    result['setter-cached-sign'] = cached
    magnitude = once(cached,
        'const long long ticks = hz > -sampleRate && hz < sampleRate ? static_cast<long long>(hz.value * stepScale) : 0;',
        'const float magnitude = std::fabs(hz.value);\n'
        '\t\t\t\t\t\tconst unsigned int ticks = magnitude < sampleRate ? static_cast<unsigned int>(magnitude * stepScale) : 0;')
    magnitude = once(magnitude, 'const bool negative = ticks < 0;', 'const bool negative = hz < 0 && ticks != 0;')
    magnitude = once(magnitude, 'step = static_cast<unsigned int>(negative ? -ticks : ticks);', 'step = ticks;')
    result['setter-unsigned'] = magnitude
    no_step = once(magnitude, '\t\t\t\tunsigned int step = 0;\n', '')
    no_step = once(no_step, '\t\t\t\t\t\tstep = ticks;\n', '')
    no_step = once(no_step, 'std::memcpy(&increment.amount, &step, sizeof(step));', 'std::memcpy(&increment.amount, &ticks, sizeof(ticks));')
    no_step = once(no_step, 'f = float(step) * tickScale;', 'f = float(ticks) * tickScale;')
    no_step = no_step.replace('float(step -', 'float(static_cast<unsigned int>(increment.amount) -')
    result['setter-no-step'] = no_step
    # Diagnostic: change only the cached scale's precision, keeping conversion bounded.
    float_scale = once(no_step, 'double stepScale = 0;', 'float stepScale = 0;')
    float_scale = once(float_scale, 'static_cast<unsigned int>(magnitude * stepScale)',
        'static_cast<unsigned int>(std::min(double(magnitude * stepScale), turn - 1))')
    result['setter-float-scale'] = float_scale
    return result
