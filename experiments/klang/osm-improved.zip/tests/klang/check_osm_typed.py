"""Check typed OSM frontend compatibility, signed DSP and actual Klang syntax cost."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from compare_osm_versions import ROOT


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default='cl.exe')
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--contracts-only', action='store_true')
    parser.add_argument('--variant', choices=['typed', 'typed-conversions'], default='typed')
    parser.add_argument('--output', default='build/osm-typed/msvc')
    args = parser.parse_args()
    compiler = shutil.which(args.compiler)
    output = (ROOT / args.output).resolve()
    if not compiler or not output.is_relative_to(ROOT / 'build'):
        parser.error('Use a VS developer prompt and an output under build/')
    headers = {name: ROOT / 'build/osm-typed/headers' / name / 'klang.h' for name in ['control', args.variant]}
    flags = ['/nologo', '/std:c++17', '/EHsc', '/Od' if args.debug else '/O2', '/fp:fast',
             '/MTd' if args.debug else '/MT', '/D_DEBUG' if args.debug else '/DNDEBUG',
             '/DNOMINMAX', '/D_CRT_SECURE_NO_WARNINGS', '/wd4244', '/wd4305', '/showIncludes']
    source = ROOT / 'tests/klang/osm-typed-contracts.cpp'
    source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    header_hashes = {name: hashlib.sha256(header.read_bytes()).hexdigest() for name, header in headers.items()}
    results = {}
    passed = True
    for name, header in headers.items():
        directory = output / name
        directory.mkdir(parents=True, exist_ok=True)
        exe = directory / 'contracts.exe'
        command = [compiler, *flags, *(['/DOSM_TYPED'] if name != 'control' else []),
                   '/I' + str(header.parent), str(source), '/Fo' + str(directory / 'contracts.obj'), '/Fe' + str(exe)]
        build = subprocess.run(command, capture_output=True, text=True, errors='replace', timeout=120)
        log = build.stdout + build.stderr
        (directory / 'compiler.log').write_text(log, encoding='utf-8')
        selected = header.as_posix().lower() in log.replace('\\', '/').lower()
        record = {'command': command, 'compile_returncode': build.returncode,
                  'selected_header_verified': selected, 'header_sha256': header_hashes[name]}
        if build.returncode == 0 and selected:
            run = subprocess.run([str(exe)], capture_output=True, text=True, timeout=60)
            record['run'] = {'returncode': run.returncode, 'output': run.stdout + run.stderr}
            passed &= run.returncode == 0
            print(name, run.stdout, flush=True)
        else:
            passed = False
            print('\n'.join(line for line in log.splitlines() if 'error' in line.lower()), flush=True)
        results[name] = record
    report = {'frontend': results, 'source_sha256': source_hash}
    if passed and not args.contracts_only:
        debug = ['--debug'] if args.debug else []
        command = [sys.executable, str(ROOT / 'tests/klang/check_osm.py'), '--fast', '--compiler', compiler,
                   '--header', str(headers[args.variant]), '--output', str(output / 'quality'), *debug]
        passed &= subprocess.run(command).returncode == 0
        report['quality'] = json.loads((output / 'quality/results.json').read_text())
        if passed:
            command = [sys.executable, str(ROOT / 'tests/klang/compare_osm_versions.py'), '--frontend', '--assembly',
                       '--compiler', compiler, '--output', str(output / 'benchmark'), '--repeats', '3',
                       '--versions', 'control', args.variant, *debug]
            for name, header in headers.items():
                command += ['--compare-header', name, str(header)]
            passed &= subprocess.run(command).returncode == 0
            report['benchmark'] = json.loads((output / 'benchmark/results.json').read_text())
    report['sources_unchanged'] = (source_hash == hashlib.sha256(source.read_bytes()).hexdigest() and
        all(header_hashes[name] == hashlib.sha256(header.read_bytes()).hexdigest() for name, header in headers.items()))
    passed &= report['sources_unchanged']
    report['passed'] = passed
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
