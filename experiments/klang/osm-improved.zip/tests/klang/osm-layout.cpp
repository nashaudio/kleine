// Layout and separately inspectable routines for OSM cost attribution.
#include <klang.h>
#include <cstdio>
#include <cstddef>
using OSM = klang::Generators::Fast::OSM;
extern "C" __declspec(noinline) float probe_saw(OSM& osm) { return osm.saw(); }
extern "C" __declspec(noinline) float probe_pulse(OSM& osm) { return osm.pulse(); }
extern "C" __declspec(noinline) void probe_set(OSM& osm, float hz) { osm.set(hz); }
int main() {
    std::printf("OSM=%zu align=%zu Saw=%zu\n", sizeof(OSM), alignof(OSM), sizeof(klang::optimised::Saw));
#define MEMBER(name) std::printf(#name " offset=%zu bytes=%zu\n", offsetof(OSM, name), sizeof(OSM::name))
    MEMBER(waveform); MEMBER(increment); MEMBER(offset); MEMBER(phaseOffset);
    MEMBER(breakpoint); MEMBER(state);
#ifndef OSM_NO_STEP
    MEMBER(step);
#endif
    MEMBER(frequency); MEMBER(sampleRate);
    MEMBER(col); MEMBER(rising); MEMBER(upSlope); MEMBER(downBias);
}
