"""Generate bounded assembly-led reflection experiments; no core files are changed."""
import argparse
import hashlib
import json
import re
from pathlib import Path
from compare_osm_versions import ROOT, prepare


def variants(source):
    # These distances are [0, increment] in UpDown, hence strictly below 2**32.
    bounded = source.replace('float(end - breakpoint)',
                             'float(end - static_cast<unsigned int>(breakpoint))')
    bounded = bounded.replace('float(static_cast<unsigned int>(increment.amount) - (end - breakpoint))',
                              'float(static_cast<unsigned int>(increment.amount) - (end - static_cast<unsigned int>(breakpoint)))')
    # Reconstruct the previous side from the interval's start. This removes the
    # loop-carried history dependency, at the cost of one extra comparison.
    start = bounded.index('\tState tick() {')
    end = bounded.index('\tfloat output()', start)
    endpoints = bounded[:start] + '''\tState tick() {
		const unsigned int end = offset.position;
		const unsigned int step = static_cast<unsigned int>(increment.amount);
		const unsigned int begin = end - step;
		offset.position += step;
		return State((begin < breakpoint ? 2 : 0) |
			(end < breakpoint ? 1 : 0) | (end < step ? 4 : 0));
	}
''' + bounded[end:]
    vector = bounded.replace('float(4294967296ull - end)', '(float(0xffffffffu - end) + 1.f)')
    return {'bounded': bounded, 'endpoints': endpoints, 'vector-distances': vector}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='build/osm-codegen/candidates')
    args = parser.parse_args()
    output = (ROOT / args.output).resolve()
    if not output.is_relative_to(ROOT / 'build'):
        parser.error('Output must be under build/')
    base = prepare(output)['reflection'].read_text(encoding='utf-8')
    fragment = (ROOT / 'experiments/klang/core/osm-reflected.inc').read_text(encoding='utf-8')
    begin = base.index('\t\t\tstruct OSM {')
    end = base.index('\t\t\t/// @cond\n\t\t\tstruct Osm', begin)
    result = {}
    for name, changed in variants(fragment).items():
        # Drop only the fragment's introductory comments, as in the current header.
        changed = changed[changed.index('struct OSM {'):]
        header = base[:begin] + ''.join('\t\t\t' + x if x.strip() else x
                                         for x in changed.splitlines(keepends=True)) + base[end:]
        path = output / name / 'klang.h'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(header, encoding='utf-8')
        result[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    # Isolate phase-to-counter quantisation from reassociation across floor().
    # This is setup-only; waveform and frequency setter retain fast math.
    protected = (output / 'vector-distances/klang.h').read_text(encoding='utf-8')
    start = protected.index('\t\t\tstruct Phase {', protected.index('\t\t\tstruct Increment {'))
    stop = protected.index('\n\t\t\t};', start) + len('\n\t\t\t};')
    protected = (protected[:start] + '#pragma float_control(precise, on, push)\n' +
                 protected[start:stop] + '\n#pragma float_control(pop)' + protected[stop:])
    path = output / 'phase-precise' / 'klang.h'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(protected, encoding='utf-8')
    result['phase-precise'] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    # Explicit inlining without final classes/methods or changed model syntax.
    # Compiler-specific spelling is contained within this generated prototype.
    begin = protected.index('\t\t\tstruct OSM {')
    end = protected.index('\t\t\t/// White noise generator', begin)
    region = protected[begin:end]
    region = re.sub(r'^(\s*)(?=(?:OSM|Osm|Saw|Triangle|Square|Pulse)\(|(?:void|float|State) (?:set|setDuty|setBreakpoint|setOffset|reset|sync|coefficients|tick|output|saw|pulse|process)\()',
                    r'\1KLANG_OSM_INLINE ', region, flags=re.MULTILINE)
    prefix = '''#if defined(_MSC_VER)
#define KLANG_OSM_INLINE __forceinline
#elif defined(__clang__) || defined(__GNUC__)
#define KLANG_OSM_INLINE inline __attribute__((always_inline))
#else
#define KLANG_OSM_INLINE inline
#endif
'''
    hinted = protected[:begin] + prefix + region + '#undef KLANG_OSM_INLINE\n' + protected[end:]
    path = output / 'force-inline' / 'klang.h'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(hinted, encoding='utf-8')
    result['force-inline'] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    (output / 'variants.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
