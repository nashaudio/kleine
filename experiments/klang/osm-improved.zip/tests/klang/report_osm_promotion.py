"""Collect the four completed OSM promotion comparisons and export review WAVs.

Run after check_sounds.py has populated build/osm-promotion/models-v2-*.
Retains full reports and hashes; float WAVs are unnormalised and stay in build/.
"""
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[2]
CONFIGS = ('msvc-release', 'msvc-debug', 'clang14-release', 'clang14-debug')


def main():
    reports = {}
    summaries = {}
    listening = []
    for config in CONFIGS:
        path = ROOT / 'build/osm-promotion' / ('models-v2-' + config) / 'results.json'
        report = json.loads(path.read_text())
        assert report['sources_unchanged'] and not report['regressions'], path
        reports[config] = report
        summary = {}
        for label in ('baseline', 'candidate'):
            rows = [r for r in report['results'] if r['header'] == label]
            summary[label] = {}
            for collection in ('examples', 'sounds'):
                cases = [r for r in rows if r['mode'] == 'host-fixture'
                         and r['source'].startswith(collection + '/')]
                renders = [v for r in cases for v in r['renders']]
                summary[label][collection] = dict(
                    cases=len(cases), compiled=sum(r['compiled'] for r in cases),
                    renders=len(renders), silent=sum(v.get('rms') == 0 for v in renders),
                    finite=all(v['returncode'] == 0 and v['finite'] for v in renders),
                    failures=[r['source'] + ':' + r['model'] for r in cases if not r['compiled']])
        comparisons = [c for c in report['comparisons'] if c['reference'] == 'baseline']
        summary['paired_files'] = len(comparisons)
        summary['sample_identical'] = sum(c['sample_identical'] for c in comparisons)
        summary['changed'] = [c for c in comparisons if not c['sample_identical']]
        summaries[config] = summary
        print(config, json.dumps(summary, indent=2))

        if not config.endswith('release'):
            continue
        for row in report['results']:
            if row['source'] not in ('examples/Modulation/Flanger.k',
                                     'examples/Subtractive/Expression.k',
                                     'examples/Modulation/FM2.k'):
                continue
            for render in row['renders']:
                if render['rate'] != 44100:
                    continue
                data = (ROOT / render['path']).read_bytes()
                channels = render['channels']
                frames = len(data) // (4 * channels)
                fmt = struct.pack('<HHIIHH', 3, channels, 44100, 44100 * 4 * channels,
                                  4 * channels, 32)
                body = (b'WAVEfmt ' + struct.pack('<I', len(fmt)) + fmt
                        + b'fact' + struct.pack('<II', 4, frames)
                        + b'data' + struct.pack('<I', len(data)) + data)
                name = f"{config}-{row['model'].lower()}-{row['header']}-44100.wav"
                output = ROOT / 'build/osm-promotion/listening' / name
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_bytes(b'RIFF' + struct.pack('<I', len(body)) + body)
                listening.append(dict(path=output.relative_to(ROOT).as_posix(),
                                      sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
                                      source=render['path'], gain=1, alignment_samples=0))

    evidence = dict(scope='Unchanged models, standalone fixtures; no subjective acceptance implied.',
                    summaries=summaries, reports=reports, listening=listening)
    language = {}
    for label, directory in (('msvc-precise', 'language-msvc-precise'),
                             ('msvc-fast', 'language-msvc-release'),
                             ('clang14-fast', 'language-clang14-release-v2')):
        path = ROOT / 'build/osm-promotion' / directory / 'results.json'
        if path.exists():
            language[label] = json.loads(path.read_text())
    evidence['language_reports'] = language
    main_build = ROOT / 'build/osm-promotion/main-build.json'
    if main_build.exists():
        evidence['main_build'] = json.loads(main_build.read_text())
    target = ROOT / 'experiments/klang/core/osm-promotion-model-results.json'
    target.write_text(json.dumps(evidence, indent=2) + '\n')


if __name__ == '__main__':
    main()
