"""Isolate OSM source/layout choices without changing the experimental core.

From an x64 VS developer prompt, run sequentially for each compiler/build:
  python tests/klang/probe_osm_layout.py --quality --output build/osm-layout/msvc
  python tests/klang/probe_osm_layout.py --debug --output build/osm-layout/debug-msvc
Add --compiler clang-cl.exe for Clang. --variants narrows the comparison.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
from osm_setter_variants import variants as setter_variants

ROOT = Path(__file__).resolve().parents[2]


def replace(source, old, new):
    if source.count(old) != 1:
        raise ValueError('Expected exactly one occurrence: ' + old)
    return source.replace(old, new)


def variants(source):
    result = {'control': source}
    def numerical_cases(function):
        cases = list(re.finditer(r'^\t{5}case (\w+):', function, re.MULTILINE))
        end = function.index('\t\t\t\t\tdefault:', cases[-1].start())
        blocks = {case[1]: function[case.start():cases[i + 1].start() if i + 1 < len(cases) else end]
                  for i, case in enumerate(cases)}
        order = ['Down', 'ReversePeak', 'UpDown', 'Up', 'DownUpDown', 'DownUp', 'ReverseWrap', 'UpDownUp']
        return function[:cases[0].start()] + ''.join(blocks[name] for name in order) + function[end:]
    saw, pulse = source.index('\t\t\t\tfloat saw() {'), source.index('\t\t\t\tfloat pulse() {')
    result['numerical-order'] = source[:saw] + numerical_cases(source[saw:pulse]) + numerical_cases(source[pulse:])
    result['phase-operator'] = replace(source,
        'offset.position += static_cast<unsigned int>(increment.amount);', 'offset += increment;')
    result['inline-carry'] = replace(source,
        'const bool carry = (offset.position < static_cast<unsigned int>(increment.amount)) != reverse;\n'
        '\t\t\t\t\tconst State transition = State(state | (carry ? 4 : 0));',
        'const State transition = State(state | (((offset.position < static_cast<unsigned int>(increment.amount)) != reverse) ? 4 : 0));')
    result['byte-state'] = replace(source, 'enum State {', 'enum State : byte {')

    # Only reorder fields; retain their types and calculations.
    packed = replace(source, '\t\t\t\tunsigned long long breakpoint = 0;\n', '')
    packed = replace(packed, '\t\t\t\tdouble stepScale = 0;\n', '')
    packed = replace(packed, '\t\t\t\tbool reverse = false;\n', '')
    packed = replace(packed, 'Fast::Increment increment;',
        'unsigned long long breakpoint = 0;\n\t\t\t\tdouble stepScale = 0;\n\t\t\t\tFast::Increment increment;')
    packed = replace(packed, 'float upBias = -1, downBias = -1;',
        'float upBias = -1, downBias = -1;\n\t\t\t\tbool reverse = false;')
    result['reorder'] = packed
    packed = replace(packed, 'enum State {', 'enum State : byte {')
    packed = replace(packed, '\t\t\t\tState state = Down;\n', '')
    result['packed-byte'] = replace(packed, 'bool reverse = false;', 'State state = Down;\n\t\t\t\tbool reverse = false;')

    folded = replace(source, 'State state = Down;\n\t\t\t\tbool reverse = false;', 'byte state = Down;')
    folded = replace(folded,
        'state = (offset.position - static_cast<unsigned int>(increment.amount)) < breakpoint ? Up : Down;',
        'state = byte((state & 4) | ((offset.position - static_cast<unsigned int>(increment.amount)) < breakpoint ? Up : Down));')
    folded = replace(folded, 'reverse = ticks < 0;', 'state = byte((state & 3) | (ticks < 0 ? 4 : 0));')
    folded = replace(folded, 'reverse ? -ticks : ticks', '(state & 4) ? -ticks : ticks')
    folded = replace(folded,
        'state = State(((state << 1) | (offset.position < breakpoint)) & 3);',
        'state = byte((state & 4) | (((state << 1) | (offset.position < breakpoint)) & 3));')
    folded = replace(folded,
        'const bool carry = (offset.position < static_cast<unsigned int>(increment.amount)) != reverse;\n'
        '\t\t\t\t\tconst State transition = State(state | (carry ? 4 : 0));',
        'const State transition = State(state ^ (offset.position < static_cast<unsigned int>(increment.amount) ? 4 : 0));')
    result['folded-state'] = folded.replace('reverse ? end + step : end', '(state & 4) ? end + step : end')

    local = replace(source, '\t\t\t\tdouble stepScale = 0;\n', '')
    local = replace(local, '\t\t\t\t\t\t\tstepScale = sampleRate > 0 ? turn / sampleRate : 0;\n', '')
    result['local-scale'] = replace(local, 'const long long ticks =',
        'const double stepScale = sampleRate > 0 ? turn / sampleRate : 0;\n\t\t\t\t\t\tconst long long ticks =')
    result['float-scale'] = replace(source, 'double stepScale = 0;', 'float stepScale = 0;')
    result['float-scale-double-product'] = replace(result['float-scale'],
        'static_cast<long long>(hz.value * stepScale)', 'static_cast<long long>(double(hz.value) * stepScale)')

    # Retain only the integer interval; calculate these floats where they are used.
    fewer = replace(source, 'fallingWidth = 1, f = 0, width = 0, inverseStep = 0;',
        'fallingWidth = 1, inverseStep = 0;')
    fewer = replace(fewer, '\t\t\t\t\t\tf = float(ticks) * tickScale;\n', '')
    fewer = replace(fewer, 'width = float(step) * tickScale;', 'const float width = float(step) * tickScale;')
    fewer = replace(fewer, 'void coefficients() {',
        'void coefficients() {\n\t\t\t\t\tconst float f = (reverse ? -float(step) : float(step)) * tickScale;')
    fewer = fewer.replace('case UpDownUp: {', 'case UpDownUp: {\n\t\t\t\t\t\tconst float width = float(step) * tickScale;')
    fewer = fewer.replace('case DownUpDown: {', 'case DownUpDown: {\n\t\t\t\t\t\tconst float width = float(step) * tickScale;')
    result['fewer-caches'] = fewer

    # Boundary distances are strictly below one turn in these transition cases.
    narrow = source
    for expression in ['end - breakpoint', 'step - (end - breakpoint)',
                       'breakpoint - end', 'step - (breakpoint - end)',
                       'step - (4294967296ull - end)']:
        narrow = narrow.replace('float(' + expression + ')', 'float(static_cast<unsigned int>(' + expression + '))')
    result['narrow-distances'] = narrow.replace('float(4294967296ull - end)', '(float(0xffffffffu - end) + 1.f)')
    result['bounded-distances'] = narrow.replace('float(4294967296ull - end)',
        'float(static_cast<long long>(4294967296ull - end))')

    magnitude = replace(source,
        'const long long ticks = hz.value > -sampleRate && hz.value < sampleRate ? static_cast<long long>(hz.value * stepScale) : 0;\n'
        '\t\t\t\t\t\tconst unsigned int bits = static_cast<unsigned int>(ticks);\n'
        '\t\t\t\t\t\tstd::memcpy(&increment.amount, &bits, sizeof(bits));\n'
        '\t\t\t\t\t\treverse = ticks < 0;\n'
        '\t\t\t\t\t\tstep = static_cast<unsigned int>(reverse ? -ticks : ticks);\n'
        '\t\t\t\t\t\tf = float(ticks) * tickScale;',
        'const double ticks = hz.value > -sampleRate && hz.value < sampleRate ? hz.value * stepScale : 0;\n'
        '\t\t\t\t\t\tstep = static_cast<unsigned int>(std::fabs(ticks));\n'
        '\t\t\t\t\t\treverse = step != 0 && ticks < 0;\n'
        '\t\t\t\t\t\tconst unsigned int bits = reverse ? 0u - step : step;\n'
        '\t\t\t\t\t\tstd::memcpy(&increment.amount, &bits, sizeof(bits));\n'
        '\t\t\t\t\t\tf = (reverse ? -float(step) : float(step)) * tickScale;')
    result['unsigned-setup'] = magnitude

    no_step = replace(source, '\t\t\t\tunsigned int step = 0;\n', '')
    no_step = replace(no_step, 'step = static_cast<unsigned int>(reverse ? -ticks : ticks);',
        'const unsigned int step = static_cast<unsigned int>(reverse ? -ticks : ticks);')
    general_step = 'reverse ? 0u - static_cast<unsigned int>(increment.amount) : static_cast<unsigned int>(increment.amount)'
    for name, specialised in [('derived-step', False), ('transition-step', True)]:
        trial = no_step
        for case in ['UpDown', 'DownUp', 'ReversePeak', 'ReverseWrap', 'UpDownUp', 'DownUpDown']:
            expression = general_step
            if specialised and case in ['UpDown', 'DownUp']:
                expression = 'static_cast<unsigned int>(increment.amount)'
            if specialised and case in ['ReversePeak', 'ReverseWrap']:
                expression = '0u - static_cast<unsigned int>(increment.amount)'
            trial = replace(trial, 'case ' + case + ': {',
                'case ' + case + ': {\n\t\t\t\t\t\tconst unsigned int step = ' + expression + ';')
        result[name] = trial

    folded_packed = replace(result['folded-state'], '\t\t\t\tunsigned long long breakpoint = 0;\n', '')
    folded_packed = replace(folded_packed, '\t\t\t\tdouble stepScale = 0;\n', '')
    folded_packed = replace(folded_packed, '\t\t\t\tbyte state = Down;\n', '')
    folded_packed = replace(folded_packed, 'Fast::Increment increment;',
        'unsigned long long breakpoint = 0;\n\t\t\t\tdouble stepScale = 0;\n\t\t\t\tFast::Increment increment;')
    result['folded-packed'] = replace(folded_packed, 'float upBias = -1, downBias = -1;',
        'float upBias = -1, downBias = -1;\n\t\t\t\tbyte state = Down;')
    bounded = result['folded-packed']
    for expression in ['end - breakpoint', 'step - (end - breakpoint)',
                       'breakpoint - end', 'step - (breakpoint - end)',
                       'step - (4294967296ull - end)']:
        bounded = bounded.replace('float(' + expression + ')', 'float(static_cast<unsigned int>(' + expression + '))')
    result['folded-bounded'] = bounded.replace('float(4294967296ull - end)',
        'float(static_cast<long long>(4294967296ull - end))')

    # C++17 specialisation supplies a genuinely forward-only sample routine.
    split = replace(source, 'State tick() {', 'template<bool Signed> State tick() {')
    split = replace(split, ')) != reverse;', ')) != (Signed && reverse);')
    split = replace(split, 'float saw() {',
        'float saw() { return sawSample<true>(); }\n\t\t\t\tfloat sawForward() { return sawSample<false>(); }\n'
        '\t\t\t\ttemplate<bool Signed> float sawSample() {')
    split = replace(split, 'float pulse() {',
        'float pulse() { return pulseSample<true>(); }\n\t\t\t\tfloat pulseForward() { return pulseSample<false>(); }\n'
        '\t\t\t\ttemplate<bool Signed> float pulseSample() {')
    split = split.replace('switch (tick())', 'switch (tick<Signed>())')
    split = split.replace('case ReversePeak:', 'case ReversePeak: if constexpr (!Signed) return 0;')
    split = split.replace('case ReverseWrap:', 'case ReverseWrap: if constexpr (!Signed) return 0;')
    split = split.replace('reverse ? end + step : end', '(Signed && reverse) ? end + step : end')
    result['branch-split'] = split
    pointer = replace(split, 'const Waveform waveform;', 'Waveform waveform;\n\t\t\t\tconst bool pulseWave;')
    pointer = replace(pointer, 'OSM(Waveform waveform) : waveform(waveform) {}',
        'OSM(Waveform waveform) : waveform(waveform == &OSM::pulse ? &OSM::pulseForward : &OSM::sawForward),\n'
        '\t\t\t\t\tpulseWave(waveform == &OSM::pulse) {}')
    result['pointer-split'] = replace(pointer, 'reverse = ticks < 0;',
        'if (reverse != (ticks < 0)) {\n\t\t\t\t\t\t\treverse = ticks < 0;\n'
        '\t\t\t\t\t\t\twaveform = reverse ? (pulseWave ? &OSM::pulse : &OSM::saw)\n'
        '\t\t\t\t\t\t\t\t: (pulseWave ? &OSM::pulseForward : &OSM::sawForward);\n\t\t\t\t\t\t}')

    # Unlike pointer-split, specialise the reverse routine too.
    directions = replace(source, 'State tick() {', 'template<bool Reverse> State tick() {')
    directions = replace(directions, ')) != reverse;', ')) != Reverse;')
    directions = replace(directions, 'float saw() {',
        'float saw() { return reverse ? sawSample<true>() : sawSample<false>(); }\n'
        '\t\t\t\tfloat sawForward() { return sawSample<false>(); }\n'
        '\t\t\t\tfloat sawReverse() { return sawSample<true>(); }\n'
        '\t\t\t\ttemplate<bool Reverse> float sawSample() {')
    directions = replace(directions, 'float pulse() {',
        'float pulse() { return reverse ? pulseSample<true>() : pulseSample<false>(); }\n'
        '\t\t\t\tfloat pulseForward() { return pulseSample<false>(); }\n'
        '\t\t\t\tfloat pulseReverse() { return pulseSample<true>(); }\n'
        '\t\t\t\ttemplate<bool Reverse> float pulseSample() {')
    directions = directions.replace('switch (tick())', 'switch (tick<Reverse>())')
    for name in ['UpDown', 'DownUp']:
        directions = directions.replace('case '+name+':', 'case '+name+': if constexpr (Reverse) return 0;')
    for name in ['ReversePeak', 'ReverseWrap']:
        directions = directions.replace('case '+name+':', 'case '+name+': if constexpr (!Reverse) return 0;')
    directions = directions.replace('reverse ? end + step : end', 'Reverse ? end + step : end')
    directions = replace(directions, 'const Waveform waveform;', 'Waveform waveform;\n\t\t\t\tconst bool pulseWave;')
    directions = replace(directions, 'OSM(Waveform waveform) : waveform(waveform) {}',
        'OSM(Waveform waveform) : waveform(waveform == &OSM::pulse ? &OSM::pulseForward : &OSM::sawForward),\n'
        '\t\t\t\t\tpulseWave(waveform == &OSM::pulse) {}')
    result['pointer-directions'] = replace(directions, 'reverse = ticks < 0;',
        'if (reverse != (ticks < 0)) {\n\t\t\t\t\t\t\treverse = ticks < 0;\n'
        '\t\t\t\t\t\t\twaveform = reverse ? (pulseWave ? &OSM::pulseReverse : &OSM::sawReverse)\n'
        '\t\t\t\t\t\t\t\t: (pulseWave ? &OSM::pulseForward : &OSM::sawForward);\n\t\t\t\t\t\t}')

    # Keep the promising identity prototype as readable C++ for review.
    reflected = (ROOT / 'experiments/klang/core/osm-reflected.inc').read_text(encoding='utf-8')
    result['reflected-phase'] = ''.join('\t\t\t' + line if line.strip() else line
                                       for line in reflected.splitlines(keepends=True))

    # Diagnostic only: intentionally removes signed support to isolate sign costs.
    forward = replace(source, 'bool reverse = false;', 'static constexpr bool reverse = false;')
    result['constant-forward'] = replace(forward, '\t\t\t\t\t\treverse = ticks < 0;\n', '')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default='cl.exe')
    parser.add_argument('--output', default='build/osm-layout/msvc')
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--quality', action='store_true')
    parser.add_argument('--signed', action='store_true', help='Include negative-frequency timings for the signed variants')
    parser.add_argument('--crossing', action='store_true', help='Also time through-zero and alternating-sign setters')
    parser.add_argument('--only-comparisons', action='store_true', help='Benchmark only selected variants')
    parser.add_argument('--repeats', type=int, default=1)
    parser.add_argument('--variants', nargs='+')
    parser.add_argument('--header', type=Path, help='Use a retained workspace klang.h as the base for exact reproduction')
    args = parser.parse_args()
    compiler = shutil.which(args.compiler)
    if not compiler:
        parser.error('Use an x64 VS developer environment')
    output = (ROOT / args.output).resolve()
    if not output.is_relative_to(ROOT / 'build'):
        parser.error('Output must be inside build/')
    original = ROOT / 'experiments/klang/core/klang.h'
    if args.header:
        original = args.header.resolve(strict=True)
        if original.name != 'klang.h' or not original.is_relative_to(ROOT):
            parser.error('--header must name a workspace klang.h')
    raw = original.read_bytes()
    text = raw.decode('utf-8').replace('\r\n', '\n')
    start = text.index('\t\t\tstruct OSM {')
    end = text.index('\t\t\t/// @cond\n\t\t\tstruct Osm', start)
    alternatives = variants(text[start:end])
    alternatives.update(setter_variants())
    selected = args.variants or list(alternatives)
    if not set(selected) <= set(alternatives):
        parser.error('Unknown variant')
    output.mkdir(parents=True, exist_ok=True)
    records = {}
    bench = [sys.executable, str(ROOT / 'tests/klang/benchmark_osm.py'), '--compiler', compiler,
             '--output', str(output / 'benchmark'), '--repeats', str(args.repeats)]
    if args.debug:
        bench += ['--debug']
    if args.crossing:
        bench += ['--crossing']
    if args.only_comparisons:
        bench += ['--only-comparisons']
    for name in selected:
        directory = output / name
        directory.mkdir(parents=True, exist_ok=True)
        header = directory / 'klang.h'
        candidate = text[:start] + alternatives[name] + text[end:]
        if name in ['pointer-split', 'pointer-directions']:
            candidate = candidate.replace('out = osm.saw();', 'out = osm.output();').replace('out = osm.pulse();', 'out = osm.output();')
        elif name == 'reflected-phase' or name.startswith('setter-'):
            candidate = candidate.replace('Direction is cached in set(); backwards boundary states use separate formulas.',
                                          'Negative Hz reflects phase in set(); both directions use the forward state machine.')
            if name == 'reflected-phase' or name.startswith('setter-') and name not in ['setter-original', 'setter-no-width']:
                candidate = candidate.replace('frequency.value != hz.value', 'frequency != hz')
        elif name == 'branch-split':
            candidate = candidate.replace('out = osm.saw();', 'out = osm.reverse ? osm.saw() : osm.sawForward();')
            candidate = candidate.replace('out = osm.pulse();', 'out = osm.reverse ? osm.pulse() : osm.pulseForward();')
        header.write_bytes(candidate.encode('utf-8'))
        flags = ['/nologo', '/std:c++17', '/EHsc', '/Od' if args.debug else '/O2', '/fp:fast',
                 '/MTd' if args.debug else '/MT', '/D_DEBUG' if args.debug else '/DNDEBUG', '/DNOMINMAX',
                 '/D_CRT_SECURE_NO_WARNINGS', '/wd4244', '/wd4305']
        if 'unsigned int step = 0;' not in alternatives[name]:
            flags.append('/DOSM_NO_STEP')
        command = [compiler, *flags, '/I' + str(directory), str(ROOT / 'tests/klang/osm-layout.cpp'),
                   '/FAs', '/Fa' + str(directory / 'layout.asm'), '/Fo' + str(directory / 'layout.obj'),
                   '/Fe' + str(directory / 'layout.exe')]
        build = subprocess.run(command, capture_output=True, text=True, errors='replace', timeout=120)
        (directory / 'compiler.log').write_text(build.stdout + build.stderr, encoding='utf-8')
        if build.returncode:
            print(name, build.stdout[-2000:], build.stderr[-2000:])
            return 1
        layout = subprocess.check_output([str(directory / 'layout.exe')], text=True)
        record = dict(sha256=hashlib.sha256(header.read_bytes()).hexdigest(), command=command, layout=layout)
        if args.quality and name != 'constant-forward':
            check = [sys.executable, str(ROOT / 'tests/klang/check_osm.py'), '--compiler', compiler,
                     '--header', str(header), '--output', str(directory / 'quality')]
            if args.debug:
                check += ['--debug']
            run = subprocess.run(check, text=True, capture_output=True, timeout=120)
            record['quality_returncode'] = run.returncode
            record['quality'] = json.loads((directory / 'quality/results.json').read_text())
            print(name, 'quality', run.returncode, layout.splitlines()[0], flush=True)
        else:
            print(name, layout.splitlines()[0], flush=True)
        records[name] = record
        bench += ['--compare-header', name, str(header)]
        if args.signed and name != 'constant-forward':
            bench += ['--signed-header', name]
    subprocess.run(bench, check=True)
    unchanged = raw == original.read_bytes()
    report = dict(base_sha256=hashlib.sha256(raw).hexdigest(), core_unchanged=unchanged,
                  variants=records, benchmark=json.loads((output / 'benchmark/results.json').read_text()))
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    return 0 if unchanged else 1


if __name__ == '__main__':
    raise SystemExit(main())
