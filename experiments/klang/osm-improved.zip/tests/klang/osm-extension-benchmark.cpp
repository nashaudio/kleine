// Same ordinary and extreme workloads for the control and extended OSM headers.
#include <klang.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>

volatile double consumed = 0;

template<class Osc>
void bench(const char* name, int mode) {
    constexpr int frames = 2000000, block = 64;
#ifdef OSM_COMBINED_BENCH
    const bool tiny = mode >= 8;
    if (tiny) mode -= 2;
#endif
    std::array<float, 256> hz, duty;
    for (int i = 0; i < 256; ++i) {
#ifdef OSM_FRACTIONAL_DUTY_BENCH
        hz[i] = float((mode >= 6 ? .001 : 200) * std::sin(i * .03));
#else
        hz[i] = float((mode >= 6 ? 150000 : 200) * std::sin(i * .03));
#ifdef OSM_COMBINED_BENCH
        if (tiny) hz[i] = float(.001 * std::sin(i * .03));
#endif
#endif
        if (mode == 2 || mode == 5) hz[i] += 440;
        duty[i] = float(.5 + .4 * std::sin(i * .047));
#ifdef OSM_COMBINED_BENCH
        if (tiny) duty[i] *= 1e-6f;
#endif
#ifdef OSM_FRACTIONAL_DUTY_BENCH
        if (mode >= 6) duty[i] *= 1e-6f;
#endif
    }
    double times[5], checksum = 0;
    for (int pass = 0; pass < 5; ++pass) {
        Osc osc;
#ifdef OSM_FRACTIONAL_DUTY_BENCH
        osc.set(mode >= 6 ? .001f : 440.f, 0);
#else
        osc.set(mode == 6 ? 60000 : 440, 0);
#ifdef OSM_COMBINED_BENCH
        if (tiny) osc.set(.001f, 0);
#endif
#endif
        if (name[0] == 'p') osc.setDuty(.25f);
#ifdef OSM_COMBINED_BENCH
        if (tiny) osc.setDuty(1e-6f);
#endif
#ifdef OSM_FRACTIONAL_DUTY_BENCH
        if (mode >= 6) osc.setDuty(1e-6f);
#endif
        double sum = 0;
        const auto start = std::chrono::steady_clock::now();
        for (int frame = 0; frame < frames; frame += block) {
            float audio[block]{};
            for (int i = 0; i < block; ++i) {
                const int index = (frame + i) & 255;
                if (mode == 4 || mode == 5 || mode == 7) osc.setDuty(duty[index]);
#ifdef OSM_FRONTEND
                klang::signal sample;
                if (mode == 1) osc(440) * 1.f >> sample;
                else if (mode == 2 || mode == 3 || mode == 5 || mode == 7) osc(hz[index]) * 1.f >> sample;
                else osc >> sample;
                audio[i] += float(sample);
#else
                if (mode == 1) osc.set(440);
                else if (mode == 2 || mode == 3 || mode == 5 || mode == 7) osc.set(hz[index]);
                osc.process();
                audio[i] += float(osc.out);
#endif
            }
            for (float sample : audio) sum += sample;
        }
        const auto end = std::chrono::steady_clock::now();
        consumed = checksum = sum;
        times[pass] = std::chrono::duration<double, std::nano>(end - start).count() / frames;
    }
    std::sort(times, times + 5);
#ifdef OSM_COMBINED_BENCH
    if (tiny) mode += 2;
#endif
    std::printf("%s,%d,%zu,%.9g,%.9g,%.9g,%.12g\n", name, mode, sizeof(Osc), times[0], times[2], times[4], checksum);
}

int main() {
    klang::fs = 48000;
    std::puts("wave,mode,bytes,min_ns,median_ns,max_ns,checksum");
#ifdef OSM_COMBINED_BENCH
    constexpr int modes = 10;
#else
    constexpr int modes = 8;
#endif
    for (int mode = 0; mode < modes; ++mode) {
        bench<klang::optimised::Saw>("saw", mode);
        bench<klang::optimised::Triangle>("triangle", mode);
        bench<klang::optimised::Square>("square", mode);
        bench<klang::optimised::Pulse>("pulse25", mode);
    }
}
