# Klang language regression tests

These tests compare the archived previous production core with the working
`include/klang.h`; existing model sources remain unchanged. See the
[OSM promotion report](../../experiments/klang/core/OSM-PROMOTION.md). Generated wrappers,
executables, raw float renders and logs go under `build/`.

## Run

From an x64 VS developer command prompt, at the repository root:

```text
python tests/klang/check.py
python tests/klang/check.py --compiler clang-cl.exe --output build/language-regression/clang
python experiments/klang/core/check_compatibility.py
python tests/klang/check_sounds.py --upstream-repo F:/klang/git
python tests/klang/check_sounds.py --upstream-repo F:/klang/git --compiler clang-cl.exe --output build/sound-headers/clang
```

Supply a full compiler path if needed. Python's standard library is sufficient.
The scripts record compiler versions, flags, selected-header include traces,
header/source hashes, results and commands. Upstream sound checks read pinned
Git blobs from the specified repository; they do not change its checkout or
fetch anything. Omit `--upstream-repo` to compare only local headers.

## Language contracts

[arithmetic.cpp](arithmetic.cpp) tests public behaviour rather than private
implementation details:

- Float-backed `signal`/`param` layout and inheritance; arithmetic result types.
- All four arithmetic operations with mutable/const scalar, signal and parameter
  lvalues. Candidate tests add integer/float/double temporaries, both direct
  objects and inline calls returning `Output&`, plus stereo outputs.
- Noncommutative operand order and exactly-once evaluation, including two
  separate generators and source → modifier → output chains.
- Deferred inline setter calls, virtual absolute/relative dispatch, cached const
  reads and feedback input that does not advance processing.
- Existing narrowing of double constants before float signal arithmetic.
- Function-wrapper arithmetic used by the game sounds, including preserving its
  float/double result type instead of silently selecting a new overload.

The runner also builds/runs the existing typed-literal probe: exact literal
types, overload selection and 184,200 sample-identical oscillator frames for
plain, Hz and kHz expressions across 44.1/48 kHz.

[ambiguities.cpp](ambiguities.cpp) retains minimal compile probes:

| Expression family | Previous production | Working header |
| --- | --- | --- |
| `source(440) * .5f` | Fails | Compiles |
| `source(440) >> modifier` | Fails | Still fails |
| `set(envelope, 10)` taking `param` | Fails | Still fails |
| `1 - abs(signal(...))` | Fails | Still fails |
| Bank output routed into mono `signal` | Fails | Still fails |
| `Control >> Modifier` with an integer conversion, as in Train | MSVC fails; Clang compiles | Same |

Known-failure probes must produce the expected diagnostic category and reference
the probe file. A compiler failure for an unrelated reason is not a pass. An
unexpected success also requests review of the expectation. `PASS` on these
probes means the known restriction was reproduced, not that the expression now
works. Baseline/candidate positive contracts run separately so header breakage
cannot turn the whole suite green through compilation failures.

## Sound fixtures

[check_sounds.py](check_sounds.py) first compiles all seven unchanged sound
headers without helpers. Its separately labelled `host-fixture` mode adds only
the dependencies declared in [sound-host.h](sound-host.h):

- `FMath::Tanh(float)` stands in as `std::tanh(float)`.
- `Phasor` uses the definition commented out in `sounds/Bicycle.h`.
- Upstream headers receive `Sound`/stereo `Sound` aliases to `Effect` and `byte`.
- Train explicitly includes `examples/Delay/Reverb2.k`, because its own include
  names `Reverb.k` but its field names `Reverb2`. The actual game Reverb.k has
  since been confirmed identical to this Reverb2 source apart from line endings.

This is not UE emulation or a check of Unreal Build Tool's settings. Model code
is never rewritten to overcome compilation failures. In particular, no DSP or
signal-flow workaround is hidden in these host definitions.

[sound-render.h](sound-render.h) defines six-second control recipes at 44.1 and
48 kHz, with changes at 0/2/4 seconds, `prepare()` every 64 samples, seed 12345,
fresh processes and full float output without normalisation. The period is a
fixed test-host buffer cadence, not a change to the models. Generator-only
components have no `prepare()` call. These fixtures exercise both steady-state
and changing controls; they do not claim exhaustive host/lifecycle coverage.

For successful builds the runner records sample counts, finite values, peak,
RMS, mean, samples beyond ±1, and render hashes. Candidate renders repeat in
fresh processes and must match. Candidate/baseline samples must agree wherever
both run. Upstream comparisons report residuals without assuming that every
branch difference is a defect. Missing/nonfinite/nondeterministic candidate
renders and compile regressions fail the gate; existing compile blockers and
levels above unity remain visible in the report. No test listens to or accepts
the sound on the user's behalf.

## First retained result

16 September 2026, VS 2026 MSVC 19.51.36257 and Clang 22.1.3, Windows x64,
C++17 `/O2 /fp:precise`:

- 147 baseline and 227 candidate runtime language checks pass on each compiler,
  plus compile-time assertions, compile probes and literal checks.
- All 80 model files checked unchanged: MSVC improves 61 → 72; Clang 59 → 70;
  zero new failures.
- Harrier candidate/baseline and Bicycle/Rain candidate/upstream renders are
  sample-identical at both rates wherever the relevant header compiles.
- Train's reconstructed fixture runs only on candidate Clang; it is finite and
  repeatable, but has no compiling reference for an equivalence claim.

See the [full review](../../experiments/klang/core/ARITHMETIC-REVIEW.md) and
[retained evidence](../../experiments/klang/core/arithmetic-review.json).

Next additions should follow actual changes: isolate table initialisation,
resolve the remaining routing/conversion cases with evaluation-count tests,
then add mixed precision, precision-boundary and unit-conversion contracts for
the planned generic numeric core. Full UE builds, multitranslation-unit linkage,
other operating systems and comprehensive host-buffer lifecycle tests remain
separate coverage gaps.

## Supplied game header and oscillator review

The runners accept an optional read-only supplied header:

```text
python tests/klang/check.py --game-header F:/Future/Future.58/Plugins/Klang/Source/Public/klang.h --output build/game-header/language-msvc
python tests/klang/check_sounds.py --game-header F:/Future/Future.58/Plugins/Klang/Source/Public/klang.h --output build/game-header/msvc
python tests/klang/check_sounds.py --game-header F:/Future/Future.58/Plugins/Klang/Source/Public/klang.h --ue-language-flags --output build/game-header/ue-language-flags
python experiments/klang/core/check_compatibility.py --header reference --reference-header F:/Future/Future.58/Plugins/Klang/Source/Public/klang.h --output build/game-header/all-models-msvc
python tests/klang/check_oscillators.py --game-header F:/Future/Future.58/Plugins/Klang/Source/Public/klang.h
```

Add `--compiler clang-cl.exe` and a distinct output directory for Clang.
The game header supplies native Phasor and changes Sound's inheritance; the
fixture uses those interfaces directly. `--ue-language-flags` reproduces the
language/conformance subset of the saved build response, not a full UE build.

The supplied 0.7.9 passes 231 MSVC runtime language checks. Its complete
arithmetic contract fails to compile on Clang, honestly leaving that run red.
It fixes the Function-left-scalar, Bank-mono and Control-routing probes;
inline routing and Envelope-to-param are still diagnosed failures.
[channel-broadcast.cpp](channel-broadcast.cpp) independently records a known
runtime failure in all three headers: a mono value 2 constructs `{2,0,0}`.
The runner requires that exact failure rather than treating any crash as a pass.

[check_oscillators.py](check_oscillators.py) and [oscillators.cpp](oscillators.cpp)
measure the old/new native oscillators independently of PD. They report
waveform/phase diagnostics rather than claim an all-oscillator passing gate.
Snapshots before tick and a consistent Saw breakpoint isolate faults without
editing the reference headers. See the [OSM findings](../../experiments/klang/core/OSM-REVIEW.md),
[game-core review](../../experiments/klang/core/GAME-HEADER-REVIEW.md) and
[retained evidence](../../experiments/klang/core/game-header-review.json).

## Repaired OSM contracts

`python tests/klang/check_osm.py` now checks the default signed-frequency
candidate against independent integrals, with phase, reset, rate-change, virtual
setters and FM/PWM through zero: 18,432 fixtures and 12,616,512 checks.
`--profile signed` retains the historical integration prototype for comparison;
it is not needed for negative-frequency support. `--profile reference` retains the original
strict general-integrator suite (3,840 fixtures). The integrated default passes
with MSVC and Clang, Release and Debug; the retained general reference also
passes on both compilers. Add `--debug`, or `--compiler clang-cl.exe`
and a distinct output directory. `--profile strict` applies full-domain tests
to the fast candidate itself and exposes unsupported frequencies and extreme
duty-rounding differences. The fast/signed suite measures both counter-quantised
accuracy and ordinary audio accuracy against the unquantised duty request.
`check_oscillators.py` includes the candidate by default;
the optional `--game-header` adds the supplied UE reference. Only the historical
headers use the earlier diagnostic subclasses.

`python tests/klang/benchmark_osm.py` records scalar processing cost against
production; run it without competing compile/render jobs. `--experiments` adds
signed/general profiles; `--opaque` separately measures virtual dispatch;
`--debug` measures unoptimised `/Od /fp:fast /MTd` throughput, not just correctness;
`--retained` reconstructs hash-verified positive-only and prior signed headers.
`--repeats 3` retains repeated runs and median-of-medians summaries. No device or
file I/O occurs in the timed loop. See the [fast repair and limits](../../experiments/klang/core/OSM-FAST.md)
and [current Release/Debug performance review](../../experiments/klang/core/OSM-POSITIVE-PATH.md).

`probe_osm_layout.py` generates isolated storage/arithmetic/dispatch alternatives
under `build/`, emits layout and assembly probes, and optionally runs the signed
quality suite before benchmarking. `--variants` selects individual changes;
`--header` accepts a retained workspace base. Float-scale failures are expected
diagnostics and the `constant-forward` diagnostic deliberately drops signed
support. See the [case-by-case findings](../../experiments/klang/core/OSM-LAYOUT.md).

`--signed` also measures negative-frequency workloads. The `pointer-directions`
variant specialises both directions; `reflected-phase` reads the reviewable
[OSM fragment](../../experiments/klang/core/osm-reflected.inc) and uses a forward
state machine for both signs. See [reflection results and limits](../../experiments/klang/core/OSM-REFLECTION.md).

The `setter-*` variants compare setter changes against the archived original
reflection. `--crossing` adds through-zero and alternating-sign timings, and
`--only-comparisons` omits unrelated automatic benchmark entries. See the
[setter and precision review](../../experiments/klang/core/OSM-SETTER.md).

`compare_osm_versions.py` compares original Klang, upstream V2 C++, the retained
positive-only fix and the current reflection prototype in one buffered harness.
It shows fixed 64-sample calls and one-sample calls with fixed/unchanged/varying
frequency. See the [four-way comparison](../../experiments/klang/core/OSM-FOUR-WAY.md).

### Current compiler settings (17 September 2026)

Klang test runners now link the static CRT (`/MT`, or `/MTd` for Debug).
OSM performance runners (`benchmark_osm.py`, `compare_osm_versions.py`, and the
layout probe) use `/fp:fast`, matching Klang Studio. Release uses `/O2`; Debug
uses `/Od`. Historical reports retain their original flags and timings.
The correctness runners keep `/fp:precise` as the independent reference;
`check_osm.py --fast` checks a fast-math candidate with precise oracle arithmetic.
It also constructs exceptional inputs under precise semantics, so fast-math
assumptions in standard-library helpers cannot invalidate the test itself.

`osm_codegen_variants.py` generates the assembly-led reflection candidates.
`compare_osm_versions.py --assembly` retains assembler listings, `--flag` adds
an explicit compiler option, and `--compare-header NAME PATH` benchmarks a
generated candidate. `OSM_QUALIFIED` and `OSM_INLINE_CONSTRUCTION` are harness
diagnostics for static dispatch and construction visibility; they are not core
changes. See [compiler/code-generation findings](../../experiments/klang/core/OSM-CODEGEN.md).

`osm_typed_variants.py` generates a typed oscillator adapter without sealing
public classes or overrides. `check_osm_typed.py` checks frontend syntax,
polymorphism and signed waveform quality, then benchmarks actual Klang
expressions on the selected compiler. Use `--debug`, `--contracts-only`, or
`--variant typed-conversions` as needed. `compare_osm_versions.py --frontend`
selects the expression benchmark independently. See the
[typed OSM report](../../experiments/klang/core/OSM-TYPED.md) for compatibility,
performance limits and why `final` is not used.

`osm_extension_variants.py` generates the separately gated multi-cycle trial.
`check_osm.py --profile multicycle --fast` tests the extended frequency contract;
`compare_osm_versions.py --extensions` measures ordinary FM/PWM and wide-frequency
workloads. The extension passed correctness but failed the MSVC Release CPU gate,
so fractional-duty work was not started. See the
[extension report](../../experiments/klang/core/OSM-EXTENSIONS.md).

The subsequent independent step-2 trial uses
`osm_extension_variants.py --variant fractional-duty --output build/osm-fractional-duty`,
`check_osm.py --profile fractional-duty --fast` and
`compare_osm_versions.py --fractional-duty`. It retains fractional duty without
the multi-cycle extension. The new quality profile checks unquantised duty,
including sub-counter-tick cases; the performance harness replaces the two
wide-frequency cases with tiny-duty workloads. Correctness passes on both
compilers in Release/Debug, but Release FM/PWM costs fail the performance gate.
See the [fractional-duty report](../../experiments/klang/core/OSM-FRACTIONAL-DUTY.md).

`profile_synthx.py` compares production, upstream V2 C++ and recommended reflection
Saws inside the actual SynTHX model. A generated copy changes only the Saw member
type; non-oscillator code uses one shared core. It measures held and moving
controls through the full stereo synth host, validates output, retains assembly,
and rotates variant order between repetitions. Use `--compiler clang-cl.exe`
and/or `--debug`, with distinct build output paths. See the
[SynTHX results](../../experiments/klang/core/OSM-SYNTHX.md), including the
one-sample V2 adapter's scope and the arithmetic support required by SynTHX.

`profile_synthx.py --extensions` instead compares reflection with the existing
multi-cycle and fractional-duty candidates separately. The generated headers
must match the common core outside OSM. The
[separate-fix results](../../experiments/klang/core/OSM-SYNTHX-EXTENSIONS.md)
include longer Release confirmation runs and fresh baseline measurements.

`profile_synthx.py --all-variants` compares all five Saws in one rotating run;
the exceptional-case fixes are still separate. `--driver gnu` supports Studio's
native compiler DLL launcher, using `-O2`/`-O0`, `-ffast-math` and `-static`.
GNU builds retain dependency files to verify the selected header and produce
assembly separately. Additional compiler options can be passed with `--flag=VALUE`.
See the [Clang 14.0.6 results and launcher setup](../../experiments/klang/core/OSM-SYNTHX-CLANG14.md)
for the actual target, bundled libraries and differences from `/MT` and `/MTd`.

`osm_extension_variants.py --variant combined` now generates reflection with
both fixes. `check_osm.py --profile combined --fast` checks both contracts and
their interactions, including tiny-duty PWM across signed whole-cycle frequency
boundaries. `check_osm.py --driver gnu` also supports Studio's Clang DLL launcher.
`profile_synthx.py --combined` compares this candidate with a fresh reflection
baseline. See the [combined report](../../experiments/klang/core/OSM-COMBINED.md)
for MSVC and Studio Clang 14.0.6 Release/Debug results and exact commands.

The repaired core intentionally changes oscillator audio. Previous model
comparisons, including the explained Harrier increment-quantisation difference,
describe the earlier general repair. The new fast repair's impact on extant
models is the next review, not a claimed pass in this oscillator-only step.

## Farbrausch source comparison

`python tests/klang/check_v2_source.py` extracts the pinned V2 C++ waveform
routines unchanged and runs 112 diagnostic cases. It also generates a small
float repair of the old Klang OSM, checks waveform metrics and benchmarks it
against production. Add `--compiler clang-cl.exe` and a distinct `--output`
directory for Clang. Run benchmarks sequentially without competing work.

The expected source is `build/farbrausch-v2/synth_core.cpp`; its download URL
and verified hash are recorded in the [source review](../../experiments/klang/core/V2-SOURCE-REVIEW.md)
and [retained evidence](../../experiments/klang/core/v2-source-review.json).
All generated headers, binaries and raw output stay under `build/`.
This executes the 2012 C++ port, not the original assembly. Successful execution
means the diagnostics completed, not that its low-frequency cases or the small
repair satisfy the full OSM contract suite.
