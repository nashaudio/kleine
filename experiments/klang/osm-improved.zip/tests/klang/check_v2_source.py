"""Extract pinned V2 routines verbatim and measure a small Klang-only correction.

The original assembler is inspected separately; this executes the later C++ port.
Downloaded source and all generated headers/results stay under build/.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
SOURCE_HASH = '4cc93eb78a985ddfb32e01b151878cec4a43a9c58185c90c75fa16a050c1e2b0'


def function(text, signature):
    start = text.index(signature)
    body = text.index('{', start)
    depth = 1
    end = body + 1
    while depth:
        if text[end] == '{': depth += 1
        if text[end] == '}': depth -= 1
        end += 1
    return text[start:end]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default='cl.exe')
    parser.add_argument('--source-dir', type=Path, default=ROOT / 'build/farbrausch-v2')
    parser.add_argument('--output', default='build/farbrausch-v2/msvc')
    args = parser.parse_args()
    compiler = shutil.which(args.compiler)
    if not compiler: parser.error('Use an x64 VS developer prompt')
    output = (ROOT / args.output).resolve()
    if not output.is_relative_to(ROOT / 'build'): parser.error('Output must be under build/')
    output.mkdir(parents=True, exist_ok=True)
    source = args.source_dir / 'synth_core.cpp'
    if hashlib.sha256(source.read_bytes()).hexdigest() != SOURCE_HASH:
        parser.error('Expected pinned Farbrausch source recorded in V2-SOURCE-REVIEW.md')
    original = source.read_text()
    extracted = '// Extracted unchanged from Farbrausch V2, Tammo Hinrichs / Fabian Giesen.\n'
    extracted += '// v2/LICENSE.txt places the directory in the public domain.\n'
    extracted += '#include <cstdint>\n#include <cassert>\nusing sF32=float; using sU32=uint32_t; using sInt=int;\n'
    extracted += '#define COVER(x)\nstatic const sF32 fc32bit=2147483648.0f;\nunion FloatBits {sF32 f; sU32 u;};\n'
    for sig in ['static sF32 bits2float(', 'static inline sF32 sqr(', 'static inline sF32 utof23(', 'static inline sU32 ftou32(']:
        extracted += function(original, sig) + '\n'
    extracted += 'struct V2OscProbe { sU32 cnt,brpt; sInt freq; bool ring; sF32 gain;\n'
    enum_start = original.index('enum OSMTransitionCode')
    enum_end = original.index('};', enum_start) + 2
    extracted += original[enum_start:enum_end] + '\n'
    for sig in ['inline void output(', 'inline sU32 osm_init(', 'inline sU32 osm_tick(',
                'void renderTriSaw(', 'void renderPulse(']:
        extracted += function(original, sig) + '\n'
    extracted += '};\n'
    (output / 'v2-oscillator.h').write_text(extracted)

    # Diagnostic only: preserve the original float OSM and phase increment,
    # correcting the port's ordering, phase scale, duty defaults and initialisation.
    minimal = (ROOT / 'experiments/klang/core/baselines/production-2026-09-17/klang.h').read_text()
    repaired = (ROOT / 'experiments/klang/core/klang.h').read_text()
    old_phase = function(minimal, 'Phase& operator=(klang::Phase phase)')
    new_phase = function(repaired, 'Phase& operator=(klang::Phase phase)')
    minimal = minimal.replace(old_phase, new_phase, 1)
    minimal = minimal.replace('State state;', 'State state = Down;', 1).replace('float delta;', 'float delta = 0;', 1)
    minimal = minimal.replace('param frequency = 0; // cached to optimise updates', 'param frequency = -1; // cached to optimise updates', 1)
    minimal = minimal.replace('rcpf = 1.f / f', 'rcpf = f > 0 ? 1.f / f : 0', 1)
    minimal = minimal.replace('c1 = 1.f / col;', 'c1 = col > 0 ? 1.f / col : 0;', 1)
    minimal = minimal.replace('c2 = -1.f / (1.0f - col);', 'c2 = col < 1 ? -1.f / (1.0f - col) : 0;', 1)
    minimal = minimal.replace('float saw() { return saw(offset - col, tick()); }',
                              'float saw() { const float p = offset - col; return saw(p, tick()); }', 1)
    minimal = minimal.replace('float pulse() { return pulse(offset, tick()); }',
                              'float pulse() { const float p = offset; return pulse(p, tick()); }', 1)
    minimal = minimal.replace('Triangle() : Osm(&OSM::saw, 1.f)', 'Triangle() : Osm(&OSM::saw, 0.5f)', 1)
    minimal = minimal.replace('Square() : Osm(&OSM::pulse, 1.0f)', 'Square() : Osm(&OSM::pulse, 0.5f)', 1)
    minimal = minimal.replace('{ osm.setDuty(_Duty); }', '{ osm.setDuty(_Duty); osm.set(frequency); }', 1)
    minimal_dir = output / 'minimal'
    minimal_dir.mkdir(exist_ok=True)
    (minimal_dir / 'klang.h').write_text(minimal)

    flags = ['/nologo', '/std:c++17', '/EHsc', '/O2', '/fp:precise', '/MT', '/DNDEBUG',
             '/DNOMINMAX', '/D_CRT_SECURE_NO_WARNINGS', '/wd4244', '/wd4305', '/showIncludes']
    results = []
    for label, include, cpp in [
        ('v2-cpp', output, ROOT / 'tests/klang/v2-source-probe.cpp'),
        ('minimal-metrics', minimal_dir, ROOT / 'tests/klang/oscillators.cpp'),
        ('baseline-cost', ROOT / 'include', ROOT / 'tests/klang/osm-benchmark.cpp'),
        ('minimal-cost', minimal_dir, ROOT / 'tests/klang/osm-benchmark.cpp')]:
        exe = output / (label + '.exe')
        cmd = [compiler, *flags, '/I' + str(include), str(cpp),
               '/Fo' + str(output / (label + '.obj')), '/Fe' + str(exe)]
        compiled = subprocess.run(cmd, capture_output=True, text=True, errors='replace', timeout=120)
        log = compiled.stdout + compiled.stderr
        (output / (label + '.log')).write_text(log, encoding='utf-8')
        header = include / ('v2-oscillator.h' if label == 'v2-cpp' else 'klang.h')
        if compiled.returncode or header.as_posix().lower() not in log.replace('\\','/').lower():
            print(log[-3000:]); return 1
        run = subprocess.run([str(exe)], capture_output=True, text=True, check=True, timeout=60)
        (output / (label + '.csv')).write_text(run.stdout)
        rows = list(csv.DictReader(io.StringIO(run.stdout)))
        results.append(dict(case=label, command=cmd, header_sha256=hashlib.sha256(header.read_bytes()).hexdigest(), metrics=rows))
        print(label, len(rows), 'measurements', flush=True)
    version = subprocess.run([compiler, *(['--version'] if 'clang' in compiler.lower() else [])], capture_output=True, text=True)
    report = dict(date=datetime.now(timezone.utc).isoformat(), compiler_version=version.stdout + version.stderr,
                  upstream_sha256=SOURCE_HASH, generated_extraction_sha256=hashlib.sha256((output / 'v2-oscillator.h').read_bytes()).hexdigest(),
                  input_sha256={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                                [ROOT / 'experiments/klang/core/baselines/production-2026-09-17/klang.h', ROOT / 'experiments/klang/core/klang.h', Path(__file__).resolve(),
                                 ROOT / 'tests/klang/v2-source-probe.cpp', ROOT / 'tests/klang/osm-benchmark.cpp',
                                 ROOT / 'tests/klang/oscillators.cpp']}, results=results)
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
