// Independent analytic waveform integrals, not a copy of the OSM's transition code.
#include <klang.h>
#ifdef OSM_REFERENCE
#include "../../experiments/klang/core/osm-reference.h"
#endif
#include <cstdio>
#include <cstdint>
#include <cmath>
#include <limits>
#include <chrono>

namespace fast = klang::Generators::Fast;
static int checks = 0, failures = 0, fixtures = 0;
static double worst = 0;

void check(bool okay, const char* label) {
    ++checks;
    if (!okay && failures++ < 12) std::printf("FAIL %s\n", label);
}

#include "oscillator-reference.h"
using namespace oscillator_reference;

template<class Osc>
void compare(Osc& osc, std::uint32_t& phase, float hz, int rate, double duty,
             bool pulse, int frames, std::uint32_t offset = 0) {
    const std::int64_t ticks = step(hz, rate);
    const double delta = double(ticks) / turn;
    for (int n = 0; n < frames; ++n) {
        const double p = double(std::uint32_t(phase + offset)) / turn;
        const double expected = ticks ? (primitive(p, duty, pulse) - primitive(p - delta, duty, pulse)) / delta
                                     : point(p, duty, pulse);
        osc.process();
        const double actual = float(osc.out);
        const double error = std::fabs(actual - expected);
        worst = std::max(worst, error);
        if ((!std::isfinite(actual) || error > 2e-6 || actual < -1.000001 || actual > 1.000001)
                && failures < 12)
            std::printf("rate=%d hz=%.9g duty=%.9g pulse=%d frame=%d actual=%.12g expected=%.12g\n",
                        rate, hz, duty, pulse, n, actual, expected);
        check(std::isfinite(actual) && error <= 2e-6, "analytic interval mean");
        check(actual >= -1.000001 && actual <= 1.000001, "bounded output");
        phase += static_cast<std::uint32_t>(ticks);
    }
}

template<class Osc>
void matrix(bool pulse, double defaultDuty) {
    for (int rate : {44100, 48000}) {
        klang::fs = rate;
        for (float hz : {0.f, .01f, 1.f, 100.f, 440.f, 1000.f, float(rate) * .4999f,
                         float(rate) * .5f, float(rate) * .75f, float(rate), float(rate) * 2.25f,
                         -.01f, -440.f, -float(rate) * .5f, -float(rate) * 2.25f}) {
            for (float duty : {0.f, .000001f, .01f, .25f, .5f, .99f, .999999f, 1.f}) {
                for (float angle : {0.f, fast::twoPi * .137f, fast::twoPi * .5f, -fast::twoPi * .25f}) {
                    Osc osc;
                    osc.set(hz, angle, duty);
                    auto phase = position(angle);
                    compare(osc, phase, hz, rate, duty, pulse, 257);
                    check(float(osc.frequency) == hz, "public frequency cache");
                    ++fixtures;
                }
            }
        }
        Osc defaultOsc;
        auto phase = std::uint32_t(0);
        compare(defaultOsc, phase, 1000, rate, defaultDuty, pulse, 1024);
        defaultOsc.set(440);
        compare(defaultOsc, phase, 440, rate, defaultDuty, pulse, 1024);
        defaultOsc.reset(); phase = 0;
        compare(defaultOsc, phase, 440, rate, defaultDuty, pulse, 1024);

        // Audio-rate FM/PWM, crossing through zero and changing direction.
        Osc mod;
        phase = 0;
        for (int i = 0; i < 6000; ++i) {
            const float hz = float(12000 * std::sin(i * .031));
            const float duty = float(.5 + .5 * std::sin(i * .047));
            mod.set(hz);
            mod.setDuty(duty);
            compare(mod, phase, hz, rate, duty, pulse, 1);
        }

        mod.set(440, 0, .5);
        phase = 0;
        mod.set(klang::relative{.25f});
        compare(mod, phase, 440, rate, .5, pulse, 256, 0x40000000u);
        mod.set(440, klang::relative{.5f});
        compare(mod, phase, 440, rate, .5, pulse, 256, 0x80000000u);
        mod.reset(); phase = 0;
        compare(mod, phase, 440, rate, .5, pulse, 256, 0x80000000u);
        // Absolute phase clears modulation, reset preserves configured duty.
        mod.set(440, fast::twoPi * .25f);
        phase = 0x40000000u;
        compare(mod, phase, 440, rate, .5, pulse, 256);
        klang::fs = rate == 44100 ? 48000 : 44100;
        mod.set(440);
        compare(mod, phase, 440, int(klang::fs), .5, pulse, 256);
        for (float duty : {-2.f, 2.f}) {
            mod.set(440, 0, duty);
            phase = 0;
            compare(mod, phase, 440, int(klang::fs), duty < 0 ? 0 : 1, pulse, 256);
        }
        for (float hz : {std::numeric_limits<float>::infinity(), std::numeric_limits<float>::quiet_NaN()}) {
            mod.set(hz, 0, .5);
            mod.process();
            check(std::isfinite(float(mod.out)), "invalid frequency stays finite");
        }
    }
}

void phaseAndSine() {
    for (float cycles : {0.f, .25f, .5f, .75f, 1.f, -0.25f, -3.f, 7.25f}) {
        fast::Phase phase;
        const float radians = cycles * fast::twoPi;
        phase = radians;
        double expected = double(radians) / fast::twoPi;
        expected -= std::floor(expected);
        check(std::fabs(phase.cycles() - expected) < 1.0 / turn, "wrapped phase scale");
        check(float(phase) >= 0 && float(phase) < 1, "phase conversion range");
        check(std::fabs(phase.radians() - expected * fast::twoPi) < 1e-6, "radians units");
    }
    for (float radians : {std::nextafter(fast::twoPi, 0.f), -std::numeric_limits<float>::denorm_min(),
                          std::numeric_limits<float>::infinity(), std::numeric_limits<float>::quiet_NaN()}) {
        fast::Phase phase;
        phase = radians;
        check(std::isfinite(float(phase)) && float(phase) >= 0 && float(phase) < 1, "phase boundary/invalid input");
    }
    for (int rate : {44100, 48000}) {
        klang::fs = rate;
        for (float hz : {0.f, 1000.f, 440.f, -440.f}) {
            fast::Sine sine;
            const float angle = fast::twoPi * .25f;
            sine.set(hz, angle);
            auto phase = position(angle);
            for (int n = 0; n < 4000; ++n) {
                sine.process();
                const double expected = std::sin(double(phase) / turn * 2 * klang::pi.d);
                check(std::fabs(float(sine.out) - expected) < 8e-6, "shared Sine phase/increment");
                phase += static_cast<std::uint32_t>(step(hz, rate));
            }
        }
        fast::Sine sine;
        sine.set(1000, 0);
        sine.set(klang::relative{.25f});
        sine.process();
        check(std::fabs(float(sine.out) - 1) < 8e-6, "Sine relative phase");
        sine.reset();
        sine.process();
        check(std::fabs(float(sine.out)) < 8e-6, "Sine reset clears phase/offset");
        klang::fs = rate == 44100 ? 48000 : 44100;
        sine.set(1000, 0);
        sine.process();
        sine.process();
        check(std::fabs(float(sine.out) - std::sin(double(step(1000, int(klang::fs))) / turn * 2 * klang::pi.d)) < 8e-6,
              "Sine unchanged frequency after rate change");
    }
}

int main() {
#ifdef OSM_REFERENCE
    namespace target = fast::reference;
#else
    namespace target = fast;
#endif
    matrix<target::Saw>(false, 0);
    matrix<target::Triangle>(false, .5);
    matrix<target::Square>(true, .5);
    matrix<target::Pulse>(true, .5);
    phaseAndSine();
    std::printf("fixtures=%d checks=%d failures=%d max_interval_error=%.12g\n", fixtures, checks, failures, worst);
    return failures ? 1 : 0;
}
