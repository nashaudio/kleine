"""Benchmark old Klang, pinned V2 C++, positive-only fix, and current reflection.

Compiles first, then alternates executable order between timing repetitions.
Run compiler/build configurations sequentially, without competing benchmarks.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import shutil
import statistics
import subprocess

from check_v2_source import SOURCE_HASH, function

ROOT = Path(__file__).resolve().parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(output):
    core = ROOT / 'experiments/klang/core'
    current = (core / 'klang.h').read_bytes().decode('utf-8')
    archive = json.loads((core / 'osm-comparison-sources.json').read_text(encoding='utf-8'))
    a, b = current.index(archive['start']), current.index(archive['end'])
    old = archive['variants']['positive-only']
    positive = (current[:a] + old['source'] + current[b:]).encode('utf-8')
    assert hashlib.sha256(positive).hexdigest() == old['sha256']
    base = current.replace('\r\n', '\n')
    a = base.index('\t\t\tstruct OSM {')
    b = base.index('\t\t\t/// @cond\n\t\t\tstruct Osm', a)
    fragment = (core / 'osm-reflected.inc').read_text(encoding='utf-8')
    reflected = base[:a] + ''.join('\t\t\t' + line if line.strip() else line
                                   for line in fragment.splitlines(keepends=True)) + base[b:]
    reflected = reflected.replace('frequency.value != hz.value', 'frequency != hz')
    reflected = reflected.replace('Direction is cached in set(); backwards boundary states use separate formulas.',
                                  'Negative Hz reflects phase in set(); both directions use the forward state machine.')
    upstream = ROOT / 'build/farbrausch-v2/synth_core.cpp'
    assert sha(upstream) == SOURCE_HASH
    original = upstream.read_text()
    extracted = '// Unchanged routines from Farbrausch V2, Tammo Hinrichs / Fabian Giesen.\n'
    extracted += '// v2/LICENSE.txt places the directory in the public domain.\n'
    extracted += '#include <cstdint>\n#include <cassert>\nusing sF32=float; using sU32=uint32_t; using sInt=int;\n'
    extracted += '#define COVER(x)\nstatic const sF32 fc32bit=2147483648.0f;\nunion FloatBits {sF32 f; sU32 u;};\n'
    for sig in ['static sF32 bits2float(', 'static inline sF32 sqr(', 'static inline sF32 utof23(', 'static inline sU32 ftou32(']:
        extracted += function(original, sig) + '\n'
    extracted += 'struct V2OscProbe { sU32 cnt,brpt; sInt freq; bool ring; sF32 gain;\n'
    a = original.index('enum OSMTransitionCode'); b = original.index('};', a) + 2
    extracted += original[a:b] + '\n'
    for sig in ['inline void output(', 'inline sU32 osm_init(', 'inline sU32 osm_tick(', 'void renderTriSaw(', 'void renderPulse(']:
        extracted += function(original, sig) + '\n'
    extracted += '};\n'
    headers = {'original': ROOT / 'experiments/klang/core/baselines/production-2026-09-17/klang.h'}
    for name, filename, data in [('v2', 'v2-oscillator.h', extracted.encode()),
                                  ('positive', 'klang.h', positive), ('reflection', 'klang.h', reflected.encode())]:
        directory = output / 'headers' / name
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / filename
        path.write_bytes(data)
        headers[name] = path
    return headers


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default='cl.exe')
    parser.add_argument('--driver', choices=['cl', 'gnu'], default='cl')
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--output', default='build/osm-four-way/msvc')
    parser.add_argument('--versions', nargs='+', help='Restrict the versions measured')
    parser.add_argument('--flag', action='append', default=[], help='Additional compiler option, e.g. --flag=/fp:precise')
    parser.add_argument('--assembly', action='store_true', help='Retain source/assembly listings')
    parser.add_argument('--frontend', action='store_true', help='Benchmark Klang signal-flow syntax instead of direct process calls')
    parser.add_argument('--extensions', action='store_true', help='Use extended ordinary FM/PWM and multi-cycle workloads')
    parser.add_argument('--fractional-duty', action='store_true', help='Use ordinary workloads and tiny-duty cases instead of multi-cycle cases')
    parser.add_argument('--combined', action='store_true', help='Include ordinary FM/PWM, multi-cycle and tiny-duty workloads')
    parser.add_argument('--compare-header', nargs=2, action='append', default=[], metavar=('LABEL', 'PATH'))
    args = parser.parse_args()
    if args.combined and args.fractional_duty:
        parser.error('Choose --combined or --fractional-duty')
    if args.fractional_duty or args.combined:
        args.extensions = True
    compiler = shutil.which(args.compiler)
    if not compiler or args.repeats < 1:
        parser.error('Use a VS developer prompt and positive repetitions')
    output = (ROOT / args.output).resolve()
    if not output.is_relative_to(ROOT / 'build'):
        parser.error('Output must be under build/')
    headers = prepare(output)
    for label, path in args.compare_header:
        header = (ROOT / path).resolve(strict=True)
        if label in headers or not label.replace('-', '').isalnum() or header.name != 'klang.h' or not header.is_relative_to(ROOT):
            parser.error('Comparison headers need a unique label and workspace klang.h')
        headers[label] = header
    if args.versions:
        if not set(args.versions) <= set(headers):
            parser.error('Unknown version')
        headers = {name: headers[name] for name in args.versions}
    if args.frontend and 'v2' in headers:
        parser.error('The V2 kernel has no Klang frontend; select only Klang versions')
    if args.extensions and 'v2' in headers:
        parser.error('Extension workloads require Klang oscillators')
    source = ROOT / 'tests/klang' / ('osm-extension-benchmark.cpp' if args.extensions else 'osm-four-way.cpp')
    inputs = [ROOT / 'include/klang.h', ROOT / 'experiments/klang/core/klang.h',
              ROOT / 'experiments/klang/core/osm-reflected.inc', ROOT / 'build/farbrausch-v2/synth_core.cpp',
              ROOT / 'experiments/klang/core/osm-comparison-sources.json', Path(__file__), source]
    inputs += list(headers.values())
    hashes = {str(p.relative_to(ROOT)): sha(p) for p in inputs}
    records = {}
    flags = ['/nologo', '/std:c++17', '/EHsc', '/Od' if args.debug else '/O2', '/fp:fast',
             '/MTd' if args.debug else '/MT', '/D_DEBUG' if args.debug else '/DNDEBUG',
             '/DNOMINMAX', '/D_CRT_SECURE_NO_WARNINGS', '/wd4244', '/wd4305', '/showIncludes', *args.flag]
    if args.driver == 'gnu':
        flags = ['-std=c++17', '-fexceptions', '-O0' if args.debug else '-O2', '-ffast-math',
                 '-static', '-D_DEBUG' if args.debug else '-DNDEBUG', '-DNOMINMAX',
                 '-D_CRT_SECURE_NO_WARNINGS', '-H', *args.flag]
    define = '-D' if args.driver == 'gnu' else '/D'
    if args.frontend:
        flags.append(define+'OSM_FRONTEND')
    if args.fractional_duty:
        flags.append(define+'OSM_FRACTIONAL_DUTY_BENCH')
    if args.combined:
        flags.append(define+'OSM_COMBINED_BENCH')
    for name, header in headers.items():
        directory = output / name; directory.mkdir(exist_ok=True)
        exe = directory / 'benchmark.exe'
        definitions = [define+'OSM_V2'] if name == 'v2' else [define+'OSM_ORIGINAL'] if name == 'original' else []
        command = [compiler, *flags, *definitions, '/I' + str(header.parent), str(source),
                   '/Fo' + str(directory / 'benchmark.obj'), '/Fe' + str(exe)]
        if args.driver == 'gnu':
            command = [compiler, *flags, *definitions, '-I'+str(header.parent),
                       '-MD', '-MF', str(directory/'benchmark.d'), str(source), '-o', str(exe)]
        elif args.assembly:
            command += ['/FAs', '/Fa' + str(directory / 'benchmark.asm')]
        build = subprocess.run(command, capture_output=True, text=True, errors='replace', timeout=120)
        log = build.stdout + build.stderr
        (directory / 'compiler.log').write_text(log, encoding='utf-8')
        includes = (directory/'benchmark.d').read_text() if args.driver == 'gnu' and (directory/'benchmark.d').exists() else log
        if build.returncode or header.as_posix().lower() not in includes.replace('\\', '/').lower():
            print(log[-5000:]); return 1
        if args.driver == 'gnu' and args.assembly:
            asm = subprocess.run([*command[:-2], '-S', '-o', str(directory/'benchmark.asm')],
                                 capture_output=True, text=True, errors='replace', timeout=120)
            (directory/'assembly.log').write_text(asm.stdout+asm.stderr)
            if asm.returncode:
                print(asm.stderr[-5000:]); return 1
        records[name] = dict(command=command, header_sha256=sha(header), repetitions=[])
    orders = []
    for repeat in range(args.repeats):
        order = list(headers) if repeat % 2 == 0 else list(reversed(headers))
        orders.append(order)
        for name in order:
            exe = output / name / 'benchmark.exe'
            run = subprocess.run([str(exe)], capture_output=True, text=True, check=True, timeout=120)
            (output / name / f'metrics-{repeat}.csv').write_text(run.stdout)
            rows = [{k: v if k == 'wave' else float(v) for k, v in row.items()}
                    for row in csv.DictReader(io.StringIO(run.stdout))]
            assert len(rows) == (40 if args.combined else 32 if args.extensions else 16)
            records[name]['repetitions'].append(rows)
            print(name, repeat + 1, 'complete', flush=True)
    for record in records.values():
        record['metrics'] = []
        for i, first in enumerate(record['repetitions'][0]):
            row = dict(first)
            for key, reduce in [('median_ns', statistics.median), ('min_ns', min), ('max_ns', max)]:
                row[key] = reduce(run[i][key] for run in record['repetitions'])
            record['metrics'].append(row)
    version = subprocess.run([compiler, *(['--version'] if args.driver == 'gnu' or 'clang' in compiler.lower() else [])], capture_output=True, text=True)
    unchanged = all(sha(ROOT / p) == h for p, h in hashes.items())
    report = dict(date=datetime.now(timezone.utc).isoformat(), machine=platform.platform(), processor=platform.processor(),
                  compiler_version=version.stdout + version.stderr, debug=args.debug, hashes=hashes, sources_unchanged=unchanged,
                  compiler_environment={name: os.environ.get(name) for name in ['CL', '_CL_']}, extra_flags=args.flag,
                  rate=48000, frames=2000000, passes=5, repeats=args.repeats, execution_orders=orders,
                  modes={'0':'fixed 440 Hz, render 64', '1':'fixed 440 Hz, render 1',
                         '2':'unchanged setter every sample, render 1', '3':'varying positive Hz every sample, render 1'}, results=records)
    report['frontend'] = args.frontend
    if args.frontend:
        report['modes'] = {'0': 'osc >> out, fixed 440 Hz', '1': 'osc(440) * 1.f >> out',
                           '2': 'osc(positive FM) * 1.f >> out', '3': 'osc(bipolar FM) * .2f >> out'}
    report['extensions'] = args.extensions
    report['driver'] = args.driver
    report['combined'] = args.combined
    report['fractional_duty'] = args.fractional_duty
    if args.extensions:
        report['modes'] = {'0': 'fixed 440 Hz', '1': 'unchanged 440 Hz setter each sample',
            '2': 'positive FM 240-640 Hz', '3': 'bipolar FM -200 to +200 Hz',
            '4': 'PWM .1-.9, fixed 440 Hz', '5': 'positive FM plus PWM',
            '6': 'fixed 60000 Hz (control does not render this correctly)',
            '7': 'bipolar FM -150000 to +150000 Hz plus PWM (control contains wide inputs)'}
    if args.fractional_duty:
        report['modes']['6'] = 'fixed .001 Hz, 1e-6 duty'
        report['modes']['7'] = 'bipolar FM -.001 to +.001 Hz, PWM 1e-7 to 9e-7'
    if args.combined:
        report['modes']['8'] = 'fixed .001 Hz, 1e-6 duty'
        report['modes']['9'] = 'bipolar FM -.001 to +.001 Hz, PWM 1e-7 to 9e-7'
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    return 0 if unchanged else 1


if __name__ == '__main__':
    raise SystemExit(main())
