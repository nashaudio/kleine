// Frontline syntax and polymorphism contracts, independent of waveform accuracy.
#include <klang.h>
#include <cstdio>
#include <type_traits>
#include <utility>

using namespace klang;
namespace fast = klang::Generators::Fast;
static int checks = 0, failures = 0;
void check(bool okay, const char* label) {
    ++checks;
    if (!okay) { ++failures; std::printf("FAIL %s\n", label); }
}

template<class Osc>
struct Custom : Osc {
    int samples = 0, settings = 0;
    bool* destroyed = nullptr;
    using Osc::set;
    ~Custom() override { if (destroyed) *destroyed = true; }
    void process() override { this->out = float(++samples); }
    void set(param hz) override { ++settings; Osc::set(hz); }
    void set(param hz, param phase) override { ++settings; Osc::set(hz, phase); }
    void set(relative phase) override { ++settings; Osc::set(phase); }
};

struct Stage : Modifier {
    int inputs = 0, samples = 0;
    void input() override { ++inputs; }
    void process() override { out = in * 2.f; ++samples; }
};

template<class Osc>
void contract() {
    static_assert(std::is_base_of_v<fast::Osm, Osc>);
    static_assert(!std::is_final_v<Osc>);
#ifdef OSM_TYPED
    static_assert(std::is_same_v<decltype(std::declval<Osc&>()(param{440})), Osc&>);
#endif
    Osc osc, reference;
    signal out;
    osc(440, 0);
    reference.set(440, 0);
    for (int i = 0; i < 256; ++i) {
        osc >> out;
        reference.process();
        check(std::fabs(float(out) - float(reference.out)) < 1e-6f, "direct signal flow advances once");
    }
    osc.reset(); reference.reset();
    for (int i = 0; i < 256; ++i) {
        osc(-440) * .2f >> out;
        reference.set(-440); reference.process();
        check(std::fabs(float(out) - float(reference.out) * .2f) < 1e-6f, "inline setter/arithmetic advances once");
    }
    osc(Frequency{440}, relative{.25f}) * 1.f >> out;
    osc(relative{.5f}) * 1.f >> out;
    osc(440, 0, .25f) * 1.f >> out;
    osc(signal{441}) * 1.f >> out;
    osc(1, 2, 3, 4) * 1.f >> out; // Existing unused-arity/no-op setter remains available.
    const Osc& frozen = osc;
    const float previous = float(osc.out);
    signal last = frozen;
    check(float(last) == previous, "const conversion reads cached output");
    Custom<Osc> custom;
    custom(440) * 1.f >> out;
    check(custom.settings == 1 && custom.samples == 1 && float(out) == 1, "derived overrides via ordinary syntax");
    Osc& base = custom;
    base(441) * 1.f >> out;
    check(custom.settings == 2 && custom.samples == 2 && float(out) == 2, "derived overrides via Saw-like reference");
    fast::Osm& osm = custom;
    osm(442) * 1.f >> out;
    check(custom.settings == 3 && custom.samples == 3, "derived overrides via common Osm reference");
    Generic::Generator<signal>& generator = custom;
    generator(443) * 1.f >> out;
    check(custom.settings == 4 && custom.samples == 4, "derived overrides via Generator reference");
    Generic::Output<signal>& output = custom;
    output.operator>>(out); // Unqualified Output& >> signal has a pre-existing ambiguity.
    check(custom.samples == 5 && float(out) == 5, "derived override via Output reference");
    custom(440, 0) * 1.f >> out;
    check(custom.settings == 5 && custom.samples == 6, "two-parameter override");
    custom(440, relative{.25f}) * 1.f >> out;
    check(custom.settings == 7 && custom.samples == 7, "relative setter forwards through virtual overrides");
    custom(relative{.5f}) * 1.f >> out;
    check(custom.settings == 8 && custom.samples == 8, "relative-only override");
    float gain = .5f;
    custom * gain >> out;
    check(custom.samples == 9 && float(out) == 4.5f, "right lvalue arithmetic override");
    .5f * custom >> out;
    check(custom.samples == 10 && float(out) == 5, "left scalar arithmetic override");
    custom * .5f >> out;
    check(custom.samples == 11 && float(out) == 5.5f, "right temporary arithmetic override");
    param parameter = .5f;
    custom * parameter >> out;
    check(custom.samples == 12 && float(out) == 6, "Klang parameter arithmetic override");
    const Custom<Osc>& constCustom = custom;
    signal cached = constCustom;
    check(custom.samples == 12 && float(cached) == 12, "const subclass read never processes");
    Custom<Osc> second;
    signal product = custom * second;
    check(custom.samples == 13 && second.samples == 1 && float(product) == 13, "generator arithmetic evaluates both once");
    auto& configured = base(440);
    Generic::Output<signal>& widened = configured;
    widened.operator>>(out);
    check(custom.samples == 14 && custom.settings == 9, "typed result still converts to Output reference");
    Stage sharedStage;
    base(441) * 1.f >> sharedStage >> out;
    check(custom.samples == 15 && custom.settings == 10 && sharedStage.inputs == 1 &&
          sharedStage.samples == 1 && float(out) == 30, "ordinary modifier route preserves input and processing hooks");
    bool destroyed = false;
    auto* allocated = new Custom<Osc>;
    allocated->destroyed = &destroyed;
    Generic::Oscillator<signal>* polymorphic = allocated;
    delete polymorphic;
    check(destroyed, "virtual destruction reaches subclass destructor");
#ifdef OSM_TYPED
    Custom<Osc> inlineRoute;
    inlineRoute(440) >> out;
    check(inlineRoute.samples == 1 && inlineRoute.settings == 1 && float(out) == 1,
          "typed return removes Output-reference inline routing ambiguity");
    Osc& inlineBase = inlineRoute;
    inlineBase(441) >> out;
    check(inlineRoute.samples == 2 && inlineRoute.settings == 2 && float(out) == 2,
          "unscaled inline route still respects overrides through oscillator reference");
    Stage stage;
    inlineBase(442) >> stage >> out;
    check(inlineRoute.samples == 3 && inlineRoute.settings == 3 && stage.inputs == 1 &&
          stage.samples == 1 && float(out) == 6, "typed source preserves modifier input and processing hooks");
#endif
}

int main() {
    fs = 48000;
    contract<fast::Saw>(); contract<fast::Triangle>();
    contract<fast::Square>(); contract<fast::Pulse>();
    std::printf("checks=%d failures=%d Saw=%zu\n", checks, failures, sizeof(fast::Saw));
    return failures ? 1 : 0;
}
