"""Generate separately gated OSM extensions from the recommended reflection candidate."""
import argparse
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from compare_osm_versions import ROOT
from osm_codegen_variants import variants


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='build/osm-extensions')
    parser.add_argument('--variant', choices=['multicycle', 'fractional-duty', 'combined'], default='multicycle')
    args = parser.parse_args()
    output = (ROOT / args.output).resolve()
    if not output.is_relative_to(ROOT / 'build'):
        parser.error('Output must stay under build/')
    subprocess.run([sys.executable, str(ROOT / 'tests/klang/osm_codegen_variants.py'),
                    '--output', str(output / 'base')], check=True, capture_output=True)
    base = (output / 'base/force-inline/klang.h').read_text(encoding='utf-8')
    fragment_path = ROOT / f'experiments/klang/core/osm-{args.variant}.inc'
    fragment = variants(fragment_path.read_text(encoding='utf-8'))['vector-distances']
    fragment = re.sub(r'^(\s*)(?=(?:OSM)\(|(?:void|float|State) (?:set|setDuty|setBreakpoint|setOffset|reset|sync|coefficients|tick|output|saw|pulse)\()',
                      r'\1KLANG_OSM_INLINE ', fragment, flags=re.MULTILINE)
    a = base.index('\t\t\tstruct OSM {')
    b = base.index('\t\t\t/// @cond\n\t\t\tstruct Osm', a)
    fragment = fragment[fragment.index('struct OSM {'):]
    candidate = base[:a] + ''.join('\t\t\t' + line if line.strip() else line
                                   for line in fragment.splitlines(keepends=True)) + base[b:]
    records = {}
    for name, source in [('control', base), (args.variant, candidate)]:
        header = output / 'headers' / name / 'klang.h'
        header.parent.mkdir(parents=True, exist_ok=True)
        header.write_text(source, encoding='utf-8')
        records[name] = dict(path=str(header), sha256=hashlib.sha256(header.read_bytes()).hexdigest())
    records['source'] = dict(path=str(fragment_path), sha256=hashlib.sha256(fragment_path.read_bytes()).hexdigest())
    (output / 'headers.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(records, indent=2))


if __name__ == '__main__':
    main()
