// One common buffered workload for old Klang, upstream V2, and the two fixes.
// V2's extracted render routines are unchanged; only its Hz adapter is supplied.
#include <array>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#ifdef OSM_V2
#include "v2-oscillator.h"
template<bool Pulse, int Quarters>
struct Wave {
    V2OscProbe osc{};
    float frequency = -1;
    Wave() {
        osc.brpt = ftou32(Quarters * .25f);
        osc.gain = 1;
        osc.ring = false;
    }
    void set(float hz) {
        if (frequency != hz) {
            frequency = hz;
            osc.freq = int(double(hz) * (4294967296.0 / 48000));
        }
    }
    void render(float* dest, int count) {
        if constexpr (Pulse) osc.renderPulse(dest, count);
        else osc.renderTriSaw(dest, count);
    }
};
using Saw = Wave<false, 0>;
using Triangle = Wave<false, 2>;
using Square = Wave<true, 2>;
using Pulse = Wave<true, 1>;
#else
#include <klang.h>
template<class Osc, bool QuarterPulse = false>
struct Wave {
    Osc osc;
#ifdef OSM_INLINE_CONSTRUCTION
    // Diagnostic: expose initial duty/phase to the enclosing render loop.
    __forceinline
#endif
    Wave() {
        osc.set(440, 0);
        if constexpr (QuarterPulse) {
#ifdef OSM_ORIGINAL
            // Its default .5 duty maps to 25% through the old half-scale phase.
#else
            osc.setDuty(.25f);
#endif
        }
    }
    void set(float hz) {
#ifdef OSM_QUALIFIED
        // Diagnostic: force static dispatch for a concretely owned oscillator.
        osc.Osc::set(hz);
#else
        osc.set(hz);
#endif
    }
    void render(float* dest, int count) {
        for (int i = 0; i < count; ++i) {
#ifdef OSM_QUALIFIED
            osc.Osc::process();
#else
            osc.process();
#endif
            dest[i] += float(osc.out);
        }
    }
#ifdef OSM_FRONTEND
    void frontend(float* dest, int frame, int mode, const std::array<float, 256>& frequencies) {
        klang::signal value;
        if (mode == 0) osc >> value;
        else if (mode == 1) osc(440) * 1.f >> value;
        else if (mode == 2) osc(frequencies[frame & 255]) * 1.f >> value;
        else osc(frequencies[frame & 255] - 440.f) * .2f >> value;
        *dest += float(value);
    }
#endif
};
using Saw = Wave<klang::optimised::Saw>;
using Triangle = Wave<klang::optimised::Triangle>;
using Square = Wave<klang::optimised::Square>;
using Pulse = Wave<klang::optimised::Pulse, true>;
#endif

volatile double consumed = 0;
template<class Osc>
void bench(const char* name, int mode) {
    std::array<float, 256> frequencies;
    for (int i = 0; i < 256; ++i) frequencies[i] = float(440 + 200 * std::sin(i * .03));
    constexpr int frames = 2000000, block = 64;
    double times[5], checksum = 0;
    for (int pass = 0; pass < 5; ++pass) {
        Osc osc;
        osc.set(440);
        double sum = 0;
        const auto start = std::chrono::steady_clock::now();
        for (int frame = 0; frame < frames; frame += block) {
            float audio[block]{};
#ifdef OSM_FRONTEND
            for (int i = 0; i < block; ++i) osc.frontend(audio + i, frame + i, mode, frequencies);
#else
            if (mode == 0) osc.render(audio, block);
            else {
                for (int i = 0; i < block; ++i) {
                    if (mode == 2) osc.set(440);
                    if (mode == 3) osc.set(frequencies[(frame + i) & 255]);
                    osc.render(audio + i, 1);
                }
            }
#endif
            for (float x : audio) sum += x;
        }
        const auto end = std::chrono::steady_clock::now();
        consumed = checksum = sum;
        times[pass] = std::chrono::duration<double, std::nano>(end - start).count() / frames;
    }
    std::sort(times, times + 5);
    std::printf("%s,%d,%zu,%.9g,%.9g,%.9g,%.12g\n", name, mode, sizeof(Osc), times[0], times[2], times[4], checksum);
}

int main() {
#ifndef OSM_V2
    klang::fs = 48000;
#endif
    std::puts("wave,mode,bytes,min_ns,median_ns,max_ns,checksum");
    for (int mode = 0; mode < 4; ++mode) {
        bench<Saw>("saw", mode);
        bench<Triangle>("triangle", mode);
        bench<Square>("square", mode);
        bench<Pulse>("pulse25", mode);
    }
}
