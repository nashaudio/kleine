# Improved OSM archive

Completed and accepted on 17 September 2026. Original repository-relative paths and exact bytes are preserved. ARCHIVE-MANIFEST.json records hashes and which files were retired, moved or retained as live dependencies.

Start with experiments/klang/core/OSM-PROMOTION.md and osm-listening-review.json. Superseded reports, variants, benchmark harnesses and measured results are historical evidence, not outstanding tasks. The working header and earlier baseline are included as snapshots.

Extract into a separate directory for inspection; do not overwrite the current workspace. Reproduction uses the matching repository models and the external compilers/Studio DLL documented in the reports; generated executables and bulk build outputs are not included. Active numeric, time-unit, literal, scheduling, PD-block and ambiguity experiments remain live outside this archive.
