# Klang UE 0.7.9 integration archive

Completed 17 September 2026 and promoted as Klang 0.7.10. Paths are repository-relative.

This archive retains the reviewed UE integration source snapshots, focused experiments, production header/model snapshots, language and model tests, licences, and compact JSON reports referenced by `docs/klang/working-production.json`.

Bulk audio, plots, HTML inspections, executables, objects, dependency files and repetitive compiler logs are intentionally excluded. Extract at a repository root or into a separate inspection directory; do not overwrite newer work without reviewing hashes and diffs.

The live source/tests/documentation remain tracked. Generated `build/` copies are disposable after this archive is verified.
